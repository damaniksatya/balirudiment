<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GajiFreelanceAbsenKerja extends Model
{
  protected $table = 'gaji_freelance_absen_kerja';
  public $timestamps = false;

  public static function getInfo($id_gaji_freelance)
  {
    return self::where('id_gaji_freelance', $id_gaji_freelance)->first();
  }

  public static function insertOrUpdate($data)
  {
    $exists = self::where('id_gaji_freelance', $data['id_gaji_freelance'])
      ->where('bulan', $data['bulan'])
      ->exists();

    if($exists) self::updateData($data);
    else self::insertData($data);
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_gaji_freelance', $data['id_gaji_freelance'])
      ->where('bulan', $data['bulan'])
      ->update($data);
  }

  public static function deleteData($id_gaji_freelance)
  {
    self::where('id_gaji_freelance', $id_gaji_freelance)->delete();
  }
}
