<?php

namespace App;

use App\Http\Controllers\InstrukturController;
use App\Http\Controllers\InstrumenController;
use App\Http\Controllers\StudioController;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Instruktur extends Model
{
  protected $table = 'instruktur';
  public $timestamps = false;

  const J_LAKI_LAKI = 'LAKI-LAKI';
  const J_PEREMPUAN = 'PEREMPUAN';

  const JI_FULL_TIME = 'FULL TIME';
  const JI_FREELANCE = 'FREELANCE';

  public static $jenis_instruktur = [
    self::JI_FULL_TIME,
    self::JI_FREELANCE,
  ];

  public static $jenis_kelamin = [
    self::J_LAKI_LAKI,
    self::J_PEREMPUAN,
  ];

  public static $color = [
    self::JI_FULL_TIME => 'primary',
    self::JI_FREELANCE => 'purple',
    self::J_LAKI_LAKI => 'primary',
    self::J_PEREMPUAN => 'purple',
  ];

  public static function getInfo($id_pengguna)
  {
    $get = self::leftJoin('pengguna as p','p.id','=','instruktur.id_pengguna')
      ->leftJoin('penempatan as pp','pp.id_penempatan','=','instruktur.id_penempatan')
      ->where('instruktur.id_pengguna', $id_pengguna)
      ->first();

    if($get != null){
      $get->nama_studio = StudioController::implodeNamaStudio($get->id_studio);
      $get->nama_instrumen = InstrumenController::implodeNamaInstrumen($get->id_instrumen);
    }

    return $get;
  }

  public static function getInfoByIdInstruktur($id_instruktur)
  {
    $get = self::leftJoin('pengguna as p','p.id','=','instruktur.id_pengguna')
      ->leftJoin('penempatan as pp','pp.id_penempatan','=','instruktur.id_penempatan')
      ->where('instruktur.id_instruktur', $id_instruktur)
      ->first();

    if($get != null){
      $get->nama_studio = StudioController::implodeNamaStudio($get->id_studio);
      $get->nama_instrumen = InstrumenController::implodeNamaInstrumen($get->id_instrumen);
    }

    return $get;
  }

  public static function getIdPenempatan()
  {
    if(Auth::user()){
      $get = self::where('id_pengguna', Auth::user()->id)->first();
      return $get ? $get->id_penempatan : null;
    }
    return null;
  }

  public static function getNamaInstruktur($id_instruktur = null)
  {
    if($id_instruktur){
      $get = self::where('id_instruktur', $id_instruktur)->first();
      return $get ? $get->nama_instruktur : null;
    }
    else{
      $get = self::where('id_pengguna', Auth::user()->id)->first();
      return $get ? $get->nama_instruktur : null;
    }
  }

  public static function getData($jenis_instruktur = null)
  {
    if($jenis_instruktur != null){
      $get = self::leftJoin('pengguna as p','p.id','=','instruktur.id_pengguna')
        ->leftJoin('penempatan as pp','pp.id_penempatan','=','instruktur.id_penempatan')
        ->where('instruktur.jenis_instruktur', $jenis_instruktur)
        ->get();
    }
    else{
      $get = self::leftJoin('pengguna as p','p.id','=','instruktur.id_pengguna')
        ->leftJoin('penempatan as pp','pp.id_penempatan','=','instruktur.id_penempatan')
        ->get();
    }

    foreach($get as $index=>$g){
      $get[$index]->nama_studio = StudioController::implodeNamaStudio($g->id_studio);
      $get[$index]->nama_instrumen = InstrumenController::implodeNamaInstrumen($g->id_instrumen);
    }

    return $get;
  }

  public static function getDataAktif($id_penempatan = null)
  {
    $get = self::leftJoin('pengguna as p','p.id','=','instruktur.id_pengguna')->where('p.status', User::S_AKTIF);
    $get = $id_penempatan != null ? $get->where('instruktur.id_penempatan', $id_penempatan) : $get;
    $get = $get->leftJoin('penempatan as pp','pp.id_penempatan','=','instruktur.id_penempatan')->get();

    foreach($get as $index=>$g){
      $get[$index]->nama_studio = StudioController::implodeNamaStudio($g->id_studio);
      $get[$index]->nama_instrumen = InstrumenController::implodeNamaInstrumen($g->id_instrumen);
    }

    return $get;
  }

  public static function getJumlahAktif()
  {
    return self::leftJoin('pengguna as p','p.id','=','instruktur.id_pengguna')
      ->where('p.status', User::S_AKTIF)
      ->count();
  }

  public static function getDataStudio($id_instruktur, $id_instrumen)
  {
    if(!$id_instruktur || !$id_instrumen) return [];
    $info = self::where('id_instruktur', $id_instruktur)->first();
    return Studio::getDataByPenempatanInstrumen($info->id_penempatan, $id_instrumen);
  }

  public static function getDataInstrumen($id_instruktur)
  {
    if(!$id_instruktur) return [];
    $info = self::where('id_instruktur', $id_instruktur)->first();
    $arr_id_instrumen = $info ? json_decode($info->id_instrumen) : [];
    $data_instrumen = Instrumen::getDataByArrId($arr_id_instrumen);
    return $data_instrumen;
  }

  public static function getIdInstruktur()
  {
    if(Auth::user()){
      $get = self::where('id_pengguna', Auth::user()->id)->first();
      return $get ? $get->id_instruktur : null;
    }
    else return null;
  }

  public static function isFreelance()
  {
    if(Auth::user()){
      $get = self::where('id_pengguna', Auth::user()->id)->first();
      return $get->jenis_instruktur == self::JI_FREELANCE;
    }
    else return false;
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_pengguna', $data['id_pengguna'])->update($data);
  }
}
