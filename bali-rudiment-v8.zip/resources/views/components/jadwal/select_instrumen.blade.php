<select name="id_instrumen" id="id_instrumen" class="form-control select2" title="Instrumen" onchange="getItemStudio()">
  @if(isset($id_instruktur))
    <option value="">Pilih Instrumen</option>
  @else
    <option value="">Pilih Instruktur terlebih dahulu</option>
  @endif
  @isset($data_instrumen)
    @foreach($data_instrumen as $l)
      <option value="{{ $l->id_instrumen }}" {{ (isset($id_instrumen) ? $id_instrumen : null) == $l->id_instrumen ? 'selected' : '' }}>{{ $l->nama_instrumen }}</option>
    @endforeach
  @endif
</select>