<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Bali Rudiment" name="description" />
    
    <meta content="LaraDev" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="icon" type="image/jpg" sizes="16x16" href="<?php echo e(url('images/logo.jpg')); ?>">
    <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" id="bootstrap-stylesheet" />
    <link href="<?php echo e(url('css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('css/app.min.css')); ?>" rel="stylesheet" type="text/css"  id="app-stylesheet" />
</head>
<body class="authentication-bg" style="background-color: #263238">
<div class="account-pages pt-5 my-5"><?php echo $__env->yieldContent('content'); ?></div>

<script src="<?php echo e(url('js/vendor.min.js')); ?>"></script>
<script src="<?php echo e(url('js/app.min.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>