<?php

namespace App\Http\Controllers;

use App\JadwalHarian;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Auth;

class HelperController extends Controller
{
  public static $arr_bulan = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
  public static function setNamaBulan($tahun_bulan, $tahun_bulan_tanggal = null)
  {
    $arr_nama_bulan = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

    $exp = explode('-', $tahun_bulan_tanggal == null ? $tahun_bulan : $tahun_bulan_tanggal);

    if($tahun_bulan_tanggal == null && count($exp) < 2)
      return $tahun_bulan;
    elseif($tahun_bulan_tanggal != null && count($exp) < 3)
      return $tahun_bulan_tanggal;

    $tahun = $exp[0];
    $bulan = $exp[1];
    $nama_bulan = $arr_nama_bulan[(int)$bulan-1];

    return $tahun_bulan_tanggal == null ? $nama_bulan.' '.$tahun : $exp[2].' '.$nama_bulan.' '.$tahun;
  }

  public static function getDurasiMenit($jam_mulai, $jam_selesai)
  {
    $waktu_mulai = strtotime(date("Y-m-d $jam_mulai"));
    $waktu_selesai = strtotime(date("Y-m-d $jam_selesai"));
    $durasi = ($waktu_selesai - $waktu_mulai) / 60;
    return $durasi;
  }

  public static function getNamaHari($tanggal)
  {
    $arr_hari = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
    $no_hari = date('w', strtotime($tanggal));
    return $arr_hari[$no_hari];
  }

  public static function setNamaWaktu($Ymd_His)
  {
    $Ymd = explode(' ', $Ymd_His)[0];
    $Hi = substr($Ymd_His, 11, 5);
    $nama_bulan = self::setNamaBulan(null, $Ymd);

    return $nama_bulan.' ('.$Hi.')';
  }

  public static function formatNumber($val, $with_rp = true)
  {
    $string_rp = $with_rp ? 'Rp ' : null;
    $formatted_number = number_format($val, 0, ',', '.');
    return $string_rp.$formatted_number;
  }

  public static function getArrJam($jam_mulai, $jam_selesai, $menit_step = null)
  {
    $menit_step = $menit_step != null ? $menit_step : JadwalHarian::MINUTE_STEP;
    $detik_mulai = strtotime(date('Y-m-d')." $jam_mulai:00");
    $detik_selesai = strtotime(date('Y-m-d')." $jam_selesai:00");
    $detik_step = $menit_step * 60;
    $jumlah_perulangan = (int)(($detik_selesai - $detik_mulai) / $detik_step) + 1;
    $arr_jam = [];

    for($i=0; $i<$jumlah_perulangan; $i++){
      $arr_jam[] = date("H:i", $detik_mulai + ($detik_step * $i));
    }
    return $arr_jam;
  }

  public static function getColumnAlphabeticalNameByNumber($number)
  {
    $arr_alphabet = range('A','Z');
    $one_digit = $number <= 26;
    $two_digit = $number <= 702;

    if($one_digit) $index_total = 0;
    elseif($two_digit) $index_total = 26;
    else $index_total = 702;

    for($i=0; $i<26; $i++){
      $ap1 = $arr_alphabet[$i];

      if($one_digit){
        $index_total += 1;
        if($number == $index_total) return $ap1;
      }
      else{
        for($a=0; $a<26; $a++){
          $ap2 = $arr_alphabet[$a];

          if($two_digit){
            $index_total += 1;
            if($number == $index_total) return $ap1.$ap2;
          }
          else{
            for($b=0; $b<26; $b++){
              $ap3 = $arr_alphabet[$b];
              $index_total += 1;
              if($number == $index_total) return $ap1.$ap2.$ap3;
            }
          }
        }
      }
    }
    return "Out of range, max $index_total";
  }

  public static function getNextJam($jam, $menit_step = null)
  {
    $menit_step = $menit_step != null ? $menit_step : JadwalHarian::MINUTE_STEP;
    $detik_step = $menit_step * 60;
    $result = (int)strtotime(date('Y-m-d')." $jam:00") + $detik_step;
    return date("H:i", $result);
  }

  public static function getValue($name, $arr, $arr_not_all = [])
  {
    $data = [];
    foreach($arr as $a){
      if(isset($_GET[$a])){
        $data[$a] = $_GET[$a];
      }
      else{
        $data[$a] = self::getCookie($name.$a) ?: null;
      }
    }
    $set_data = $data;

    foreach($arr_not_all as $an){
      if(isset($_GET[$an])){
        $value = $_GET[$an];
      }
      else{
        $value = self::getCookie($name.$an) ?: null;
      }
      $data[$an] = $value == 'all' ? null : $value;
      $set_data[$an] = $value;
    }

    self::setCookie($name, $set_data);
    return $data;
  }

  public static function setCookie($name, $data)
  {
    $user = 'bali_rudiment';
    $arr = [];
    if(Cookie::get($user)){
      $cookie = Cookie::get($user);
      $arr = (array)json_decode($cookie);
    }
    foreach($data as $index=>$d){
      $arr[$name.$index] = $d;
    }
    Cookie::queue($user, json_encode($arr), 43200);
  }

  public static function getCookie($name)
  {
    $user = 'bali_rudiment';
    if(Cookie::get($user)){
      $cookie = Cookie::get($user);
      $arr = (array)json_decode($cookie);
      if(isset($arr[$name])){
        return $arr[$name];
      }
    }
    return null;
  }

  public static function isPdf($string)
  {
    if($string == null) return false;

    $a = explode('.', $string);
    return $a[count($a)-1] == 'pdf';
  }

  public static function isImage($string)
  {
    if($string == null) return false;

    $a = explode('.', $string);
    return in_array(strtolower($a[count($a)-1]), ['png','jpg','jpeg']);
  }

  public static function getRomawiBulan($bulan)
  {
    $romawi = [
      '01' => 'I',
      '02' => 'II',
      '03' => 'III',
      '04' => 'IV',
      '05' => 'V',
      '06' => 'VI',
      '07' => 'VII',
      '08' => 'VIII',
      '09' => 'IX',
      '10' => 'X',
      '11' => 'XI',
      '12' => 'XII',
    ];

    if(array_key_exists($bulan, $romawi)) return $romawi[$bulan];
    return null;
  }
}
