@extends('layouts.main')

@section('title','Data Penempatan')

@php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_penempatan);
  $nonaktif_input = in_array(\App\SettingMenu::CREATE_PENEMPATAN, $arr_nonaktif);
  $nonaktif_edit = in_array(\App\SettingMenu::UPDATE_PENEMPATAN, $arr_nonaktif);
  $nonaktif_delete = in_array(\App\SettingMenu::DELETE_PENEMPATAN, $arr_nonaktif);
@endphp

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right mt-2 pt-1">
                @if($nonaktif_input == false)
                  <a href="{{ url('penempatan/add') }}" class="btn btn-primary">
                    <i class="mdi mdi-plus mr-2"></i>Input Data Penempatan
                  </a>
                @endif
              </div>
              <h4 class="page-title">Data Penempatan</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body">
            <div class="table-responsive">
              <table id="datatable" class="table mb-0 table-sm table-bordered">
                <thead>
                <tr>
                  <th class="text-center" style="width: 40px">No</th>
                  <th class="">Nama Penempatan</th>
                  @if(!($nonaktif_edit && $nonaktif_delete))
                    <th style="width: 80px" class="text">Aksi</th>
                  @endif
                </tr>
                </thead>
                <tbody>
                @foreach($data as $no=>$d)
                  <tr>
                    <td class="text-center">{{ $no+1 }}</td>
                    <td class="">{{ $d['nama_penempatan'] }}</td>
                    @if(!($nonaktif_edit && $nonaktif_delete))
                      <td>
                        <div class="btn-group btn-block">
                          @if(!$nonaktif_edit)
                            <a href="{{ url('penempatan/edit/'.$d['id_penempatan']) }}" class="btn btn-outline-primary btn-sm">Edit</a>
                          @endif

                          @if(!$nonaktif_delete)
                            <button id="delete-{{ $d['id_penempatan'] }}" type="button" class="btn btn-block btn-sm btn-outline-danger">Hapus</button>
                          @endif
                        </div>

                        <form id="form-delete{{ $d['id_penempatan'] }}" action="{{ url('penempatan') }}" method="post">
                          @csrf @method('delete')
                          <input type="hidden" name="id" value="{{ $d['id_penempatan'] }}">
                        </form>
                      </td>
                    @endif
                  </tr>
                @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection
@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script>
      @foreach($data as $d)
          $('#delete-{{ $d['id_penempatan'] }}').click(function(){
              swal({
                  title: "Anda yakin?",
                  text: "Data penempatan {{ $d['nama_penempatan'] }} yang akan dihapus, tidak bisa dikembalikan!",
                  type: "warning",
                  showCancelButton: true,
                  confirmButtonColor: "#E62129",
                  confirmButtonText: "Ya, hapus!",
                  cancelButtonText: "Batalkan",
                  closeOnConfirm: false
              }, function(){
                  $("#form-delete{{ $d['id_penempatan'] }}").submit();
              });
          });
      @endforeach
  </script>
@endsection