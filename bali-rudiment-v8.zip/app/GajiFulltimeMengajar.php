<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GajiFulltimeMengajar extends Model
{
  protected $table = 'gaji_fulltime_mengajar';
  public $timestamps = false;

  const ADDITION_ROW = 5;

  public static function getData($id_gaji_fulltime)
  {
    return self::where('id_gaji_fulltime', $id_gaji_fulltime)->get()->toArray();
  }

  public static function isExists($id_gaji_fulltime)
  {
    return self::where('id_gaji_fulltime', $id_gaji_fulltime)->exists();
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id', $data['id'])->update($data);
  }

  public static function deleteData($data)
  {
    self::where('id', $data['id'])->delete();
  }

  public static function deleteByIdGaji($id_gaji_fulltime)
  {
    self::where('id_gaji_fulltime', $id_gaji_fulltime)->delete();
  }
}
