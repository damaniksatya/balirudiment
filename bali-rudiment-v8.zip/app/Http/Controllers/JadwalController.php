<?php

namespace App\Http\Controllers;

use App\Instruktur;
use App\Jadwal;
use App\JadwalHarian;
use App\JadwalSiswa;
use App\Siswa;
use App\Studio;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class JadwalController extends Controller
{
  public function index()
  {
    $data_bulan = Jadwal::getArrBulan();
    $bulan = HelperController::getValue('bulan',['bulan'])['bulan'];
    $bulan = $bulan ?: (count($data_bulan) ? $data_bulan[0] : 'all');
    $data = Jadwal::getData($bulan);
//    dd($data);

    return view('pages.jadwal.index')
      ->with('data', $data)
      ->with('bulan', $bulan)
      ->with('data_bulan', $data_bulan);
  }

  public function indexInstruktur()
  {
    $data_bulan = Jadwal::getArrBulanByInstruktur();
    $bulan = HelperController::getValue('bulan',['bulan'])['bulan'];
    $bulan = $bulan ?: (count($data_bulan) ? $data_bulan[0] : 'all');
    $data = Jadwal::getDataByInstruktur($bulan);

//    dd($data);
    return view('pages.jadwal.index_instruktur')
      ->with('data', $data)
      ->with('bulan', $bulan)
      ->with('data_bulan', $data_bulan);
  }

  public function indexSiswa()
  {
    $data_bulan = JadwalSiswa::getArrBulanBySiswa();
    $bulan = HelperController::getValue('bulan',['bulan'])['bulan'];
    $bulan = $bulan ?: (count($data_bulan) ? $data_bulan[0] : 'all');
    $data = Jadwal::getDataBySiswa($bulan);
//    dd($data);

    return view('pages.jadwal.index_siswa')
      ->with('data', $data)
      ->with('bulan', $bulan)
      ->with('data_bulan', $data_bulan);
  }

  public function viewAdd()
  {
    $data_instruktur = Instruktur::getDataAktif();
//    dd($data_instruktur);
    return view('pages.jadwal.add')
      ->with('data_instruktur', $data_instruktur);
  }

  public function viewEdit($id_jadwal)
  {
    $info = Jadwal::getInfo($id_jadwal);
    $data_instruktur = Instruktur::getDataAktif();

    return view('pages.jadwal.edit')
      ->with('data_instruktur', $data_instruktur)
      ->with('info', $info);
  }

  public function getComponentSelectInstrumen(Request $req)
  {
    $data_instrumen = Instruktur::getDataInstrumen($req->id_instruktur);
    $id_instrumen = $req->id_instrumen;

    return view('components.jadwal.select_instrumen')
      ->with('data_instrumen', $data_instrumen)
      ->with('id_instrumen', $id_instrumen)
      ->with('id_instruktur', $req->id_instruktur);
  }

  public function getComponentSelectStudio(Request $req)
  {
    $data_studio = Instruktur::getDataStudio($req->id_instruktur, $req->id_instrumen);
    $id_studio = $req->id_studio;

    return view('components.jadwal.select_studio')
      ->with('data_studio', $data_studio)
      ->with('id_studio', $id_studio)
      ->with('id_instrumen', $req->id_instrumen)
      ->with('id_instruktur', $req->id_instruktur);
  }

  public function getComponentTableAddSiswa(Request $req)
  {
    $info = Jadwal::getInfo($req->id_jadwal);
    $siswa_in_jadwal = JadwalSiswa::getArrIdSiswa($req->id_jadwal);
    $siswa_not_in_jadwal = Siswa::getArrIdByPenempatanInstrumen($info->id_penempatan, $info->id_instrumen, $siswa_in_jadwal);
    $data_siswa = Siswa::getDataByArrId(array_merge($siswa_in_jadwal, $siswa_not_in_jadwal));
    $data_jam = $this->getArrJam($info->jam_mulai, $info->jam_selesai);
//    return [$info, $siswa_in_jadwal, $siswa_not_in_jadwal, $data_siswa, $data_jam];
    return view('components.jadwal.table_add_siswa')
      ->with('info', $info)
      ->with('data_siswa', $data_siswa)
      ->with('data_jam', $data_jam)
      ->with('siswa_in_jadwal', $siswa_in_jadwal)
      ->with('siswa_not_in_jadwal', $siswa_not_in_jadwal);
  }

  public function getComponentModalEditJam(Request $req)
  {
    $info = Jadwal::getInfo($req->id_jadwal);
    $data_jadwal = JadwalSiswa::getData($req->id_jadwal, $req->id_siswa);
    $data_jam = $this->getArrJam($info->jam_mulai, $info->jam_selesai);

    return view('components.jadwal.table_edit_jam')
      ->with('id_jadwal', $req->id_jadwal)
      ->with('id_siswa', $req->id_siswa)
      ->with('data_jadwal', $data_jadwal)
      ->with('data_jam', $data_jam);
  }

  public function getArrJam($jam_mulai, $jam_selesai)
  {
    $batas_jam_mulai = (int)strtotime(date('Y-m-d')." $jam_mulai:00");
    $batas_jam_mulai = $batas_jam_mulai + (60 * JadwalHarian::MINUTE_STEP);
    $batas_jam_mulai = date("H:i", $batas_jam_mulai);

    $batas_jam_selesai = (int)strtotime(date('Y-m-d')." $jam_selesai:00");
    $batas_jam_selesai = $batas_jam_selesai - (60 * JadwalHarian::MINUTE_STEP);
    $batas_jam_selesai = date("H:i", $batas_jam_selesai);

//    return [$batas_jam_mulai, $batas_jam_selesai];
    $arr_jam_mulai = HelperController::getArrJam($jam_mulai, $batas_jam_selesai);
    $arr_jam_selesai = HelperController::getArrJam($batas_jam_mulai, $jam_selesai);

    return [
      'arr_jam_mulai' => $arr_jam_mulai,
      'arr_jam_selesai' => $arr_jam_selesai,
    ];
  }

  public function store(Request $req)
  {
    $this->validateData();

    $data = [
      'id_instruktur' => $req->id_instruktur,
      'id_studio' => $req->id_studio,
      'id_instrumen' => $req->id_instrumen,
      'bulan' => $req->bulan,
      'hari' => $req->hari,
      'jam_mulai' => $req->jam_mulai,
      'jam_selesai' => $req->jam_selesai,
    ];

    $bertabrakan = $this->validateBertabrakan($data);
    if($bertabrakan){
      return back()->withErrors([$bertabrakan])->withInput();
    }
    $durasi = $this->validateDurasiMengajar($data);
    if ($durasi){
      return back()->withErrors([$durasi])->withInput();
    }

    Jadwal::insertData($data);

    return back()->with('success','Berhasil menyimpan data')->withInput();
  }

  private function validateBertabrakan($data, $except_id = null)
  {
    $error_msg = null;
    $instruktur = Jadwal::isJadwalBertabrakanByInstruktur($data, $except_id);
    if($instruktur['status']){
      $nama_instruktur = Instruktur::getNamaInstruktur($instruktur['info']['id_instruktur']);
      $nama_studio = Studio::getNamaStudio($instruktur['info']['id_studio']);
      $jam = $instruktur['info']['jam_mulai'] .'-'. $instruktur['info']['jam_selesai'];
      $hari = $instruktur['info']['hari'];
      $error_msg = "Jadwal bertabrakan dengan instruktur $nama_instruktur studio $nama_studio hari $hari jam $jam";
    }
    $studio = Jadwal::isJadwalBertabrakanByStudio($data, $except_id);
    if($studio['status']){
      $nama_instruktur = Instruktur::getNamaInstruktur($studio['info']['id_instruktur']);
      $nama_studio = Studio::getNamaStudio($studio['info']['id_studio']);
      $jam = $studio['info']['jam_mulai'] .'-'. $studio['info']['jam_selesai'];
      $hari = $studio['info']['hari'];
      $error_msg = "Jadwal bertabrakan dengan instruktur $nama_instruktur studio $nama_studio hari $hari jam $jam";
    }
    return $error_msg;
  }

  private function validateDurasiMengajar($data, $except_id = null)
  {
    if($data['jam_selesai'] < $data['jam_mulai'] || $data['jam_selesai'] == $data['jam_mulai']){
      return "Jam mulai / jam selesai tidak valid!";
    }

    $jam_maksimal = Jadwal::MAX_DURASI_MENGAJAR / 3600;
    $time_start = strtotime(date('Y-m-d')." ".$data['jam_mulai'].":00");
    $time_finish = strtotime(date('Y-m-d')." ".$data['jam_selesai'].":00");
    $total_durasi = (int)$time_finish - (int)$time_start;
    if($total_durasi > Jadwal::MAX_DURASI_MENGAJAR){
      return "Setiap instruktur maksimal mengajar selama $jam_maksimal jam berturut-turut.";
    }

    $jam_mulai = $data['jam_mulai'];
    $jam_selesai = $data['jam_selesai'];
    $get = Jadwal::where('id_instruktur', $data['id_instruktur'])
      ->where('id_jadwal','!=', $except_id)
      ->where('bulan', $data['bulan'])
      ->where('hari', $data['hari'])
      ->whereRaw("(jam_selesai = '$jam_mulai' OR jam_mulai = '$jam_selesai')")
//      ->where('jam_selesai','=', $data['jam_mulai'])
//      ->orWhere('jam_mulai','=', $data['jam_selesai'])
      ->first();

    if($get){
      if($data['jam_mulai'] < $get['jam_mulai']){
        $jam_mulai = $data['jam_mulai'];
        $jam_selesai = $get['jam_selesai'];
      }
      else{
        $jam_mulai = $get['jam_mulai'];
        $jam_selesai = $data['jam_selesai'];
      }

      $time_start = strtotime(date('Y-m-d')." $jam_mulai:00");
      $time_finish = strtotime(date('Y-m-d')." $jam_selesai:00");
      $total_durasi = (int)$time_finish - (int)$time_start;
      if($total_durasi > Jadwal::MAX_DURASI_MENGAJAR){
        $jam_mengajar = $get['jam_mulai'] .'-'. $get['jam_selesai'];
        return "Setiap instruktur maksimal mengajar selama $jam_maksimal jam berturut-turut. Terdapat jadwal mengajar dari jam $jam_mengajar";
      }
    }
    return null;
  }

  public function update(Request $req)
  {
    $this->validateData();
    $new_jam_mulai = $req->jam_mulai != $req->jam_mulai_old;
    $new_jam_selesai = $req->jam_selesai != $req->jam_selesai_old;
    $new_jam = $new_jam_mulai || $new_jam_selesai;

    $data = [
      'id_jadwal' => $req->id_jadwal,
      'id_instruktur' => $req->id_instruktur,
      'id_studio' => $req->id_studio,
      'id_instrumen' => $req->id_instrumen,
      'bulan' => $req->bulan,
      'hari' => $req->hari,
      'jam_mulai' => $req->jam_mulai,
      'jam_selesai' => $req->jam_selesai,
    ];

    if($new_jam){
      $bertabrakan = $this->validateBertabrakan($data, $req->id_jadwal);
      if($bertabrakan){
        return back()->withErrors([$bertabrakan])->withInput();
      }
      $durasi = $this->validateDurasiMengajar($data);
      if ($durasi){
        return back()->withErrors([$durasi])->withInput();
      }
    }

    DB::transaction(function () use ($req, $data){
      Jadwal::updateData($data);

      if($req->id_instrumen_old != $req->id_instrumen){
        JadwalSiswa::deleteData($req->id_jadwal);
      }
      elseif($req->hari_old != $req->hari || $req->bulan_old != $req->bulan){
        $data_siswa = JadwalSiswa::getArrIdSiswa($req->id_jadwal);
        JadwalSiswa::deleteData($req->id_jadwal);

        $arr_tgl = self::getArrTglDariHari($req->bulan, $req->hari);
        foreach($data_siswa as $id_siswa){
          foreach($arr_tgl as $tgl){
            JadwalSiswa::insertData([
              'id_jadwal' => $req->id_jadwal,
              'id_siswa' => $id_siswa,
              'tanggal' => $tgl,
            ]);
          }
        }
      }
    });


    return redirect('jadwal')->with('success','Berhasil menyimpan data');
  }

  public function updateJamMengajar(Request $req)
  {
    $error_msg = [];
    $data_jadwal = JadwalSiswa::getData($req->id_jadwal, $req->id_siswa);
    foreach($data_jadwal as $d){
      $jam_mulai = $req["jam_mulai$d->id_jadwal_siswa"];
      $jam_selesai = $req["jam_selesai$d->id_jadwal_siswa"];
      if($jam_mulai >= $jam_selesai){
        $tanggal = HelperController::setNamaBulan(null, $d->tanggal);
        $nama_siswa = Siswa::getNamaSiswa($req["id_siswa"]);
        $error_msg[] = "Jam mengajar $nama_siswa tanggal $tanggal tidak valid!";
      }
    }
    if(count($error_msg)) return back()->withErrors([$error_msg]);

    DB::transaction(function () use ($req, $data_jadwal){
      foreach($data_jadwal as $d){
        JadwalSiswa::updateData([
          'id_jadwal_siswa' => $d->id_jadwal_siswa,
          'jam_mulai' => $req["jam_mulai$d->id_jadwal_siswa"],
          'jam_selesai' => $req["jam_selesai$d->id_jadwal_siswa"],
        ]);
      }
    });

    return back()->with('success','Berhasil menyimpan data');
  }

  public function storeAddSiswa(Request $req)
  {
//    dd($req);
    $arr_in_jadwal = $req->siswa_in_jadwal ? json_decode($req->siswa_in_jadwal) : [];

    foreach($arr_in_jadwal as $id_siswa){
      $jam_mulai = $req["jam_mulai$id_siswa"];
      $jam_selesai = $req["jam_selesai$id_siswa"];
      if($jam_mulai >= $jam_selesai){
        $nama_siswa = Siswa::getNamaSiswa($id_siswa);
        return back()->withErrors(["Jam $jam_mulai sampai $jam_selesai siswa $nama_siswa tidak valid!"])->withInput();
      }
    }

    DB::transaction(function () use ($req, $arr_in_jadwal){
      $arr_tgl = self::getArrTglDariHari($req->bulan, $req->hari);
      $arr_list_siswa = $req->id_siswa ?: [];

      foreach($arr_list_siswa as $id_siswa){
        $exists = JadwalSiswa::isExists($id_siswa, $req->id_jadwal);
        if(!$exists){
          foreach($arr_tgl as $tgl){
            JadwalSiswa::insertData([
              'id_jadwal' => $req->id_jadwal,
              'id_siswa' => $id_siswa,
              'tanggal' => $tgl,
              'jam_mulai' => $req["jam_mulai$id_siswa"],
              'jam_selesai' => $req["jam_selesai$id_siswa"],
            ]);
          }
        }
        else{
          $new_jam_mulai = $req["jam_mulai$id_siswa"] != $req["jam_mulai_old$id_siswa"];
          $new_jam_selesai = $req["jam_selesai$id_siswa"] != $req["jam_selesai_old$id_siswa"];
          if($new_jam_mulai || $new_jam_selesai){
            JadwalSiswa::updateByIdJadwalAndSiswa($req->id_jadwal, $id_siswa, [
              'jam_mulai' => $req["jam_mulai$id_siswa"],
              'jam_selesai' => $req["jam_selesai$id_siswa"],
            ]);
          }
        }
      }

      foreach($arr_in_jadwal as $id_siswa){
        if(!in_array($id_siswa, $arr_list_siswa)){
          JadwalSiswa::deleteData($req->id_jadwal, $id_siswa);
        }
      }
    });

    return back()->with('success','Berhasil menyimpan data');
  }

  public static function getArrTglDariHari($bulan, $hari, $start_date = null)
  {
    $no_hari = Jadwal::$no_hari[$hari];
    $arr_tgl = [];
    $max_tgl = 4;

    for($i=1; $i<=31; $i++){
      $tgl = $bulan.'-'.sprintf("%02d", $i);
      if(date('w', strtotime($tgl)) == $no_hari){
        if($start_date == null || ($start_date != null && $tgl >= $start_date)){
          if(count($arr_tgl) < $max_tgl){
            $arr_tgl[] = $tgl;
          }
        }
      }
    }

    return $arr_tgl;
  }

  public static function getHariDariTanggal($tgl)
  {
    $no_hari = date('w', strtotime($tgl));
    return Jadwal::$hari[$no_hari];
  }

  private function validateData()
  {
    return request()->validate([
      'id_instruktur' => 'required',
      'id_studio' => 'required',
      'bulan' => 'required',
      'hari' => 'required',
      'jam_mulai' => 'required',
      'jam_selesai' => 'required',
    ],[
      'id_instruktur.required' => 'Nama Instruktur harus diisi!',
      'id_studio.required' => 'Studio harus diisi!',
      'bulan.required' => 'Bulan harus diisi!',
      'hari.required' => 'Hari harus diisi!',
      'jam_mulai.required' => 'Jam Mulai harus diisi!',
      'jam_selesai.required' => 'Jam Selesai harus diisi!',
    ]);
  }

  public function delete(Request $req)
  {
    DB::transaction(function () use ($req){
      Jadwal::deleteData($req->id_jadwal);
      JadwalSiswa::deleteData($req->id_jadwal);
    });
    return back()->with('success','Berhasil menghapus data');
  }
}
