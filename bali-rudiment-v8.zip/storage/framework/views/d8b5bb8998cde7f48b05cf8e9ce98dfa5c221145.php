<link href="<?php echo e(url('libs/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<script src="<?php echo e(url('libs/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(url('libs/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
    $(document).ready(function(){
        let options = {"columnDefs": [{ targets: 'no-sort', orderable: false }]};
        $("#datatable").DataTable(options);
        $(".datatable").DataTable(options);
    });
</script>
<style>
  td{
    vertical-align: middle !important;
  }
  table.dataTable.table-sm>thead>tr>th.no-sort {
    background: none;
    pointer-events: none;
    padding-right: 0.3rem !important;
  }
</style>