<form action="{{ url('absensi/konfirmasi') }}" method="post">
  @csrf @method('put')
  <input type="hidden" name="id_absensi" value="{{ $id_absensi }}">
  <table class="table table-sm table-bordered">
    <thead>
    <tr>
      <th>Nama Siswa</th>
      <th>Fee</th>
    </tr>
    </thead>
    <tbody>
    @php $arr_id_siswa = []; @endphp
    @foreach($data_absensi_siswa as $d)
      @php $arr_id_siswa[] = $d['id_siswa']; @endphp
      <tr>
        <td>{{ $d['siswa']['nama'] }}</td>
        <td>
          <input type="number" name="fee{{ $d['id_siswa'] }}" title="Fee {{ $d['siswa']['nama'] }}" class="form-control form-control-sm" value="{{ random_int(35, 65) * 1000 }}">
        </td>
      </tr>
    @endforeach
    </tbody>
  </table>
  <input type="hidden" name="arr_id_siswa" value="{{ json_encode($arr_id_siswa) }}">
  <div class="form-group row mb-0">
    <div class="col-lg-12">
      <button class="btn btn-primary float-right">Konfirmasi</button>
    </div>
  </div>
</form>