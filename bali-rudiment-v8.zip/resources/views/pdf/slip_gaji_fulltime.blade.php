<title>Slip Gaji Staff {{ $gaji['instruktur']['nama_instruktur'] }} Bulan {{ $nama_bulan }}</title>

<div class="text-center pb-3">
  <img src="{{ url('images/logo_kop.jpg') }}" alt="Logo" width="140px">
</div>

<table class="w-100 mb-3">
  <tr>
    <td style="width: 60px">Bulan</td>
    <td style="width: 5px">:</td>
    <td>{{ $nama_bulan }}</td>
  </tr>
  <tr>
    <td>Nama</td>
    <td>:</td>
    <td>{{ $gaji['instruktur']['nama_instruktur'] }}</td>
  </tr>
  <tr>
    <td>Jabatan</td>
    <td>:</td>
    <td>{{ $gaji['jabatan'] }}</td>
  </tr>
</table>

<table class="table table-sm table-bordered">
  <thead>
  <tr class="bg-secondary">
    <th class="py-2">Keterangan</th>
    <th colspan="3" class="text-center py-2">Jumlah</th>
    <th colspan="2" class="text-center py-2">Total</th>
  </tr>
  </thead>
  <tbody>
  <tr>
    <td>Gaji Pokok</td>
    <td class="text-center">{{ $gaji['gaji_pokok_jml_hari'] }}</td>
    <td style="width: 30px" class="border-right-0">Rp</td>
    <td style="width: 100px" class="text-right border-left-0">{{ number_format($gaji['gaji_pokok_per_hari'], 0, ',', '.') }}</td>
    <td style="width: 30px" class="border-right-0">Rp</td>
    <td style="width: 100px" class="text-right border-left-0">{{ number_format($gaji['gaji_pokok'], 0, ',', '.') }}</td>
  </tr>
  <tr>
    <td>Kehadiran Harian</td>
    <td class="text-center">{{ $gaji['kehadiran_harian_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['kehadiran_harian_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['kehadiran_harian'], 0, ',', '.') }}</td>
  </tr>
  <tr>
    <td>Tunjangan tambahan</td>
    <td class="text-center">{{ $gaji['tunj_tambahan_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['tunj_tambahan_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['tunj_tambahan'], 0, ',', '.') }}</td>
  </tr>
  <tr>
    <td>Bonus</td>
    <td class="text-center">{{ $gaji['bonus_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['bonus_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['bonus'], 0, ',', '.') }}</td>
  </tr>
  <tr>
    <td>Event Konser (Paid)</td>
    <td class="text-center">{{ $gaji['event_konser_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['event_konser_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['event_konser'], 0, ',', '.') }}</td>
  </tr>
  <tr>
    <td>Set Up Konser</td>
    <td class="text-center">{{ $gaji['set_up_konser_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['set_up_konser_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['set_up_konser'], 0, ',', '.') }}</td>
  </tr>
  <tr>
    <td>Set Down Konser</td>
    <td class="text-center">{{ $gaji['set_down_konser_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['set_down_konser_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['set_down_konser'], 0, ',', '.') }}</td>
  </tr>
  <tr>
    <td>Support</td>
    <td class="text-center">{{ $gaji['support_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['support_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['support'], 0, ',', '.') }}</td>
  </tr>
  <tr class="bg-secondary">
    <td class="text-center font-weight-bold border-right-0">Total</td>
    <td class="border-left-0 border-right-0" colspan="3"></td>
    <td class="border-right-0 font-weight-bold">Rp</td>
    <td class="text-right border-left-0 font-weight-bold">{{ number_format($gaji['total_1'], 0, ',', '.') }}</td>
  </tr>

  <tr>
    <td>Libur Cuti</td>
    <td class="text-center">{{ $gaji['libur_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['libur_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['libur'], 0, ',', '.') }}</td>
  </tr>
  <tr>
    <td>Sakit / Izin</td>
    <td class="text-center">{{ $gaji['sakit_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['sakit_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['sakit'], 0, ',', '.') }}</td>
  </tr>
  <tr>
    <td class="border-right-0">Kasbon</td>
    <td class="border-left-0" colspan="3"></td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['kasbon'], 0, ',', '.') }}</td>
  </tr>
  <tr class="bg-secondary">
    <td class="text-center font-weight-bold border-right-0">Total</td>
    <td class="border-left-0 border-right-0" colspan="3"></td>
    <td class="border-right-0 font-weight-bold">Rp</td>
    <td class="text-right border-left-0 font-weight-bold">{{ number_format($gaji['total_2'], 0, ',', '.') }}</td>
  </tr>
  <tr>
    <td>Lembur/Jam</td>
    <td class="text-center">{{ $gaji['lembur_jam_jml_jam'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['lembur_jam_per_jam'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['lembur_jam'], 0, ',', '.') }}</td>
  </tr>
  <tr>
    <td>Lembur Harian</td>
    <td class="text-center">{{ $gaji['lembur_hari_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['lembur_hari_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="text-right border-left-0">{{ number_format($gaji['lembur_hari'], 0, ',', '.') }}</td>
  </tr>
  <tr class="bg-secondary">
    <td class="text-center font-weight-bold border-right-0">Sub Total</td>
    <td class="border-left-0 border-right-0" colspan="3"></td>
    <td class="border-right-0 font-weight-bold">Rp</td>
    <td class="text-right border-left-0 font-weight-bold">{{ number_format($gaji['sub_total'], 0, ',', '.') }}</td>
  </tr>
  <tr class="bg-warning">
    <td class="text-center font-weight-bold border-right-0 py-2">Total Penerimaan</td>
    <td class="border-left-0 border-right-0 py-2" colspan="3"></td>
    <td class="border-right-0 font-weight-bold py-2">Rp</td>
    <td class="text-right border-left-0 font-weight-bold py-2">{{ number_format($gaji['total_penerimaan'], 0, ',', '.') }}</td>
  </tr>
  </tbody>
</table>
<p class="font-weight-bold mb-0">Notes:</p>
<p class="mt-1">{{ $gaji['notes'] ?: '-' }}</p>

<table class="table table-sm table-bordered">
  <thead>
  <tr class="bg-secondary">
    <th class="py-2 text-center">No</th>
    <th class="py-2 text-center">Nama Siswa</th>
    <th class="py-2 text-center">Durasi</th>
    <th class="py-2 text-center">Jumlah Pertemuan</th>
    <th class="py-2 text-center">Debut</th>
    <th class="py-2 text-center">Regular</th>
    <th class="py-2 text-center">Notes</th>
  </tr>
  </thead>
  <tbody>
  @php
    $debut = 0;
    $regular = 0;
  @endphp
  @foreach($mengajar as $no=>$d)
    @php
      $debut += $d['debut'];
      $regular += $d['regular'];
    @endphp
    <tr>
      <td class="text-center">{{ $no+1 }}</td>
      <td class="text-center">{{ $d['nama_siswa'] }}</td>
      <td class="text-center">{{ $d['durasi'] }} Menit</td>
      <td class="text-center">{{ $d['jumlah_pertemuan'] }}</td>
      <td class="text-center">{{ $d['debut'] }}</td>
      <td class="text-center">{{ $d['regular'] }}</td>
      <td class="text-center">{{ $d['notes'] }}</td>
    </tr>
  @endforeach
  </tbody>
</table>

<div>
  <table class="table table-sm table-bordered float-right" style="width: 25%">
    <thead>
    <tr class="bg-secondary">
      <th colspan="2" class="py-2">Total Kelas</th>
    </tr>
    </thead>
    <tbody>
    <tr>
      <td class="border-right-0" style="width: 70px">Debut</td>
      <td class="border-left-0">: {{ $debut }}</td>
    </tr>
    <tr>
      <td class="border-right-0">Regular</td>
      <td class="border-left-0">: {{ $regular }}</td>
    </tr>
    </tbody>
  </table>
</div>

<div class="text-center pb-3" style="page-break-before: always">
  <img src="{{ url('images/logo_kop.jpg') }}" alt="Logo" width="140px">
  <h5 class="text-center mb-0 pb-0">Absen Kerja</h5>
</div>
<div class="text-center">
  <table class="table table-sm table-bordered mb-0 mx-auto" style="width: 70%">
    <thead>
    <tr class="bg-secondary">
      <th class="text-center py-2" style="width: 70px">Tanggal</th>
      <th class="text-center py-2">Kehadiran</th>
      <th class="text-center py-2">Note</th>
    </tr>
    </thead>
    <tbody>
    @foreach($absensi['data'] as $tgl=>$t)
      <tr>
        <td class="text-center">{{ $tgl }}</td>
        @php
          $is_off = $t['kehadiran'] == 'OFF' && $t['note'] == 'OFF';
          $is_event = $t['kehadiran'] == 'EVENT';
        @endphp
        <td colspan="2" class="text-center bg-soft-danger text-center" style="display: {{ $is_off ? 'table-cell' : 'none' }};">
          OFF
        </td>
        <td class="p-1 text-center" style="display: {{ !$is_off ? 'table-cell' : 'none' }}">
          {{ $t['kehadiran'] }}
        </td>
        <td class="p-1 text-center" style="display: {{ !$is_off ? 'table-cell' : 'none' }}">
          {{ $t['note'] }}
        </td>
      </tr>
    @endforeach
    </tbody>
  </table>
</div>

@include('pdf.style')