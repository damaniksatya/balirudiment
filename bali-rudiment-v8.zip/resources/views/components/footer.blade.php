<footer class="footer" style="left: 260px">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        {{ date('Y') }} &copy; <strong>Bali Rudiment</strong>.
        {{--{{ date('Y') }} &copy; <strong>Bali Rudiment</strong>. Created with--}}
        {{--<i class="mdi mdi-heart-outline text-danger"></i> by <a href="https://laradev.id" target="_blank"></a>--}}
      </div>
    </div>
  </div>
</footer>