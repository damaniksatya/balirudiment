<?php

namespace App\Http\Controllers;

use App\Absensi;
use App\AbsensiSiswa;
use App\Instruktur;
use App\Jadwal;
use App\JadwalSiswa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AbsensiController extends Controller
{
  public function indexInstruktur()
  {
    $id_instruktur = Instruktur::getIdInstruktur();
    $data_bulan = Absensi::getArrBulanByInstruktur();
    $bulan = HelperController::getValue('bulan',['bulan'])['bulan'];
    $bulan = $bulan ?: (count($data_bulan) ? $data_bulan[0] : 'all');
    $data = Absensi::getDataByInstruktur($id_instruktur, $bulan);
//    dd($data);

    return view('pages.absensi.index_instruktur')
      ->with('data', $data)
      ->with('bulan', $bulan)
      ->with('data_bulan', $data_bulan);
  }

  public function indexSiswa()
  {
    $data_bulan = Absensi::getArrBulanBySiswa();
    $bulan = HelperController::getValue('bulan',['bulan'])['bulan'];
    $bulan = $bulan ?: (count($data_bulan) ? $data_bulan[0] : 'all');
    $data = Absensi::getDataBySiswa($bulan);
//    dd($data);

    return view('pages.absensi.index_siswa')
      ->with('data', $data)
      ->with('bulan', $bulan)
      ->with('data_bulan', $data_bulan);
  }

  public function indexMenungguKonfirmasi()
  {
    $data = Absensi::getDataMenungguKonfirmasi();
//    dd($data);

    return view('pages.absensi.menunggu_konfirmasi')
      ->with('data', $data);
  }

  public function indexDikonfirmasi()
  {
    $data_bulan = Absensi::getArrBulanDikonfirmasi();
    $bulan = HelperController::getValue('bulan',['bulan'])['bulan'];
    $bulan = $bulan ?: (count($data_bulan) ? $data_bulan[0] : 'all');
    $data = Absensi::getDataDikonfirmasi($bulan);

    return view('pages.absensi.dikonfirmasi')
      ->with('data', $data)
      ->with('bulan', $bulan)
      ->with('data_bulan', $data_bulan);
  }

  public function getComponentFormKonfirmasi(Request $req)
  {
    $data_absensi_siswa = AbsensiSiswa::getData($req->id_absensi);
//    return $data_absensi_siswa;
    return view('components.absensi.form_konfirmasi')
      ->with('data_absensi_siswa', $data_absensi_siswa)
      ->with('id_absensi', $req->id_absensi);
  }

  public function viewAdd()
  {
    $data_jadwal = Jadwal::getPilihanAbsensi();
//    dd($data_absensi);

    return view('pages.absensi.add')
      ->with('data_jadwal', $data_jadwal);
  }

  public function viewEdit($id_absensi)
  {
    $info = Absensi::getInfo($id_absensi);
    $data_siswa = AbsensiSiswa::getData($id_absensi);
//    dd($info, $data_absensi);

    return view('pages.absensi.edit')
      ->with('info', $info)
      ->with('data_siswa', $data_siswa);
  }

  public function viewDetail($id_absensi)
  {
    $info = Absensi::getInfo($id_absensi);
    $data_siswa = AbsensiSiswa::getData($id_absensi);
//    dd($info, $data_absensi);

    return view('pages.absensi.detail')
      ->with('info', $info)
      ->with('data_siswa', $data_siswa);
  }

  public function getComponentTableSiswa(Request $req)
  {
    $jadwal = explode('--', $req->id_jadwal);
    $id_jadwal = $jadwal[0];
    $tanggal = $jadwal[1];

    $data_siswa = JadwalSiswa::getSiswaByIdJadwal($id_jadwal, $tanggal);
    $durasi_mengajar = Jadwal::getDurasiMengajar($id_jadwal);
    return view('components.absensi.add')
      ->with('data_siswa', $data_siswa)
      ->with('durasi_mengajar', $durasi_mengajar);
  }

  public function store(Request $req)
  {
//    dd($req);
    DB::transaction(function () use ($req){
      $jadwal = explode('--', $req->id_jadwal);
      $id_jadwal = $jadwal[0];
      $tanggal = $jadwal[1];

      $id_absensi = Absensi::insertData([
        'id_jadwal' => $id_jadwal,
        'id_instruktur' => Instruktur::getIdInstruktur(),
        'report' => $req->report,
        'tanggal' => $tanggal,
        'durasi_mengajar' => $req->durasi_mengajar,
        'status' => Absensi::S_MENUNGGU_KONFIRMASI
      ]);

      foreach(json_decode($req->id_siswa) as $id_siswa){
        AbsensiSiswa::insertData([
          'id_absensi' => $id_absensi,
          'id_siswa' => $id_siswa,
          'kehadiran' => $req['kehadiran'.$id_siswa]
        ]);
      }
    });

    return back()->with('success','Berhasil menyimpan data');
  }

  public function update(Request $req)
  {
    DB::transaction(function () use ($req){
      Absensi::updateData([
        'id_absensi' => $req->id_absensi,
        'report' => $req->report
      ]);

      foreach(json_decode($req->id_siswa) as $id_siswa){
        AbsensiSiswa::updateData([
          'id_absensi' => $req->id_absensi,
          'id_siswa' => $id_siswa,
          'kehadiran' => $req['kehadiran'.$id_siswa]
        ]);
      }
    });

    return back()->with('success','Berhasil menyimpan data');
  }

  public function konfirmasi(Request $req)
  {
//    dd($req);
    DB::transaction(function () use ($req){
      $arr_id_siswa = json_decode($req->arr_id_siswa);
      $total_fee = 0;

      foreach($arr_id_siswa as $id_siswa){
        AbsensiSiswa::updateData([
          'id_absensi' => $req->id_absensi,
          'id_siswa' => $id_siswa,
          'fee' => $req["fee$id_siswa"]
        ]);
        $total_fee += $req["fee$id_siswa"];
      }

      Absensi::updateData([
        'id_absensi' => $req->id_absensi,
        'fee' => $total_fee,
        'status' => Absensi::S_DIKONFIRMASI
      ]);
    });

    return back()->with('success','Berhasil konfirmasi absensi');
  }
}
