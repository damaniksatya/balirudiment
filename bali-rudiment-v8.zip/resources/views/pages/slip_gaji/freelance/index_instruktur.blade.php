@extends('layouts.main')

@section('title','Data Slip Gaji Instruktur Freelance')

@php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_slip_gaji_instruktur_freelance);
  $nonaktif_cetak = in_array(\App\SettingMenu::CETAK_SLIP_GAJI_INSTRUKTUR_FREELANCE, $arr_nonaktif);
@endphp

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right mt-2 pt-1">
              </div>
              <h4 class="page-title">Data Slip Gaji Instruktur Freelance</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <div class="table-responsive">
              <table id="datatable" class="table mb-0 table-sm table-bordered">
                <thead>
                <tr>
                  <th class="text-center" style="width: 40px">No</th>
                  <th class="">Bulan</th>
                  <th class="">Total Mengajar</th>
                  <th class="">Ensemble</th>
                  <th class="">Bonus</th>
                  <th class="">Event</th>
                  <th class="">Total Penerimaan</th>
                  @if(!$nonaktif_cetak)
                    <th style="width: 120px" class="text">Aksi</th>
                  @endif
                </tr>
                </thead>
                <tbody>
                @foreach($data as $no=>$d)
                  <tr>
                    <td class="text-center">{{ $no+1 }}</td>
                    <td class="">{{ \App\Http\Controllers\HelperController::setNamaBulan($d['bulan']) }}</td>
                    <td class="text-right">{{ number_format($d['total_mengajar'], 0, ',', '.') }}</td>
                    <td class="text-right">{{ number_format($d['ensemble'], 0, ',', '.') }}</td>
                    <td class="text-right">{{ number_format($d['kinerja']+$d['week_20_hours'], 0, ',', '.') }}</td>
                    <td class="text-right">{{ number_format($d['konser']+$d['set_up_konser']+$d['set_down_konser']+$d['set_up_bw']+$d['set_down_bw'], 0, ',', '.') }}</td>
                    <td class="text-right font-weight-bold">{{ number_format($d['grand_total'], 0, ',', '.') }}</td>
                    @if(!$nonaktif_cetak)
                      <td>
                        <div class="btn-group btn-block">
                          <a href="{{ url('slip-gaji/freelance/print/'.$d['id_gaji']) }}" class="btn btn-sm btn-outline-primary" target="_blank">
                            <i class="mdi mdi-printer pr-2"></i>Cetak Slip Gaji
                          </a>
                        </div>
                      </td>
                    @endif
                  </tr>
                @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection
@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();
  </script>
@endsection