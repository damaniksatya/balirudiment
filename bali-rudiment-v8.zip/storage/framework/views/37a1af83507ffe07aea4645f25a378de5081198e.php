<link rel="stylesheet" href="<?php echo e(url('plugins/sweetalert/dist/sweetalert.css')); ?>">
<script src="<?php echo e(url('plugins/sweetalert/dist/sweetalert.min.js')); ?>"></script>
<script>
  <?php if(Session::has('success')): ?>
    !function($) {
      "use strict";
      var SweetAlert = function() {};

      SweetAlert.prototype.init = function() {
        swal({
          title: 'Berhasil',
          text: "<?php echo e(Session::get('success')); ?>",
          type: 'success',
          confirmButtonColor: '#306397',
          timer: 1500
        })
      },
      $.SweetAlert = new SweetAlert, $.SweetAlert.Constructor = SweetAlert
    }(window.jQuery),

    function($) {
      "use strict";
      $.SweetAlert.init()
    }(window.jQuery);
  <?php elseif(Session::has('success_stay')): ?>
    !function($) {
      "use strict";
      var SweetAlert = function() {};

      SweetAlert.prototype.init = function() {
        swal({
          title: 'Berhasil',
          text: "<?php echo e(Session::get('success_stay')); ?>",
          type: 'success',
          confirmButtonColor: '#306397'
        })
      },
      $.SweetAlert = new SweetAlert, $.SweetAlert.Constructor = SweetAlert
    }(window.jQuery),

    function($) {
      "use strict";
      $.SweetAlert.init()
    }(window.jQuery);
  <?php elseif(count($errors) > 0): ?>
    <?php
      $error_msg = [];
      foreach($errors->all() as $error){
        $error_msg[] = $error;
      }
    ?>

    !function($) {
      "use strict";
      var SweetAlert = function() {};

      SweetAlert.prototype.init = function() {
          swal({
              title: 'Gagal',
              text: "<?php echo e(implode('\n', $error_msg)); ?>",
              type: 'error',
              confirmButtonColor: '#306397'
          })
      },
      $.SweetAlert = new SweetAlert, $.SweetAlert.Constructor = SweetAlert
    }(window.jQuery),

    function($) {
      "use strict";
      $.SweetAlert.init()
    }(window.jQuery);
  <?php endif; ?>
</script>