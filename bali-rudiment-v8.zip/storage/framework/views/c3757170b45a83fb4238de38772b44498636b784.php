<?php $__env->startSection('title','Beranda'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row justify-content-center">
            <div class="col-lg-8">
              <h4 class="page-title">Beranda</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body text-center pt-5">
            <img src="<?php echo e(url('images/logo.jpg')); ?>" alt="Logo" width="120px">
            <p class="px-lg-5 pt-3">
              <h5 class="px-lg-5">
                Selamat datang
              </h5>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>