@extends('layouts.main')

@section('title','Input Data Studio')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="{{ url('studio') }}">Studio</a></li>
                  <li class="breadcrumb-item active">Input</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="{{ url('studio') }}">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input Studio
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="{{ url('studio') }}">
            @csrf
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="nama_studio">Nama Studio</label>
                <div class="col-lg-9">
                  <input type="text" id="nama_studio" name="nama_studio" value="{{ old('nama_studio') }}" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_penempatan">Penempatan</label>
                <div class="col-lg-9">
                  <select name="id_penempatan" id="id_penempatan" class="form-control select2">
                    <option value="">Pilih Penempatan</option>
                    @foreach($data_penempatan as $l)
                      <option value="{{ $l->id_penempatan }}" {{ old('id_penempatan') == $l->id_penempatan ? 'selected' : '' }}>{{ $l->nama_penempatan }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_instrumen">Instrumen</label>
                <div class="col-lg-9">
                  @php
                    $arr_id_instrumen = old('id_instrumen') ?: [];
                  @endphp
                  @foreach($data_instrumen as $d)
                    <div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input"
                             {{ in_array($d->id_instrumen, $arr_id_instrumen) ? 'checked' : '' }}
                             id="instrumen{{ $d->id_instrumen }}"
                             value="{{ $d->id_instrumen }}"
                             name="id_instrumen[]">
                      <label class="custom-control-label" style="cursor: pointer" for="instrumen{{ $d->id_instrumen }}">{{ $d->nama_instrumen }}</label>
                    </div>
                  @endforeach
                </div>
              </div>
            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();
  </script>
@endsection