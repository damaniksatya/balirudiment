@extends('layouts.main')

@section('title','Input/Edit Data Absensi')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="{{ url('slip-gaji/freelance') }}">Absensi</a></li>
                  <li class="breadcrumb-item active">Input/Edit</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="{{ url('slip-gaji/freelance') }}">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input/Edit Absensi
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <form class="row" method="post" action="{{ url('slip-gaji/freelance/absensi') }}">
      @csrf
      <input type="hidden" name="id_gaji_freelance" value="{{ $info->id_gaji }}">
      <input type="hidden" name="arr_tgl" value="{{ json_encode($arr_tgl) }}">
      <input type="hidden" name="bulan" value="{{ $info->bulan }}">
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body pb-0">
            <table class="mb-3">
              <tr>
                <td>Nama</td>
                <td class="text-center" style="width: 15px">:</td>
                <td>{{ $info->instruktur->nama_instruktur }}</td>
              </tr>
              <tr>
                <td>Bulan</td>
                <td class="text-center">:</td>
                <td>{{ \App\Http\Controllers\HelperController::setNamaBulan($info->bulan) }}</td>
              </tr>
            </table>
            <table class="table table-sm table-bordered mb-0">
              <thead>
              <tr>
                <th class="text-center">Tanggal</th>
                <th class="text-center">Kehadiran</th>
                <th class="text-center">Note</th>
                <th class="text-center">Off</th>
                <th class="text-center">Event</th>
              </tr>
              </thead>
              <tbody>
              @foreach($data['data'] as $tgl=>$t)
                <tr>
                  <td class="text-center">{{ $tgl }}</td>
                  @php
                    $is_off = $t['kehadiran'] == 'OFF' && $t['note'] == 'OFF';
                    $is_event = $t['kehadiran'] == 'EVENT';
                  @endphp
                  <td colspan="2" id="td-off-{{ $tgl }}" class="text-center bg-soft-danger" style="display: {{ $is_off ? 'table-cell' : 'none' }};">
                    <div style="padding: 3px">OFF</div>
                  </td>
                  <td class="p-1" id="td-kehadiran-{{ $tgl }}" style="display: {{ !$is_off ? 'table-cell' : 'none' }}">
                    <input type="text" class="form-control form-control-sm"
                           value="{{ $t['kehadiran'] ?: 'HADIR' }}"
                           {{--value="08.00"--}}
                           title="Kehadiran Tanggal {{ $tgl }}" name="kehadiran-{{ $tgl }}">
                  </td>
                  <td class="p-1" id="td-note-{{ $tgl }}" style="display: {{ !$is_off ? 'table-cell' : 'none' }}">
                    <input type="text" class="form-control form-control-sm"
                           value="{{ $t['note'] }}"
                           {{--value="17.00"--}}
                           title="Keluar Note {{ $tgl }}" name="note-{{ $tgl }}">
                  </td>
                  <td class="text-center">
                    <div class="custom-control custom-checkbox" style="margin-left: 7px; cursor: pointer">
                      <input type="checkbox" class="custom-control-input" id="off-{{ $tgl }}"
                             onchange="changeOff('{{ $tgl }}', this.checked)" {{ $is_off ? 'checked' : '' }}>
                      <label class="custom-control-label" style="cursor: pointer" for="off-{{ $tgl }}"></label>
                    </div>
                  </td>
                  <td class="text-center">
                    <div class="custom-control custom-checkbox" style="margin-left: 7px; cursor: pointer">
                      <input type="checkbox" class="custom-control-input" id="event-{{ $tgl }}"
                             onchange="changeEvent('{{ $tgl }}', this.checked)" {{ $is_event ? 'checked' : '' }}>
                      <label class="custom-control-label" style="cursor: pointer" for="event-{{ $tgl }}"></label>
                    </div>
                  </td>
                </tr>
              @endforeach
              </tbody>
            </table>
            {{--<div class="form-group">--}}
              {{--<label class="col-form-label" for="note">Note</label>--}}
              {{--<textarea name="note" id="note" class="form-control" rows="5">{{ $data['note'] }}</textarea>--}}
            {{--</div>--}}
          </div>
          <div class="card-body text-right">
            <button type="submit" class="btn btn-primary">Simpan</button>
          </div>
        </div>
      </div>
    </form>

  </div>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();

      function changeOff(tgl, is_checked) {
          // console.log(tgl, is_checked)
          $(`[name=kehadiran-${tgl}]`).val(is_checked ? 'OFF' : null);
          $(`[name=note-${tgl}]`).val(is_checked ? 'OFF' : null);

          if(is_checked){
              $(`#event-${tgl}`).prop('checked', false);
              $(`#td-off-${tgl}`).show();
              $(`#td-kehadiran-${tgl}`).hide();
              $(`#td-note-${tgl}`).hide();
          }
          else{
              $(`#td-off-${tgl}`).hide();
              $(`#td-kehadiran-${tgl}`).show();
              $(`#td-note-${tgl}`).show();
          }
      }

      function changeEvent(tgl, is_checked) {
          if(is_checked){
              $(`#off-${tgl}`).prop('checked', false);
              changeOff(tgl, false);
          }
          $(`[name=kehadiran-${tgl}]`).val(is_checked ? 'EVENT' : null);
      }
  </script>
@endsection