<title>Slip Gaji Staff {{ $gaji['instruktur']['nama_instruktur'] }} Bulan {{ $nama_bulan }}</title>

<div class="text-center pb-3">
  <img src="{{ url('images/logo_kop.jpg') }}" alt="Logo" width="140px">
</div>

<table class="w-100 mb-3">
  <tr>
    <td style="width: 60px">Bulan</td>
    <td style="width: 5px">:</td>
    <td>{{ $nama_bulan }}</td>
  </tr>
  <tr>
    <td>Nama</td>
    <td>:</td>
    <td>{{ $gaji['instruktur']['nama_instruktur'] }}</td>
  </tr>
</table>

<table class="table table-sm table-bordered">
  <thead>
  <tr class="bg-secondary">
    <th class="text-center" style="width: 25px">No</th>
    <th>Nama Siswa</th>
    <th style="width: 70px" class="text-center">Jumlah Pertemuan</th>
    <th class="text-center" colspan="2">Fee</th>
    <th class="text-center" colspan="2">Total</th>
    <th>Kelas</th>
    <th>Notes</th>
  </tr>
  </thead>
  <tbody>
  @foreach($mengajar as $index=>$t)
    <tr>
      <td class="text-center">{{ $index+1 }}</td>
      <td class="">{{ $t['nama_siswa'] }}</td>
      <td class="text-center">{{ $t['jumlah_pertemuan'] }}</td>
      <td class="border-right-0" style="width: 25px">Rp</td>
      <td class="border-left-0 text-right pl-0" style="width: 60px">{{ number_format($t['fee'], 0, ',', '.') }}</td>
      <td class="border-right-0" style="width: 25px">Rp</td>
      <td class="border-left-0 text-right pl-0" style="width: 60px">{{ number_format($t['total_fee'], 0, ',', '.') }}</td>
      <td class="">{{ $t['kelas'] }}</td>
      <td class="">{{ $t['notes'] }}</td>
    </tr>
  @endforeach
  <tr>
    <td colspan="2" class="text-center font-weight-bold border-right-0">TOTAL</td>
    <td colspan="3" class="border-left-0 border-right-0"></td>
    <td class="border-right-0 font-weight-bold">Rp</td>
    <td class="text-right font-weight-bold border-right-0 border-left-0">{{ number_format($gaji->total_mengajar, 0, ',', '.') }}</td>
    <td colspan="2" class="border-left-0"></td>
  </tr>
  <tr>
    <td colspan="2" class="text-center font-weight-bold">ENSEMBLE</td>
    <td class="text-center">{{ $gaji->ensemble_jml_hari }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji->ensemble_per_hari, 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji->ensemble, 0, ',', '.') }}</td>
    <td colspan="2">{{ $gaji->ensemble_note }}</td>
  </tr>
  <tr>
    <td colspan="2" class="text-center font-weight-bold">TRIAL</td>
    <td class="text-center">{{ $gaji['trial_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['trial_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['trial'], 0, ',', '.') }}</td>
    <td colspan="2">{{ $gaji['trial_note'] }}</td>
  </tr>
  <tr>
    <td colspan="2" class="text-center font-weight-bold">EXTRA LESSON</td>
    <td class="text-center">{{ $gaji['extra_lesson_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['extra_lesson_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['extra_lesson'], 0, ',', '.') }}</td>
    <td colspan="2">{{ $gaji['extra_lesson_note'] }}</td>
  </tr>
  <tr>
    <td colspan="2" class="text-center font-weight-bold">BONUS</td>
    <td colspan="7"></td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">Kinerja</td>
    <td class="text-center">{{ $gaji['kinerja_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['kinerja_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['kinerja'], 0, ',', '.') }}</td>
    <td colspan="2">{{ $gaji['kinerja_note'] }}</td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">20 Hours/week</td>
    <td class="text-center">{{ $gaji['week_20_hours_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['week_20_hours_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['week_20_hours'], 0, ',', '.') }}</td>
    <td colspan="2">{{ $gaji['week_20_hours_note'] }}</td>
  </tr>
  <tr>
    <td colspan="2" class="text-center font-weight-bold">EVENT</td>
    <td colspan="7"></td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">Konser</td>
    <td class="text-center">{{ $gaji['konser_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['konser_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['konser'], 0, ',', '.') }}</td>
    <td colspan="2">{{ $gaji['konser_note'] }}</td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">Set Up Konser</td>
    <td class="text-center">{{ $gaji['set_up_konser_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['set_up_konser_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['set_up_konser'], 0, ',', '.') }}</td>
    <td colspan="2">{{ $gaji['set_up_konser_note'] }}</td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">Set Down Konser</td>
    <td class="text-center">{{ $gaji['set_down_konser_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['set_down_konser_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['set_down_konser'], 0, ',', '.') }}</td>
    <td colspan="2">{{ $gaji['set_down_konser_note'] }}</td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">Set Up BW / LIPPO</td>
    <td class="text-center">{{ $gaji['set_up_bw_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['set_up_bw_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['set_up_bw'], 0, ',', '.') }}</td>
    <td colspan="2">{{ $gaji['set_up_bw_note'] }}</td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">Set Down BW / LIPPO</td>
    <td class="text-center">{{ $gaji['set_down_bw_jml_hari'] }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['set_down_bw_per_hari'], 0, ',', '.') }}</td>
    <td class="border-right-0">Rp</td>
    <td class="border-left-0 text-right">{{ number_format($gaji['set_down_bw'], 0, ',', '.') }}</td>
    <td colspan="2">{{ $gaji['set_down_bw_note'] }}</td>
  </tr>
  <tr>
    <td colspan="2" class="text-center font-weight-bold border-right-0">TOTAL</td>
    <td colspan="3" class="border-left-0 border-right-0"></td>
    <td class="border-right-0 font-weight-bold">Rp</td>
    <td class="text-right font-weight-bold border-right-0 border-left-0">{{ number_format($gaji->total, 0, ',', '.') }}</td>
    <td colspan="2" class="border-left-0"></td>
  </tr>
  <tr>
    <td colspan="2" class="text-center font-weight-bold border-right-0">KASBON</td>
    <td colspan="3" class="border-left-0 border-right-0"></td>
    <td class="border-right-0 font-weight-bold">Rp</td>
    <td class="text-right font-weight-bold border-right-0 border-left-0">{{ number_format($gaji->kasbon, 0, ',', '.') }}</td>
    <td colspan="2" class="border-left-0"></td>
  </tr>
  <tr>
    <td colspan="2" class="text-center font-weight-bold border-right-0">GRAND TOTAL</td>
    <td colspan="3" class="border-left-0 border-right-0"></td>
    <td class="border-right-0 font-weight-bold">Rp</td>
    <td class="text-right font-weight-bold border-right-0 border-left-0">{{ number_format($gaji->grand_total, 0, ',', '.') }}</td>
    <td colspan="2" class="border-left-0"></td>
  </tr>
  </tbody>
</table>

<div class="text-center pb-3" style="page-break-before: always">
  <img src="{{ url('images/logo_kop.jpg') }}" alt="Logo" width="140px">
  <h5 class="text-center mb-0 pb-0">Absen Kerja</h5>
</div>
<div class="text-center">
  <table class="table table-sm table-bordered mb-0 mx-auto" style="width: 70%">
    <thead>
    <tr class="bg-secondary">
      <th class="text-center py-2" style="width: 70px">Tanggal</th>
      <th class="text-center py-2">Kehadiran</th>
      <th class="text-center py-2">Note</th>
    </tr>
    </thead>
    <tbody>
    @foreach($absensi['data'] as $tgl=>$t)
      <tr>
        <td class="text-center">{{ $tgl }}</td>
        @php
          $is_off = $t['kehadiran'] == 'OFF' && $t['note'] == 'OFF';
          $is_event = $t['kehadiran'] == 'EVENT';
        @endphp
        <td colspan="2" class="text-center bg-soft-danger text-center" style="display: {{ $is_off ? 'table-cell' : 'none' }};">
          OFF
        </td>
        <td class="p-1 text-center" style="display: {{ !$is_off ? 'table-cell' : 'none' }}">
          {{ $t['kehadiran'] }}
        </td>
        <td class="p-1 text-center" style="display: {{ !$is_off ? 'table-cell' : 'none' }}">
          {{ $t['note'] }}
        </td>
      </tr>
    @endforeach
    </tbody>
  </table>
</div>

@include('pdf.style')