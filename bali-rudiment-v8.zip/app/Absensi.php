<?php

namespace App;

use App\Http\Controllers\JadwalController;
use Illuminate\Database\Eloquent\Model;

class Absensi extends Model
{
  protected $table = 'absensi';
  public $timestamps = false;
  protected $primaryKey = 'id_absensi';

  const K_HADIR = 'HADIR';
  const K_IZIN = 'IZIN';
  const K_SAKIT = 'SAKIT';
  const K_TIDAK_HADIR = 'TIDAK HADIR';

  const S_MENUNGGU_KONFIRMASI = 'MENUNGGU KONFIRMASI';
  const S_DIKONFIRMASI = 'DIKONFIRMASI';

  public static $arr_tidak_hadir = [
    self::K_IZIN,
    self::K_SAKIT,
    self::K_TIDAK_HADIR
  ];

  public static $color = [
    self::K_HADIR => 'success',
    self::K_IZIN => 'primary',
    self::K_SAKIT => 'purple',
    self::K_TIDAK_HADIR => 'danger',
    self::S_MENUNGGU_KONFIRMASI => 'primary',
    self::S_DIKONFIRMASI => 'success',
    '' => ''
  ];

  public static function getInfo($id_absensi)
  {
    $info = self::where('id_absensi', $id_absensi)->first();
    $info->jadwal = Jadwal::getInfo($info->id_jadwal);

    return $info;
  }

  public static function getDataDikonfirmasi($bulan)
  {
    $get = self::where('status', self::S_DIKONFIRMASI)
      ->where('tanggal','like',"$bulan%")
      ->orderBy('tanggal','ASC')
      ->get();

    foreach($get as $index=>$g){
      $get[$index]['jadwal'] = Jadwal::getInfo($g->id_jadwal);
    }

    return $get;
  }

  public static function getDataByInstruktur($id_instruktur, $bulan = null)
  {
    if($bulan == null){
      $get = self::where('id_instruktur', $id_instruktur)->get();
    }
    else{
      $get = self::where('id_instruktur', $id_instruktur)
        ->where('tanggal','like',"$bulan%")
        ->get();
    }

    foreach($get as $index=>$g){
      $get[$index]['jadwal'] = Jadwal::getInfo($g->id_jadwal);
      $get[$index]['hari'] = ucfirst(strtolower(JadwalController::getHariDariTanggal($g->tanggal)));
    }

    return $get;
  }

  public static function getDataBySiswa($bulan)
  {
    $id_siswa = Siswa::getIdSiswa();
    $get = self::leftJoin('absensi_siswa as abs','abs.id_absensi','=','absensi.id_absensi')
      ->leftJoin('instruktur as i','i.id_instruktur','=','absensi.id_instruktur')
      ->where('abs.id_siswa', $id_siswa)
      ->where('absensi.tanggal','like', "$bulan%")
      ->select('abs.*','absensi.*','i.nama_instruktur')
      ->orderBy('absensi.id_absensi','DESC')
      ->get();

    foreach($get as $index=>$g){
      $get[$index]['jadwal'] = Jadwal::getInfo($g->id_jadwal);
      $get[$index]['hari'] = ucfirst(strtolower(JadwalController::getHariDariTanggal($g->tanggal)));
      $temp = JadwalSiswa::getInfo($g->tanggal, $g->id_siswa, $g->id_jadwal);
      $get[$index]['jam_mulai'] = $temp->jam_mulai;
      $get[$index]['jam_selesai'] = $temp->jam_selesai;
    }

    return $get;
  }

  public static function getDataMenungguKonfirmasi()
  {
    $get = self::leftJoin('instruktur as i','i.id_instruktur','=','absensi.id_instruktur')
      ->where('absensi.status', self::S_MENUNGGU_KONFIRMASI)
      ->select('absensi.*','i.nama_instruktur')
      ->orderBy('absensi.id_absensi','DESC')
      ->get();

    foreach($get as $index=>$g){
      $get[$index]['jadwal'] = Jadwal::getInfo($g->id_jadwal);
      $get[$index]['hari'] = ucfirst(strtolower(JadwalController::getHariDariTanggal($g->tanggal)));
    }

    return $get;
  }

  public static function getArrBulanByInstruktur()
  {
    $id_instruktur = Instruktur::getIdInstruktur();
    return self::where('id_instruktur', $id_instruktur)
      ->selectRaw("SUBSTRING(tanggal, 1, 7) as bulan")
      ->groupBy('bulan')
      ->orderBy('bulan','DESC')
      ->pluck('bulan')
      ->toArray();
  }

  public static function getArrBulanBySiswa()
  {
    $id_siswa = Siswa::getIdSiswa();
    return self::leftJoin('absensi_siswa as abs','abs.id_absensi','=','absensi.id_absensi')
      ->where('abs.id_siswa', $id_siswa)
      ->selectRaw("SUBSTRING(absensi.tanggal, 1, 7) as bulan")
      ->groupBy('bulan')
      ->orderBy('bulan','DESC')
      ->pluck('bulan')
      ->toArray();
  }

  public static function getArrBulanDikonfirmasi()
  {
    return self::where('status', self::S_DIKONFIRMASI)
      ->selectRaw("SUBSTRING(tanggal, 1, 7) as bulan")
      ->groupBy('bulan')
      ->orderBy('bulan','DESC')
      ->pluck('bulan')
      ->toArray();
  }

  public static function getJumlahMenungguKonfirmasi()
  {
    return self::where('status', self::S_MENUNGGU_KONFIRMASI)->count();
  }

  public static function insertData($data)
  {
    $keys = array_keys($data);
    $new = new self();
    foreach($keys as $key){
      $new->$key = $data[$key];
    }
    $new->save();

    return $new->id_absensi;
  }

  public static function updateData($data)
  {
    self::where('id_absensi', $data['id_absensi'])->update($data);
  }
}
