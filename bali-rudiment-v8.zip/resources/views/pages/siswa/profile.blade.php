@extends('layouts.main')

@section('title','Ubah Profil')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/dropify/css/dropify.css') }}">
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                {{--<ol class="breadcrumb m-0">--}}
                  {{--<li class="breadcrumb-item"><a href="{{ url('siswa') }}">Siswa</a></li>--}}
                  {{--<li class="breadcrumb-item active">Edit</li>--}}
                {{--</ol>--}}
              </div>
              <h4 class="page-title">
                {{--<a href="{{ url('siswa') }}">--}}
                  {{--<i class="mdi mdi-arrow-left mr-1 text-primary"></i>--}}
                {{--</a>--}}
                Ubah Profil
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="{{ url('siswa/profile') }}" enctype="multipart/form-data">
            @csrf @method('put')
            <input type="hidden" name="id_pengguna" value="{{ $info->id_pengguna }}">
            <input type="hidden" name="username_old" value="{{ $info->username }}">
            <input type="hidden" name="email_siswa_old" value="{{ $info->email_siswa }}">
            <input type="hidden" name="foto_profile_old" value="{{ $info->foto_profile }}">

            <input type="hidden" name="nama_siswa" value="{{ $info->nama_siswa }}">
            <input type="hidden" name="id_penempatan" value="{{ $info->id_penempatan }}">
            <input type="hidden" name="id_kelas" value="{{ $info->id_kelas }}">
            <input type="hidden" name="id_instrumen" value="{{ $info->id_instrumen }}">
            <input type="hidden" name="tanggal_lahir" value="{{ $info->tanggal_lahir }}">
            <input type="hidden" name="sekolah" value="{{ $info->sekolah }}">
            <input type="hidden" name="jenis_kelamin" value="{{ $info->jenis_kelamin }}">
            <input type="hidden" name="tangan_dominan" value="{{ $info->tangan_dominan }}">

            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="email_siswa">Email Siswa</label>
                <div class="col-lg-9">
                  <input type="text" id="email_siswa" name="email_siswa" value="{{ old('email_siswa') ?: $info->email_siswa }}" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="alamat">Alamat</label>
                <div class="col-lg-9">
                  <textarea name="alamat" id="alamat" class="form-control" required rows="5">{{ old('alamat') ?: $info->alamat }}</textarea>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="email_orangtua">Email Orang Tua</label>
                <div class="col-lg-9">
                  <input type="text" id="email_orangtua" name="email_orangtua" value="{{ old('email_orangtua') ?: $info->email_orangtua }}" class="form-control">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="no_hp_orangtua">No HP Orang Tua</label>
                <div class="col-lg-9">
                  <input type="text" id="no_hp_orangtua" name="no_hp_orangtua" value="{{ old('no_hp_orangtua') ?: $info->no_hp_orangtua }}" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="username">Username Login</label>
                <div class="col-lg-9">
                  <input type="text" id="username" name="username" value="{{ old('username') ?: $info->username }}" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="foto_profile">Foto Profil</label>
                <div class="col-lg-9">
                  <input type="file"
                         name="foto_profile"
                         class="dropify dropify-photo"
                         data-height="150"
                         data-show-remove="false"
                         data-allowed-file-extensions="jpg jpeg png"
                         data-max-file-size="1M"
                         {{ $info['foto_profile'] ? 'data-default-file='.url($info['foto_profile']) : '' }}
                         accept=".jpg, .jpeg, .png" />
                </div>
              </div>
              @php
                $sosial_media = (array)json_decode($info->sosial_media);
                $instagram = is_array($sosial_media) && array_key_exists('instagram', $sosial_media) ? $sosial_media['instagram'] : '';
                $twitter = is_array($sosial_media) && array_key_exists('twitter', $sosial_media) ? $sosial_media['twitter'] : '';
                $facebook = is_array($sosial_media) && array_key_exists('facebook', $sosial_media) ? $sosial_media['facebook'] : '';
                $youtube = is_array($sosial_media) && array_key_exists('youtube', $sosial_media) ? $sosial_media['youtube'] : '';
              @endphp
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="sosial-media">Sosial Media</label>
                <div class="col-lg-9">
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-20" id="instagram" style="padding: 2px 10px"><i class="mdi mdi-instagram"></i></span>
                    </div>
                    <input type="text" id="instagram" name="instagram" value="{{ old('instagram') ?: $instagram }}" class="form-control" title="Instagram">
                  </div>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-20" id="twitter" style="padding: 2px 10px"><i class="mdi mdi-twitter"></i></span>
                    </div>
                    <input type="text" id="twitter" name="twitter" value="{{ old('twitter') ?: $twitter }}" class="form-control" title="Twitter">
                  </div>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-20" id="facebook" style="padding: 2px 10px"><i class="mdi mdi-facebook"></i></span>
                    </div>
                    <input type="text" id="facebook" name="facebook" value="{{ old('facebook') ?: $facebook }}" class="form-control" title="Facebook">
                  </div>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-20" id="youtube" style="padding: 2px 10px"><i class="mdi mdi-youtube"></i></span>
                    </div>
                    <input type="text" id="youtube" name="youtube" value="{{ old('youtube') ?: $youtube }}" class="form-control" title="Youtube">
                  </div>
                </div>
              </div>

            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.datepicker')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/dropify/js/dropify.min.js') }}"></script>
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(document).ready(function(){
          $(".select2").select2();
          $('.dropify-photo').dropify({
              messages: {
                  'default': 'Drag & drop foto di sini atau klik',
                  'replace': 'Drag & drop atau klik untuk mengganti foto',
                  'error': 'Hanya format png/jpeg/jpg yang di izinkan'
              },
              error: {
                  'fileSize': 'Ukuran foto melebihi maksimal (1M max).',
              }
          });
      });
      function disableAutoComplete() {
          $("#password").val('');
      }

      setTimeout(disableAutoComplete, 500);
  </script>
@endsection