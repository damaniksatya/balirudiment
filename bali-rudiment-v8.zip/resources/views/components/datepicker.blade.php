<link href="{{ url('libs/bootstrap-datepicker/bootstrap-datepicker.min.css') }}" rel="stylesheet">
<script src="{{ url('libs/bootstrap-datepicker/bootstrap-datepicker.min.js') }}"></script>
<script>
    $('.datepicker').datepicker({
        autoclose: true,
        format: "dd-mm-yyyy",
        clearBtn: true,
    });
</script>
<style>
  .datepicker-dropdown{
    z-index: 1001 !important;
  }
</style>