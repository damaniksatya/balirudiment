<ul class="list-unstyled topnav-menu float-right mb-0">
  <li class="dropdown notification-list">
    <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
      @if(Auth::user()->foto_profile != null)
        <img src="{{ url(Auth::user()->foto_profile) }}" alt="user-image" class="rounded-circle">
      @endif
      <span class="d-none d-sm-inline-block ml-1 font-weight-medium">{{ Auth::user()->nama }}</span>
      <i class="mdi mdi-chevron-down d-none d-sm-inline-block"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
      @php
        if(Auth::user()->level_user == \App\User::L_ADMIN || Auth::user()->level_user == \App\User::L_GENERAL_ADMIN){
          $link_profile = 'admin/profile';
        }
        elseif (Auth::user()->level_user == \App\User::L_ACCOUNTING){
          $link_profile = 'accounting/profile';
        }
        elseif (Auth::user()->level_user == \App\User::L_INSTRUKTUR){
          $link_profile = 'instruktur/profile';
        }
        else{
          $link_profile = 'siswa/profile';
        }
      @endphp
      <a href="{{ url($link_profile) }}" class="dropdown-item notify-item" id="btn-ubah-profil">
        <i class="mdi mdi-account"></i>
        <span>Ubah Profil</span>
      </a>
      <a href="{{ url('password') }}" class="dropdown-item notify-item" id="btn-ubah-kata-sandi">
        <i class="mdi mdi-lock-outline"></i>
        <span>Ubah Kata Sandi</span>
      </a>
      <div class="dropdown-divider"></div>
      <form action="{{ url('logout') }}" method="post">
        @csrf
        <button class="dropdown-item notify-item">
          <i class="mdi mdi-logout-variant"></i>
          <span>Keluar</span>
        </button>
      </form>
    </div>
  </li>
</ul>

{{--<div class="logo-box">--}}
{{--<a href="index.html" class="logo text-center logo-dark">--}}
{{--<span class="logo-lg">--}}
{{--<img src="{{ url('public/images/logo.png') }}" alt="" height="22">--}}
{{--</span>--}}
{{--<span class="logo-sm">--}}
{{--<img src="{{ url('public/images/logo-sm.png') }}" alt="" height="24">--}}
{{--</span>--}}
{{--</a>--}}
{{--</div>--}}

<ul class="list-unstyled topnav-menu topnav-menu-left m-0">
  <li>
    <button class="button-menu-mobile waves-effect waves-light">
      <i class="mdi mdi-menu"></i>
    </button>
  </li>
</ul>