<?php $__env->startSection('title','Pengubahan Jadwal Menunggu Konfirmasi'); ?>

<?php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_pengubahan_jadwal);
  $nonaktif_konfirmasi = in_array(\App\SettingMenu::KONFIRMASI_PENGUBAHAN_JADWAL, $arr_nonaktif);
?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              
                
                  
                  
                
              
              <h4 class="page-title">
                
                  
                
                Pengubahan Jadwal Menunggu Konfirmasi
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <?php if(count($data_menunggu)): ?>
        <?php $__currentLoopData = $data_menunggu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-12">
            <div class="card">
              <div class="card-body">
                <table>
                  <tr>
                    <?php if($d->siswa->foto_profile != null): ?>
                      <td style="width: 55px; padding-right: 10px" class="border-0 py-0 pl-0">
                        <div style="background: url('<?php echo e(url($d->siswa->foto_profile)); ?>'); height: 45px;
                          padding-top: 50%;
                          padding-bottom: 50%;
                          background-position: 50% !important;
                          background-size: cover !important;
                          border-radius: 50%"></div>
                      </td>
                    <?php endif; ?>
                    <td class="border-0 pl-0 font-weight-bold"><?php echo e($d->siswa->nama_siswa); ?></td>
                  </tr>
                </table>
                <table class="table table-sm table-borderless mt-2">
                  <tr>
                    <td class="border-top-0" style="width: 150px">Email Siswa</td>
                    <td class="px-0" style="width: 5px">:</td>
                    <td><?php echo e($d->siswa->email_siswa); ?></td>
                  </tr>
                  <tr>
                    <td>No HP Orang Tua</td>
                    <td class="px-0">:</td>
                    <td><?php echo e($d->siswa->no_hp_orangtua); ?></td>
                  </tr>
                  <tr>
                    <td>Status Pengajuan</td>
                    <td class="px-0">:</td>
                    <td>
                      <span class="badge badge-<?php echo e(\App\JadwalPengubahan::$color[$d->status]); ?>" style="padding-top: 5px"><?php echo e($d->status); ?></span>
                    </td>
                  </tr>
                  <tr>
                    <td>Waktu Pengajuan</td>
                    <td class="px-0">:</td>
                    <td><?php echo e(\App\Http\Controllers\HelperController::setNamaWaktu($d->waktu_pengajuan)); ?></td>
                  </tr>
                </table>

                <div class="row">
                  <div class="col-lg-6">
                    <strong>Jadwal sebelum diubah</strong>
                    <div class="card shadow-none mt-2 mb-0" style="background-color: rgba(0, 0, 0, 0.07)">
                      <div class="card-body">
                        <table class="table table-sm table-borderless mb-0">
                          <tr>
                            <td style="width: 100px">Hari</td>
                            <td class="px-0" style="width: 5px">:</td>
                            <td><?php echo e($d->jadwal_sebelum->hari); ?></td>
                          </tr>
                          <tr>
                            <td>Tanggal</td>
                            <td class="px-0">:</td>
                            <td><?php echo e(date('d-m-Y', strtotime($d->tanggal_sebelum))); ?></td>
                          </tr>
                          <tr>
                            <td>Jam</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jam_sebelum); ?></td>
                          </tr>
                          <tr>
                            <td>Studio</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_sebelum->nama_studio); ?></td>
                          </tr>
                          <tr>
                            <td>Instrumen</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_sebelum->nama_instrumen); ?></td>
                          </tr>
                          <tr>
                            <td>Instruktur</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_sebelum->nama_instruktur); ?></td>
                          </tr>
                        </table>
                      </div>
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <strong>Jadwal setelah diubah</strong>
                    <div class="card shadow-none mt-2 mb-0" style="background-color: rgba(0, 0, 0, 0.07)">
                      <div class="card-body">
                        <table class="table table-sm table-borderless mb-0">
                          <tr>
                            <td style="width: 100px">Hari</td>
                            <td class="px-0" style="width: 5px">:</td>
                            <td><?php echo e($d->jadwal_setelah->hari); ?></td>
                          </tr>
                          <tr>
                            <td>Tanggal</td>
                            <td class="px-0">:</td>
                            <td><?php echo e(date('d-m-Y', strtotime($d->tanggal_setelah))); ?></td>
                          </tr>
                          <tr>
                            <td>Jam</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jam_setelah); ?></td>
                          </tr>
                          <tr>
                            <td>Studio</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_setelah->nama_studio); ?></td>
                          </tr>
                          <tr>
                            <td>Instrumen</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_setelah->nama_instrumen); ?></td>
                          </tr>
                          <tr>
                            <td>Instruktur</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_setelah->nama_instruktur); ?></td>
                          </tr>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>

                <?php if(!$nonaktif_konfirmasi): ?>
                  <div class="col-lg-12 px-0 pt-3 text-right">
                    <button class="btn btn-danger" onclick="tolak('<?php echo e($d->id_jadwal_pengubahan); ?>')">Tolak</button>
                    <button class="btn btn-primary" onclick="konfirmasi('<?php echo e($d->id_jadwal_pengubahan); ?>')">Konfirmasi</button>
                  </div>
                <?php endif; ?>

              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <p class="text-center mb-0">Semua pengajuan pengubahan telah dikonfirmasi</p>
            </div>
          </div>
        </div>
      <?php endif; ?>
    </div>

    <div class="row">
      <?php if(count($data_ditolak)): ?>
        <div class="col-lg-12">
          <h6 class="mb-3">Pengajuan Pengubahan Jadwal Ditolak</h6>
        </div>
        <?php $__currentLoopData = $data_ditolak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-6">
            <div class="card">
              <div class="card-body">
                <table>
                  <tr>
                    <?php if($d->siswa->foto_profile != null): ?>
                      <td style="width: 55px; padding-right: 10px" class="border-0 py-0 pl-0">
                        <div style="background: url('<?php echo e(url($d->siswa->foto_profile)); ?>'); height: 45px;
                          padding-top: 50%;
                          padding-bottom: 50%;
                          background-position: 50% !important;
                          background-size: cover !important;
                          border-radius: 50%"></div>
                      </td>
                    <?php endif; ?>
                    <td class="border-0 pl-0 font-weight-bold"><?php echo e($d->siswa->nama_siswa); ?></td>
                  </tr>
                </table>
                <table class="table table-sm table-borderless mt-2">
                  <tr>
                    <td class="border-top-0" style="width: 150px">Email Siswa</td>
                    <td class="px-0" style="width: 5px">:</td>
                    <td><?php echo e($d->siswa->email_siswa); ?></td>
                  </tr>
                  <tr>
                    <td>No HP Orang Tua</td>
                    <td class="px-0">:</td>
                    <td><?php echo e($d->siswa->no_hp_orangtua); ?></td>
                  </tr>
                  <tr>
                    <td>Status Pengajuan</td>
                    <td class="px-0">:</td>
                    <td>
                      <span class="badge badge-<?php echo e(\App\JadwalPengubahan::$color[$d->status]); ?>" style="padding-top: 5px"><?php echo e($d->status); ?></span>
                    </td>
                  </tr>
                  <tr>
                    <td>Waktu Pengajuan</td>
                    <td class="px-0">:</td>
                    <td><?php echo e(\App\Http\Controllers\HelperController::setNamaWaktu($d->waktu_pengajuan)); ?></td>
                  </tr>
                </table>

                <div class="row">
                  <div class="col-lg-12">
                    <strong>Jadwal sebelum diubah</strong>
                    <div class="card shadow-none mt-2 mb-0" style="background-color: rgba(0, 0, 0, 0.07)">
                      <div class="card-body">
                        <table class="table table-sm table-borderless mb-0">
                          <tr>
                            <td style="width: 100px">Hari</td>
                            <td class="px-0" style="width: 5px">:</td>
                            <td><?php echo e($d->jadwal_sebelum->hari); ?></td>
                          </tr>
                          <tr>
                            <td>Tanggal</td>
                            <td class="px-0">:</td>
                            <td><?php echo e(date('d-m-Y', strtotime($d->tanggal_sebelum))); ?></td>
                          </tr>
                          <tr>
                            <td>Jam</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_sebelum->jam_mulai .'-'. $d->jadwal_sebelum->jam_selesai); ?></td>
                          </tr>
                          <tr>
                            <td>Studio</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_sebelum->nama_studio); ?></td>
                          </tr>
                          <tr>
                            <td>Instrumen</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_sebelum->nama_instrumen); ?></td>
                          </tr>
                          <tr>
                            <td>Instruktur</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_sebelum->nama_instruktur); ?></td>
                          </tr>
                        </table>
                      </div>
                    </div>
                  </div>

                  <div class="col-lg-12 pt-2">
                    <strong>Jadwal setelah diubah</strong>
                    <div class="card shadow-none mt-2 mb-0" style="background-color: rgba(0, 0, 0, 0.07)">
                      <div class="card-body">
                        <table class="table table-sm table-borderless mb-0">
                          <tr>
                            <td style="width: 100px">Hari</td>
                            <td class="px-0" style="width: 5px">:</td>
                            <td><?php echo e($d->jadwal_setelah->hari); ?></td>
                          </tr>
                          <tr>
                            <td>Tanggal</td>
                            <td class="px-0">:</td>
                            <td><?php echo e(date('d-m-Y', strtotime($d->tanggal_setelah))); ?></td>
                          </tr>
                          <tr>
                            <td>Jam</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_setelah->jam_mulai .'-'. $d->jadwal_setelah->jam_selesai); ?></td>
                          </tr>
                          <tr>
                            <td>Studio</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_setelah->nama_studio); ?></td>
                          </tr>
                          <tr>
                            <td>Instrumen</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_setelah->nama_instrumen); ?></td>
                          </tr>
                          <tr>
                            <td>Instruktur</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_setelah->nama_instruktur); ?></td>
                          </tr>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>

  </div>

  <form action="<?php echo e(url('pengubahan-jadwal/konfirmasi')); ?>" method="post" id="form-konfirmasi">
    <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
    <input type="hidden" name="id_jadwal_pengubahan" id="id-konfirmasi">
  </form>

  <form action="<?php echo e(url('pengubahan-jadwal/tolak')); ?>" method="post" id="form-tolak">
    <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
    <input type="hidden" name="id_jadwal_pengubahan" id="id-tolak">
  </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(document).ready(function(){
          $(".select2").select2();
      });

      function konfirmasi(id_jadwal) {
          swal({
              title: "Konfirmasi Pengajuan Pengubahan Jadwal?",
              text: "Pengajuan yang dikonfirmasi akan dilanjutkan ke tahap selanjutnya",
              type: "warning",
              showCancelButton: true,
              confirmButtonColor: "#306397",
              confirmButtonText: "Konfirmasi",
              cancelButtonText: "Batalkan",
              closeOnConfirm: false
          }, function(){
              $("#id-konfirmasi").val(id_jadwal);
              $("#form-konfirmasi").submit();
          });
      }

      function tolak(id_jadwal) {
          swal({
              title: "Tolak Pengajuan Pengubahan Jadwal?",
              text: "Tidak ada perubahan jadwal yang terjadi jika pengajuan pengubahan ditolak!",
              type: "warning",
              showCancelButton: true,
              confirmButtonColor: "#E62129",
              confirmButtonText: "Ya, Tolak!",
              cancelButtonText: "Kembali",
              closeOnConfirm: false
          }, function(){
              $("#id-tolak").val(id_jadwal);
              $("#form-tolak").submit();
          });
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>