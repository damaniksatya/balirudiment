<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GajiStaff extends Model
{
  protected $table = 'gaji_staff';
  public $timestamps = false;
  protected $primaryKey = 'id_gaji';

  public static function getData($bulan)
  {
    if($bulan == null){
      return self::all();
    }
    else{
      return self::where('dari_bulan', $bulan)
        ->orWhere('sampai_bulan', $bulan)
        ->get();
    }
  }

  public static function getInfo($id_gaji)
  {
    return self::where('id_gaji', $id_gaji)->first();
  }

  public static function getArrBulan()
  {
    $dari_bulan = self::groupBy('dari_bulan')->pluck('dari_bulan')->toArray();
    $sampai_bulan = self::groupBy('sampai_bulan')->pluck('sampai_bulan')->toArray();
    foreach($dari_bulan as $d){
      if(!in_array($d, $sampai_bulan)){
        $sampai_bulan[] = $d;
      }
    }
    rsort($sampai_bulan);
    return $sampai_bulan;
  }

  public static function getTotalByBulan($bulan)
  {
    return self::where('sampai_bulan', $bulan)
      ->selectRaw("SUM(total_penerimaan) as total")
      ->first()->total;
  }

  public static function insertData($data)
  {
    $keys = array_keys($data);
    $new = new self();
    foreach($keys as $key){
      $new->$key = $data[$key];
    }
    $new->save();

    return $new->id_gaji;
  }

  public static function updateData($data)
  {
    self::where('id_gaji', $data['id_gaji'])->update($data);
  }

  public static function deleteData($id_gaji)
  {
    self::where('id_gaji', $id_gaji)->delete();
  }
}
