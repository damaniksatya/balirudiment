@extends('layouts.main')

@section('title','Input Data Slip Gaji Instruktur Full Time')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="{{ url('slip-gaji/fulltime') }}">Slip Gaji Instruktur Full Time</a></li>
                  <li class="breadcrumb-item active">Input</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="{{ url('slip-gaji/fulltime') }}">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input Slip Gaji Instruktur Full Time
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="{{ url('slip-gaji/fulltime') }}">
            @csrf
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="bulan">Bulan</label>
                <div class="col-lg-9">
                  <input type="month" id="bulan" title="Bulan" name="bulan"
                         value="{{ old('bulan') ?: date('Y-m') }}" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_instruktur">Nama Instruktur</label>
                <div class="col-lg-9">
                  <select name="id_instruktur" id="id_instruktur" class="form-control select2" required>
                    <option value="">Pilih Instruktur</option>
                    @foreach($data_instruktur as $d)
                      <option value="{{ $d->id_instruktur }}" {{ old('id_instruktur') == $d->id_instruktur ? 'selected' : '' }}>{{ $d->nama_instruktur }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
              <div class="form-group row mb-0">
                <label class="col-lg-3 text-right col-form-label" for="jabatan">Jabatan</label>
                <div class="col-lg-9">
                  <input type="text" id="jabatan" name="jabatan" value="{{ old('jabatan') ?: 'Instruktur Trainee' }}" class="form-control" required>
                </div>
              </div>
            </div>
            <div class="card-body pb-0">
              <table class="table table-sm table-bordered mb-0">
                <thead>
                <tr>
                  <th>Keterangan</th>
                  <th class="text-center" style="width: 70px">Jumlah</th>
                  <th class="text-center" style="width: 150px">Nominal</th>
                  <th class="text-center">Total</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>Gaji Pokok</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Gaji Pokok"
                           name="gaji_pokok_jml_hari" value="{{ old('gaji_pokok_jml_hari') }}" oninput="calculateGaji()">
                    <input type="hidden" name="gaji_pokok" id="gaji_pokok_hidden" value="{{ old('gaji_pokok') }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Gaji Pokok Per Hari"
                           name="gaji_pokok_per_hari" value="{{ old('gaji_pokok_per_hari') }}" oninput="calculateGaji()">
                  </td>
                  <td id="gaji_pokok_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Kehadiran Harian</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Kehadiran Harian"
                           name="kehadiran_harian_jml_hari" value="{{ old('kehadiran_harian_jml_hari') }}" oninput="calculateGaji()">
                    <input type="hidden" name="kehadiran_harian" id="kehadiran_harian_hidden" value="{{ old('kehadiran_harian') }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Kehadiran Harian Per Hari"
                           name="kehadiran_harian_per_hari" value="{{ old('kehadiran_harian_per_hari') ?: 77000 }}" oninput="calculateGaji()">
                  </td>
                  <td id="kehadiran_harian_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Tunjangan Tambahan</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Tunjangan Tambahan"
                           name="tunj_tambahan_jml_hari" value="{{ old('tunj_tambahan_jml_hari') }}" oninput="calculateGaji()">
                    <input type="hidden" name="tunj_tambahan" id="tunj_tambahan_hidden" value="{{ old('tunj_tambahan') }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Tunjangan Tambahan Per Hari"
                           name="tunj_tambahan_per_hari" value="{{ old('tunj_tambahan_per_hari') ?: 21000 }}" oninput="calculateGaji()">
                  </td>
                  <td id="tunj_tambahan_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Bonus</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Bonus"
                           name="bonus_jml_hari" value="{{ old('bonus_jml_hari') }}" oninput="calculateGaji()">
                    <input type="hidden" name="bonus" id="bonus_hidden" value="{{ old('bonus') }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Bonus Per Hari"
                           name="bonus_per_hari" value="{{ old('bonus_per_hari') }}" oninput="calculateGaji()">
                  </td>
                  <td id="bonus_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Event Konser (Paid)</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Event Konser (Paid)"
                           name="event_konser_jml_hari" value="{{ old('event_konser_jml_hari') }}" oninput="calculateGaji()">
                    <input type="hidden" name="event_konser" id="event_konser_hidden" value="{{ old('event_konser') }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Event Konser (Paid) Per Hari"
                           name="event_konser_per_hari" value="{{ old('event_konser_per_hari') }}" oninput="calculateGaji()">
                  </td>
                  <td id="event_konser_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Set Up Konser</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Set Up Konser"
                           name="set_up_konser_jml_hari" value="{{ old('set_up_konser_jml_hari') }}" oninput="calculateGaji()">
                    <input type="hidden" name="set_up_konser" id="set_up_konser_hidden" value="{{ old('set_up_konser') }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Set Up Konser Per Hari"
                           name="set_up_konser_per_hari" value="{{ old('set_up_konser_per_hari') ?: 125000 }}" oninput="calculateGaji()">
                  </td>
                  <td id="set_up_konser_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Set Down Konser</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Set Down Konser"
                           name="set_down_konser_jml_hari" value="{{ old('set_down_konser_jml_hari') }}" oninput="calculateGaji()">
                    <input type="hidden" name="set_down_konser" id="set_down_konser_hidden" value="{{ old('set_down_konser') }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Set Down Konser Per Hari"
                           name="set_down_konser_per_hari" value="{{ old('set_down_konser_per_hari') ?: 125000 }}" oninput="calculateGaji()">
                  </td>
                  <td id="set_down_konser_text" class="text-right"></td>
                </tr>
                <tr>
                  <td class="text-right font-weight-bold" colspan="3">Total</td>
                  <td class="text-right font-weight-bold">
                    <span id="total_1_text"></span>
                    <input type="hidden" name="total_1" id="total_1_hidden">
                  </td>
                </tr>
                <tr>
                  <td>Libur Cuti</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Libur Cuti"
                           name="libur_jml_hari" value="{{ old('libur_jml_hari') }}" oninput="calculateGaji()">
                    <input type="hidden" name="libur" id="libur_hidden" value="{{ old('libur') }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Libur Cuti Per Hari"
                           name="libur_per_hari" value="{{ old('libur_per_hari') }}" oninput="calculateGaji()">
                  </td>
                  <td id="libur_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Sakit / Izin</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Sakit / Izin"
                           name="sakit_jml_hari" value="{{ old('sakit_jml_hari') }}" oninput="calculateGaji()">
                    <input type="hidden" name="sakit" id="sakit_hidden" value="{{ old('sakit') }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Sakit / Izin Per Hari"
                           name="sakit_per_hari" value="{{ old('sakit_per_hari') ?: 77000 }}" oninput="calculateGaji()">
                  </td>
                  <td id="sakit_text" class="text-right"></td>
                </tr>
                <tr>
                  <td colspan="2">Kasbon</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Kasbon"
                           name="kasbon" value="{{ old('kasbon') }}" oninput="calculateGaji()">
                  </td>
                  <td id="kasbon_text" class="text-right"></td>
                </tr>
                <tr>
                  <td class="text-right font-weight-bold" colspan="3">Total</td>
                  <td class="text-right font-weight-bold">
                    <span id="total_2_text"></span>
                    <input type="hidden" name="total_2" id="total_2_hidden">
                  </td>
                </tr>
                <tr>
                  <td>Lembur/Jam</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Jam Lembur"
                           name="lembur_jam_jml_jam" value="{{ old('lembur_jam_jml_jam') }}" oninput="calculateGaji()">
                    <input type="hidden" name="lembur_jam" id="lembur_jam_hidden" value="{{ old('lembur_jam') }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Lembur Per Jam"
                           name="lembur_jam_per_jam" value="{{ old('lembur_jam_per_jam') ?: 10000 }}" oninput="calculateGaji()">
                  </td>
                  <td id="lembur_jam_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Lembur Harian</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Lembur"
                           name="lembur_hari_jml_hari" value="{{ old('lembur_hari_jml_hari') }}" oninput="calculateGaji()">
                    <input type="hidden" name="lembur_hari" id="lembur_hari_hidden" value="{{ old('lembur_hari') }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Lembur Per Hari"
                           name="lembur_hari_per_hari" value="{{ old('lembur_hari_per_hari') ?: 100000 }}" oninput="calculateGaji()">
                  </td>
                  <td id="lembur_hari_text" class="text-right"></td>
                </tr>
                <tr>
                  <td class="text-right font-weight-bold" colspan="3">Sub Total</td>
                  <td class="text-right font-weight-bold">
                    <span id="sub_total_text"></span>
                    <input type="hidden" name="sub_total" id="sub_total_hidden">
                  </td>
                </tr>
                <tr style="background: #FFFF00">
                  <td class="text-right font-weight-bold" colspan="3">Total Penerimaan</td>
                  <td class="text-right font-weight-bold">
                    <span id="total_penerimaan_text"></span>
                    <input type="hidden" name="total_penerimaan" id="total_penerimaan_hidden">
                  </td>
                </tr>
                </tbody>
              </table>
            </div>
            <div class="card-body">
              <div class="form-group row mb-0">
                <label class="col-lg-3 text-right col-form-label" for="notes">Notes</label>
                <div class="col-lg-9">
                  <textarea name="notes" id="notes" class="form-control" rows="5">{{ old('notes') }}</textarea>
                </div>
              </div>
            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>

  <style>
    /* Chrome, Safari, Edge, Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }

    /* Firefox */
    input[type=number] {
      -moz-appearance: textfield;
    }
  </style>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();

      function calculateGaji() {
          let gaji_pokok_jml_hari = getValue('gaji_pokok_jml_hari');
          let gaji_pokok_per_hari = getValue('gaji_pokok_per_hari');
          let kehadiran_harian_jml_hari = getValue('kehadiran_harian_jml_hari');
          let kehadiran_harian_per_hari = getValue('kehadiran_harian_per_hari');
          let tunj_tambahan_jml_hari = getValue('tunj_tambahan_jml_hari');
          let tunj_tambahan_per_hari = getValue('tunj_tambahan_per_hari');
          let bonus_jml_hari = getValue('bonus_jml_hari');
          let bonus_per_hari = getValue('bonus_per_hari');
          let event_konser_jml_hari = getValue('event_konser_jml_hari');
          let event_konser_per_hari = getValue('event_konser_per_hari');
          let set_up_konser_jml_hari = getValue('set_up_konser_jml_hari');
          let set_up_konser_per_hari = getValue('set_up_konser_per_hari');
          let set_down_konser_jml_hari = getValue('set_down_konser_jml_hari');
          let set_down_konser_per_hari = getValue('set_down_konser_per_hari');
          let support_jml_hari = getValue('support_jml_hari');
          let support_per_hari = getValue('support_per_hari');
          let libur_jml_hari = getValue('libur_jml_hari');
          let libur_per_hari = getValue('libur_per_hari');
          let sakit_jml_hari = getValue('sakit_jml_hari');
          let sakit_per_hari = getValue('sakit_per_hari');
          let lembur_jam_jml_jam = getValue('lembur_jam_jml_jam');
          let lembur_jam_per_jam = getValue('lembur_jam_per_jam');
          let lembur_hari_jml_hari = getValue('lembur_hari_jml_hari');
          let lembur_hari_per_hari = getValue('lembur_hari_per_hari');

          let gaji_pokok = gaji_pokok_jml_hari * gaji_pokok_per_hari;
          let kehadiran_harian = kehadiran_harian_jml_hari * kehadiran_harian_per_hari;
          let tunj_tambahan = tunj_tambahan_jml_hari * tunj_tambahan_per_hari;
          let bonus = bonus_jml_hari * bonus_per_hari;
          let event_konser = event_konser_jml_hari * event_konser_per_hari;
          let set_up_konser = set_up_konser_jml_hari * set_up_konser_per_hari;
          let set_down_konser = set_down_konser_jml_hari * set_down_konser_per_hari;
          let support = support_jml_hari * support_per_hari;
          let libur = libur_jml_hari * libur_per_hari;
          let sakit = sakit_jml_hari * sakit_per_hari;
          let lembur_jam = lembur_jam_jml_jam * lembur_jam_per_jam;
          let lembur_hari = lembur_hari_jml_hari * lembur_hari_per_hari;

          let kasbon = getValue('kasbon');

          let total_1 = gaji_pokok + kehadiran_harian + event_konser + tunj_tambahan + bonus + set_up_konser + set_down_konser + support;
          let total_2 = total_1 - (libur + sakit + kasbon);
          let sub_total = total_2 + lembur_jam + lembur_hari;
          let total_penerimaan = sub_total;

          $("#gaji_pokok_text").text(gaji_pokok ? formatNumber(gaji_pokok) : '');
          $("#gaji_pokok_hidden").val(gaji_pokok);
          $("#kehadiran_harian_text").text(kehadiran_harian ? formatNumber(kehadiran_harian) : '');
          $("#kehadiran_harian_hidden").val(kehadiran_harian);
          $("#tunj_tambahan_text").text(tunj_tambahan ? formatNumber(tunj_tambahan) : '');
          $("#tunj_tambahan_hidden").val(tunj_tambahan);
          $("#bonus_text").text(bonus ? formatNumber(bonus) : '');
          $("#bonus_hidden").val(bonus);
          $("#event_konser_text").text(event_konser ? formatNumber(event_konser) : '');
          $("#event_konser_hidden").val(event_konser);
          $("#set_up_konser_text").text(set_up_konser ? formatNumber(set_up_konser) : '');
          $("#set_up_konser_hidden").val(set_up_konser);
          $("#set_down_konser_text").text(set_down_konser ? formatNumber(set_down_konser) : '');
          $("#set_down_konser_hidden").val(set_down_konser);
          $("#support_text").text(support ? formatNumber(support) : '');
          $("#support_hidden").val(support);
          $("#libur_text").text(libur ? formatNumber(libur) : '');
          $("#libur_hidden").val(libur);
          $("#sakit_text").text(sakit ? formatNumber(sakit) : '');
          $("#sakit_hidden").val(sakit);
          $("#lembur_jam_text").text(lembur_jam ? formatNumber(lembur_jam) : '');
          $("#lembur_jam_hidden").val(lembur_jam);
          $("#lembur_hari_text").text(lembur_hari ? formatNumber(lembur_hari) : '');
          $("#lembur_hari_hidden").val(lembur_hari);
          $("#kasbon_text").text(kasbon ? formatNumber(kasbon) : '');

          $("#total_1_text").text(total_1 ? formatNumber(total_1) : '');
          $("#total_1_hidden").val(total_1);
          $("#total_2_text").text(total_2 ? formatNumber(total_2) : '');
          $("#total_2_hidden").val(total_2);
          $("#sub_total_text").text(sub_total ? formatNumber(sub_total) : '');
          $("#sub_total_hidden").val(sub_total);
          $("#total_penerimaan_text").text(total_penerimaan ? formatNumber(total_penerimaan) : '');
          $("#total_penerimaan_hidden").val(total_penerimaan);
      }
      function getValue(name) {
          let value = $(`[name=${name}]`).val();
          if(value && !isNaN(value*1)){
              return value*1;
          }
          else return 0;
      }
      function formatNumber(number, with_rp = false, fraction_digits = 0) {
          let text = (number).toLocaleString('id-ID', { minimumFractionDigits: fraction_digits });
          return (with_rp ? 'Rp ' : '') + text;
      }
  </script>
@endsection