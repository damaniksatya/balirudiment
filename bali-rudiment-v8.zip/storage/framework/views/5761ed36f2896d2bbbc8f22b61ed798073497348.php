<?php $__env->startSection('title','Detail Absensi'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(url(request()->get('back_url') ?: 'absensi/instruktur')); ?>">Absensi</a></li>
                  <li class="breadcrumb-item active">Detail</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="<?php echo e(url(request()->get('back_url') ?: 'absensi/instruktur')); ?>">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Detail Absensi
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body pb-0">
            <div class="form-group row">
              <div class="col-lg-12">
                <label class="col-form-label" for="id_jadwal">Jadwal</label>
                <div class="card shadow-none mt-2 mb-0" style="background-color: rgba(0, 0, 0, 0.07)">
                  <div class="card-body">
                    <table class="table table-sm table-borderless mb-0">
                      <tr>
                        <td style="width: 100px">Hari</td>
                        <td class="px-0" style="width: 5px">:</td>
                        <td><?php echo e($info->jadwal->hari); ?></td>
                      </tr>
                      <tr>
                        <td>Tanggal</td>
                        <td class="px-0">:</td>
                        <td><?php echo e(\App\Http\Controllers\HelperController::setNamaBulan(null, $info->tanggal)); ?></td>
                      </tr>
                      <tr>
                        <td>Jam</td>
                        <td class="px-0">:</td>
                        <td><?php echo e($info->jadwal->jam_mulai .'-'. $info->jadwal->jam_selesai); ?></td>
                      </tr>
                      <tr>
                        <td>Studio</td>
                        <td class="px-0">:</td>
                        <td><?php echo e($info->jadwal->nama_studio); ?></td>
                      </tr>
                      <tr>
                        <td>Instrumen</td>
                        <td class="px-0">:</td>
                        <td><?php echo e($info->jadwal->nama_instrumen); ?></td>
                      </tr>
                      <tr>
                        <td>Instruktur</td>
                        <td class="px-0">:</td>
                        <td><?php echo e($info->jadwal->nama_instruktur); ?></td>
                      </tr>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group row mb-2">
              <div class="col-lg-12">
                <table class="table table-sm table-borderless mb-0">
                  <tr>
                    <td class="pl-0" style="width: 100px">Status</td>
                    <td class="px-0" style="width: 5px">:</td>
                    <td>
                      <span class="badge badge-<?php echo e(\App\Absensi::$color[$info->status]); ?>" style="padding-top: 5px"><?php echo e($info->status); ?></span>
                    </td>
                  </tr>
                  <tr>
                    <td class="pl-0">Durasi</td>
                    <td class="px-0" style="width: 5px">:</td>
                    <td><?php echo e($info->durasi_mengajar); ?> Menit</td>
                  </tr>
                  <?php if($info->status == \App\Absensi::S_DIKONFIRMASI): ?>
                    <tr>
                      <td class="pl-0">Fee</td>
                      <td class="px-0" style="width: 5px">:</td>
                      <td>Rp <?php echo e(number_format($info->fee, 0, ',', '.')); ?></td>
                    </tr>
                  <?php endif; ?>
                </table>
              </div>
            </div>
            <div class="form-group row">
              <div class="col-lg-12">
                <label class="col-form-label" for="id_jadwal">Report</label>
                <p class="mb-0" style="white-space: pre-wrap"><?php echo e($info->report); ?></p>
              </div>
            </div>
            <div class="form-group row">
              <div class="col-lg-12">
                <table class="table table-sm table-bordered mb-0">
                  <thead>
                  <tr>
                    <th>Nama Siswa</th>
                    <th class="text-center">Kehadiran</th>
                    <th class="text-center">Fee</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><label class="form-check-label"><?php echo e($d['siswa']['nama_siswa']); ?></label></td>
                      <td class="text-center">
                        <span class="badge badge-<?php echo e(\App\Absensi::$color[$d['kehadiran']]); ?>" style="padding-top: 5px"><?php echo e($d['kehadiran']); ?></span>
                      </td>
                      <td class="text-center"><?php echo e(number_format($d['fee'], 0, ',', '.')); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>