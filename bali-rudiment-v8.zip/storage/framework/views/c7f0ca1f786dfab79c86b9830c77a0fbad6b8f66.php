<?php $__env->startSection('title','Input Data Accounting'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/dropify/css/dropify.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(url('accounting')); ?>">Accounting</a></li>
                  <li class="breadcrumb-item active">Input</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="<?php echo e(url('accounting')); ?>">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input Accounting
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="<?php echo e(url('accounting')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card-body">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="nama">Nama</label>
                <div class="col-lg-9">
                  <input type="text" id="nama" name="nama" value="<?php echo e(old('nama')); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="email_accounting">Email</label>
                <div class="col-lg-9">
                  <input type="text" id="email_accounting" name="email_accounting" value="<?php echo e(old('email_accounting')); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="no_hp">No HP</label>
                <div class="col-lg-9">
                  <input type="text" id="no_hp" name="no_hp" value="<?php echo e(old('no_hp')); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="username">Username Login</label>
                <div class="col-lg-9">
                  <input type="text" id="username" name="username" value="<?php echo e(old('username')); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="password">Password</label>
                <div class="col-lg-9">
                  <input type="password" id="password" name="password" class="form-control" autocomplete="off">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="jenis_kelamin">Jenis Kelamin</label>
                <div class="col-lg-9">
                  <select name="jenis_kelamin" id="jenis_kelamin" class="form-control select2">
                    <option value="">Pilih Jenis Kelamin</option>
                    <?php $__currentLoopData = \App\Accounting::$jenis_kelamin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($l); ?>" <?php echo e(old('jenis_kelamin') == $l ? 'selected' : ''); ?>><?php echo e($l); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group row mb-0">
                <label class="col-lg-3 text-right col-form-label" for="foto_profile">Foto Profil</label>
                <div class="col-lg-9">
                  <input type="file"
                         name="foto_profile"
                         class="dropify dropify-photo"
                         data-height="150"
                         data-show-remove="false"
                         data-allowed-file-extensions="jpg jpeg png"
                         data-max-file-size="1M"
                         accept=".jpg, .jpeg, .png" />
                </div>
              </div>
            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/dropify/js/dropify.min.js')); ?>"></script>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(document).ready(function(){
          $(".select2").select2();
          $('.dropify-photo').dropify({
              messages: {
                  'default': 'Drag & drop foto di sini atau klik',
                  'replace': 'Drag & drop atau klik untuk mengganti foto',
                  'error': 'Hanya format png/jpeg/jpg yang di izinkan'
              },
              error: {
                  'fileSize': 'Ukuran foto melebihi maksimal (1M max).',
              }
          });
      });
      function disableAutoComplete() {
          $("#username").val('');
          $("#password").val('');
      }

      setTimeout(disableAutoComplete, 500);
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>