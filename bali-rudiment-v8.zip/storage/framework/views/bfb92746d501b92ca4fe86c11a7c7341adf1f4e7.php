<tr>
  <?php if($with_hari): ?>
    <?php
      $rowspan_hari = $hari['siswa_total'] >= $hari['jadwal_total'] ? $hari['siswa_total'] : $hari['jadwal_total'];
    ?>
    <td rowspan="<?php echo e($rowspan_hari); ?>"><?php echo e($hari['hari']); ?></td>
  <?php endif; ?>

  <?php if($with_jadwal): ?>
    <td rowspan="<?php echo e($jadwal['siswa_total'] + 1); ?>" class="text-center"><?php echo e($jadwal['jam_mulai'] .' - '. $jadwal['jam_selesai']); ?></td>
    <td rowspan="<?php echo e($jadwal['siswa_total'] + 1); ?>"><?php echo e($jadwal['nama_studio']); ?></td>
    <td rowspan="<?php echo e($jadwal['siswa_total'] + 1); ?>" style="width: 150px"><?php echo e($jadwal['nama_instrumen']); ?></td>
    <td rowspan="<?php echo e($jadwal['siswa_total'] + 1); ?>" style="width: 40px; padding: 2px">
      <div class="btn-group btn-block">
        <a class="btn btn-xs btn-outline-primary"
           href="<?php echo e(url('jadwal/edit/'.$jadwal['id_jadwal'])); ?>"
           style="padding-top: 3px; padding-bottom: 3px" title="Edit Jadwal">
          <i class="mdi mdi-pencil"></i>
        </a>
        <button class="btn btn-xs btn-outline-danger" style="padding-top: 3px; padding-bottom: 3px"
                title="Hapus Jadwal" onclick="deleteData('<?php echo e($jadwal['id_jadwal']); ?>')">
          <i class="mdi mdi-trash-can"></i>
        </button>

      </div>
    </td>
  <?php endif; ?>

  <?php if($index_siswa != $jadwal['siswa_total']): ?>
    <td><?php echo e($jadwal['siswa'][$index_siswa]['nama_siswa']); ?></td>
  <?php else: ?>
    <td style="padding: 2px" class="text-center">
      <button class="btn btn-sm btn-block btn-outline-secondary" style="padding-top: 3px; padding-bottom: 3px; border-color: #e9ecef !important;"
              onclick="openModalAddSiswa('<?php echo e($jadwal['id_jadwal']); ?>')">
        <?php if(!$jadwal['siswa_total']): ?>
          Masukkan Siswa
        <?php else: ?>
          Edit Siswa
        <?php endif; ?>
      </button>
    </td>
  <?php endif; ?>
</tr>