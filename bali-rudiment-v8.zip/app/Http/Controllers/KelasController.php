<?php

namespace App\Http\Controllers;

use App\Kelas;
use Illuminate\Http\Request;

class KelasController extends Controller
{
  public function index()
  {
    $data = Kelas::getData();

    return view('pages.kelas.index')
      ->with('data', $data);
  }

  public function viewAdd()
  {
    return view('pages.kelas.add');
  }

  public function viewEdit($id)
  {
    $info = Kelas::getInfo($id);

    return view('pages.kelas.edit')
      ->with('info', $info);
  }

  public function store(Request $req)
  {
    $this->validateData();

    Kelas::insertData([
      'nama_kelas' => $req->nama_kelas
    ]);

    return back()->with('success','Berhasil menyimpan data');
  }

  public function update(Request $req)
  {
    $new_nama = $req->nama_kelas != $req->nama_kelas_old;
    $this->validateData($new_nama);

    Kelas::updateData([
      'id_kelas' => $req->id_kelas,
      'nama_kelas' => $req->nama_kelas
    ]);

    return redirect('kelas')->with('success','Berhasil menyimpan data');
  }

  public function delete(Request $req)
  {
    Kelas::deleteData($req->id);

    return back()->with('success','Berhasil menghapus data');
  }

  private function validateData($new_nama = true)
  {
    return request()->validate([
      'nama_kelas' => 'required|max:40'.($new_nama ? '|unique:kelas' : '')
    ],[
      'nama_kelas.required' => 'Nama Kelas harus diisi!',
      'nama_kelas.max' => 'Nama Kelas maksimal :max karakter!',
      'nama_kelas.unique' => 'Nama Kelas sudah digunakan!'
    ]);
  }
}
