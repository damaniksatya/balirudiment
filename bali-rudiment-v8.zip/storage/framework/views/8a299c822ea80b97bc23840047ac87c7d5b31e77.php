<?php $__env->startSection('title','Data Jadwal Harian'); ?>

<?php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_jadwal_harian);
  $nonaktif_edit = in_array(\App\SettingMenu::UPDATE_JADWAL_HARIAN, $arr_nonaktif);
  $nonaktif_reset = in_array(\App\SettingMenu::RESET_JADWAL_HARIAN, $arr_nonaktif);
  $nonaktif_print = in_array(\App\SettingMenu::PRINT_JADWAL_HARIAN, $arr_nonaktif);
?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
  <link rel="stylesheet" href="<?php echo e(url('plugins/jspreadsheet9/jspreadsheet.css')); ?>"/>
  <link rel="stylesheet" href="https://jsuites.net/v4/jsuites.css" type="text/css" />
  
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Material+Icons" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right mt-2 pt-1">
                
                  
                
              </div>
              <h4 class="page-title">Data Jadwal Harian</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <form method="get" class="card-body">
            <div class="row">
              <?php if($level_user == \App\User::L_GENERAL_ADMIN): ?>
                <div class="col-lg-6">
                  <div class="form-group row mb-0">
                    <label class="col-form-label col-lg-3 text-lg-right" for="id_penempatan">Penempatan</label>
                    <div class="col-lg-9">
                      <select name="id_penempatan" id="id_penempatan" class="form-control select2" onchange="this.form.submit()">
                        <option value="">Pilih penempatan</option>
                        <?php $__currentLoopData = $data_penempatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($d->id_penempatan); ?>" <?php echo e($id_penempatan == $d->id_penempatan ? 'selected' : ''); ?>><?php echo e($d->nama_penempatan); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>
                </div>
              <?php else: ?>
                <div class="col-lg-6">
                  <div class="form-group row mb-0">
                    <label class="col-form-label col-lg-3 text-lg-right" for="id_penempatan">Penempatan</label>
                    <div class="col-lg-9">
                      <select id="id_penempatan" class="form-control select2" disabled>
                        <?php $__currentLoopData = $data_penempatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($id_penempatan == $d->id_penempatan): ?>
                          <option value="<?php echo e($d->id_penempatan); ?>" ><?php echo e($d->nama_penempatan); ?></option>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>
                </div>
                <input type="hidden" id="id_penempatan" name="id_penempatan" value="<?php echo e($id_penempatan); ?>">
              <?php endif; ?>
              <div class="col-lg-6">
                <div class="form-group row mb-0">
                  <label class="col-form-label col-lg-3 text-lg-right" for="tanggal">Tanggal</label>
                  <div class="col-lg-9">
                    <input type="text" name="tanggal" id="tanggal" class="form-control datepicker"
                           value="<?php echo e(date('d-m-Y', strtotime($tanggal))); ?>" onchange="this.form.submit()">
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
      
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body overflow-auto px-0 text-center" id="card-body-spreadsheet">
            <div id="spreadsheet" style="width: 100%"></div>

            <div class="px-3">
              <table class="table-sm" style="width: 100%">
                <tr>
                  <td>
                    <textarea name="note_left" id="note_left" class="form-control" style="height: 174px" placeholder="Notes"><?php echo e($info != null ? $info['note'] : ''); ?></textarea>
                  </td>
                  <td>
                    <textarea name="note_right" id="note_right" class="form-control" style="height: 174px" placeholder="Notes"><?php echo e($info != null ? $info['note2'] : ''); ?></textarea>
                  </td>
                  <td style="width: 180px; vertical-align: top !important;">
                    <table class="table table-bordered table-xs text-left mb-0">
                      <?php $__currentLoopData = \App\JadwalHarian::$arr_keterangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td style="width: 28px; background-color: <?php echo e($ket['background']); ?>"></td>
                          <td class="pl-2"><?php echo e($ket['text']); ?></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                  </td>
                </tr>
              </table>
            </div>
            <div class="px-3 pt-3">
              <form action="<?php echo e(url('jadwal-harian/print')); ?>" method="get" target="_blank" id="form-print">
                <input type="hidden" name="id_penempatan" value="<?php echo e($id_penempatan); ?>">
                <input type="hidden" name="tanggal" value="<?php echo e($tanggal); ?>">
              </form>
              <?php if(!$nonaktif_edit): ?>
                <button type="button" onclick="simpan()" class="btn btn-primary float-right ml-2"><i class="mdi mdi-content-save"></i> Simpan</button>
              <?php endif; ?>

              <?php if(!$nonaktif_print): ?>
                <button type="button" onclick="document.getElementById('form-print').submit()" class="btn btn-outline-primary float-right">
                  <i class="mdi mdi-printer"></i> Print
                </button>
              <?php endif; ?>

              <?php if(!$nonaktif_reset): ?>
                <?php if(isset($info)): ?>
                  <form action="<?php echo e(url('jadwal-harian/reset')); ?>" method="post" id="form-reset">
                    <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                    <input type="hidden" name="id_penempatan" value="<?php echo e($id_penempatan); ?>">
                    <input type="hidden" name="tanggal" value="<?php echo e($tanggal); ?>">
                  </form>
                  <button class="btn btn-outline-danger border-0 float-left" onclick="resetJadwal()">Reset Jadwal</button>
                <?php endif; ?>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <style>
    .table tr td{
      vertical-align: top !important;
    }
    #spreadsheet{
      z-index: 101;
    }
    .jss thead, .jss tbody tr td:first-child, .jss colgroup col:first-child{
      visibility: hidden;
    }
    .jss thead tr td{
      padding: 0 !important;
      border: none !important;
    }
    .jss tbody tr td:first-child{
      padding: 0 !important;
      border: none !important;
    }
    .jss tbody tr .readonly{
      background-color: #F3F3F3;
      color: #495057 !important;
    }
    .jss_scroll{
      max-height: 540px;
    }
    .jss_content_overflow{
      border-right: none;
      border-bottom: none;
      width: 100%;
    }
    .jss > tbody > tr > td.jss_number {
      text-align: center;
    }
    .table-xs tr td{
      padding: 0.2rem;
    }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script src="<?php echo e(url('plugins/jspreadsheet9/jspreadsheet.js')); ?>"></script>
  <script src="https://jsuites.net/v4/jsuites.js"></script>
  
  <script>
      $(".select2").select2();

      let customToolbar = {
          items: [
              {
                  content: 'undo',
                  tooltip: 'Undo',
                  onclick: function() {
                      if (J[0]) {
                          J[0].undo();
                      }
                  }
              },
              {
                  content: 'redo',
                  tooltip: 'Redo',
                  onclick: function() {
                      if (J[0]) {
                          J[0].redo();
                      }
                  }
              },
              {
                  type:'divisor',
              },
              {
                  type: 'i',
                  tooltip: 'Bold',
                  content: 'format_bold',
                  onclick: function(a,b,c) {
                      jspreadsheet.current.setStyle(jspreadsheet.current.getSelected(), 'font-weight', 'bold');
                  }
              },
              {
                  type: 'i',
                  tooltip: 'Italic',
                  content: 'format_italic',
                  onclick: function(a,b,c) {
                      jspreadsheet.current.setStyle(jspreadsheet.current.getSelected(), 'font-style', 'italic');
                  }
              },
              {
                  type: 'i',
                  tooltip: 'Underline',
                  content: 'format_underline',
                  onclick: function(a,b,c) {
                      jspreadsheet.current.setStyle(jspreadsheet.current.getSelected(), 'text-decoration', 'underline');
                  }
              },
              {
                  type:'divisor',
              },
              {
                  type: 'select',
                  tooltip: 'Align text',
                  options: ['format_align_left','format_align_center','format_align_right','format_align_justify'],
                  render: function(e) {
                      return '<i class="material-icons">' + e + '</i>';
                  },
                  onchange: function(a,b,c,d) {
                      if (J[0]) {
                          J[0].setStyle(J[0].getSelected(false, true), 'text-align', d.split('_')[2]);
                      }
                  },
                  updateState: function(a,b,c,d) {
                      var cell = d.selectedCell;
                      if (cell && cell.length) {
                          if (d.records[cell[1]][cell[0]].element) {
                              var value = 'format_align_' + (d.records[cell[1]][cell[0]].element.style.textAlign || d.options.defaultColAlign || 'center');
                              var index = this.picker.options.data.indexOf(value);
                              c.picker.setValue(index);
                          }
                      }
                  }
              },
              {
                  type: 'color',
                  content: 'format_color_text',
                  k: 'color',
                  tooltip: 'Text color',
              },
              {
                  type: 'color',
                  content: 'format_color_fill',
                  k: 'background-color',
                  tooltip: 'Background color',
              },
              {
                  type:'divisor',
              },
              {
                  content: 'web',
                  onclick: function(a,b,c) {
                      var h = J[0].getHighlighted();
                      if (h && h.length) {
                          var cell = J[0].helpers.getColumnNameFromCoords(h[0], h[1]);
                          if (J[0].records[h[1]][h[0]].merged) {
                              J[0].removeMerge(cell);
                          } else {
                              var colspan = h[2] - h[0] + 1;
                              var rowspan = h[3] - h[1] + 1;
                              J[0].setMerge(cell, colspan, rowspan);
                          }
                      }
                  },
                  tooltip: 'Merge the selected cells',
              },
              {
                  content: 'fullscreen',
                  onclick: function(a,b,c) {
                      if (c.children[0].innerText == 'fullscreen') {
                          J[0].fullscreen(true);
                          c.children[0].innerText = 'fullscreen_exit';
                      } else {
                          J[0].fullscreen(false);
                          c.children[0].innerText = 'fullscreen';
                      }
                  },
                  tooltip: 'Toggle Fullscreen',
                  updateState: function(a,b,c,d) {
                      if (d.parent.config.fullscreen == true) {
                          c.children[0].innerText = 'fullscreen_exit';
                      } else {
                          c.children[0].innerText = 'fullscreen';
                      }
                  }
              }
          ]
      };

      let J = jspreadsheet(document.getElementById('spreadsheet'), {
          worksheets: [{
              data: JSON.parse('<?php echo $data; ?>'),
              columnDrag: true,
              tableOverflow: true,
              tableWidth: $("#card-body-spreadsheet").width(),
              tableHeight: '570px',
              columns: JSON.parse('<?php echo $column; ?>'),
              mergeCells: JSON.parse('<?php echo $merge_cell; ?>'),
              cells: JSON.parse('<?php echo $read_only; ?>'),
              style: '<?php echo e($style); ?>' !== '[]' ? JSON.parse('<?php echo $style; ?>') : {}
          }],
          toolbar: customToolbar,
          oninput: function (a, b) {
              getValueSpreadsheet();
          },
          onchangestyle: function () {
              getValueSpreadsheet();
          },
          onmerge: function () {
              getValueSpreadsheet();
          }
          // license: 'NTNhMTBlN2EwMjk4M2FmNDU0MjE0ZWEyY2ZkZjUyN2ViNjRjMWY2ZGE3ZDk4NWYzZjQ4NmM3N2FlNTY4Mjk5YWNlMjE2MjEyNWEzMjM3N2ViNjU3YWNjMGMwZjBkMDMwYWQwYjljOGFlNjFiOGY0NTIwMGQ1NzIwMThlMTQxN2IsZXlKdVlXMWxJam9pU25Od2NtVmhaSE5vWldWMElpd2laR0YwWlNJNk1UWTNORFkxTVRVMk9Dd2laRzl0WVdsdUlqcGJJbXB6Y0hKbFlXUnphR1ZsZEM1amIyMGlMQ0pqYjJSbGMyRnVaR0p2ZUM1cGJ5SXNJbXB6YUdWc2JDNXVaWFFpTENKamMySXVZWEJ3SWl3aWJHOWpZV3hvYjNOMElsMHNJbkJzWVc0aU9pSXpJaXdpYzJOdmNHVWlPbHNpZGpjaUxDSjJPQ0lzSW5ZNUlpd2lZMmhoY25Seklpd2labTl5YlhNaUxDSm1iM0p0ZFd4aElpd2ljR0Z5YzJWeUlpd2ljbVZ1WkdWeUlpd2lZMjl0YldWdWRITWlMQ0pwYlhCdmNuUWlMQ0ppWVhJaUxDSjJZV3hwWkdGMGFXOXVjeUlzSW5ObFlYSmphQ0pkTENKa1pXMXZJanAwY25WbGZRPT0=',
      });

      function getValueSpreadsheet(){
          // console.log(J[0].getData());
          // console.log(J[0].getMerge());
          // console.log(J[0].getCells());
          console.log(J[0].getStyle());
          // console.log(J[0].getWidth());
      }

      $(document).ready(function () {
          $(".jss colgroup col:first-child").attr('width', 0);
          $(".jss thead tr:first-child").css('height','0').css('max-height','0');
          $(".jss thead tr td").text('');
          let width_jss = $(".jss").width();
          let width_card_body = $("#card-body-spreadsheet").width();
          if(width_jss < width_card_body){
              $(".jss_toolbar").css('width', width_jss + 1);
              $("#spreadsheet").css('width', width_jss + 4);
          }
          $(".jss_scroll").css('width', width_jss);
          $(".jss_content").css('width', '100%');
          // $(".jss_content").css('height', '500px');
          // console.log($(".jss").width())
      });
      
      function simpan() {
          $.ajax({
              url: '<?php echo e(url('jadwal-harian')); ?>',
              type: 'post',
              data: {
                  _token: '<?php echo e(csrf_token()); ?>',
                  tanggal: $("#tanggal").val(),
                  id_penempatan: $("#id_penempatan").val(),
                  note: $("#note_left").val(),
                  note2: $("#note_right").val(),
                  data: J[0].getData(),
                  merge: J[0].getMerge(),
                  cells: J[0].getCells(),
                  style: J[0].getStyle(),
                  column: J[0].getWidth(),
              },
              success: function(data) {
                  swal({
                      title: 'Berhasil',
                      text: "Berhasil menyimpan jadwal",
                      type: 'success',
                      confirmButtonColor: '#306397',
                      timer: 1000
                  })
              },
              error: async function(data) {
                  swal('Gagal','Terjadi kesalahan sistem','error');
              },
          });
      }

      function resetJadwal() {
          swal({
              title: "Anda yakin?",
              text: "Jadwal harian <?php echo e(\App\Http\Controllers\HelperController::setNamaBulan(null, $tanggal)); ?> akan disinkronisasi ulang dengan jadwal mengajar, jadwal custom / selain jadwal mengajar akan terhapus!",
              type: "warning",
              showCancelButton: true,
              confirmButtonColor: "#E62129",
              confirmButtonText: "Reset!",
              cancelButtonText: "Batalkan",
              closeOnConfirm: false
          }, function(){
              $("#form-reset").submit();
          });
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>