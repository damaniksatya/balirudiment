-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bali_rudiment
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.22-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `absensi`
--

DROP TABLE IF EXISTS `absensi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `absensi` (
  `id_absensi` int(11) NOT NULL AUTO_INCREMENT,
  `id_jadwal` int(11) DEFAULT NULL,
  `id_instruktur` int(11) DEFAULT NULL,
  `report` text DEFAULT NULL,
  `fee` float DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `durasi_mengajar` int(11) DEFAULT NULL,
  `status` enum('MENUNGGU KONFIRMASI','DIKONFIRMASI') DEFAULT 'MENUNGGU KONFIRMASI',
  PRIMARY KEY (`id_absensi`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absensi`
--

LOCK TABLES `absensi` WRITE;
/*!40000 ALTER TABLE `absensi` DISABLE KEYS */;
INSERT INTO `absensi` VALUES (1,34,3,'Siap',NULL,'2023-01-28',60,'MENUNGGU KONFIRMASI');
/*!40000 ALTER TABLE `absensi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `absensi_siswa`
--

DROP TABLE IF EXISTS `absensi_siswa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `absensi_siswa` (
  `id_absensi_siswa` int(11) NOT NULL AUTO_INCREMENT,
  `id_absensi` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `kehadiran` enum('HADIR','IZIN','SAKIT','TIDAK HADIR') DEFAULT NULL,
  `fee` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_absensi_siswa`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absensi_siswa`
--

LOCK TABLES `absensi_siswa` WRITE;
/*!40000 ALTER TABLE `absensi_siswa` DISABLE KEYS */;
INSERT INTO `absensi_siswa` VALUES (1,1,3,'HADIR',NULL),(2,1,5,'HADIR',NULL);
/*!40000 ALTER TABLE `absensi_siswa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounting`
--

DROP TABLE IF EXISTS `accounting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `accounting` (
  `id_accounting` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengguna` int(11) DEFAULT NULL,
  `nama_accounting` varchar(80) DEFAULT NULL,
  `email_accounting` varchar(80) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `jenis_kelamin` enum('LAKI-LAKI','PEREMPUAN') DEFAULT NULL,
  PRIMARY KEY (`id_accounting`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting`
--

LOCK TABLES `accounting` WRITE;
/*!40000 ALTER TABLE `accounting` DISABLE KEYS */;
INSERT INTO `accounting` VALUES (1,3,'Hatten','hatten@gmail.com','0818350485','LAKI-LAKI'),(2,4,'Macallan','azrul@gmail.com','0818350485','LAKI-LAKI');
/*!40000 ALTER TABLE `accounting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengguna` int(11) DEFAULT NULL,
  `id_penempatan` int(11) DEFAULT NULL,
  `nama_admin` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,1,NULL,'Admin'),(2,2,1,'Azrul Ananda');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gaji_freelance`
--

DROP TABLE IF EXISTS `gaji_freelance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `gaji_freelance` (
  `id_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `id_instruktur` int(11) DEFAULT NULL,
  `bulan` char(7) DEFAULT NULL,
  `total_mengajar` int(11) DEFAULT NULL,
  `ensemble_jml_hari` int(11) DEFAULT NULL,
  `ensemble_per_hari` int(11) DEFAULT NULL,
  `ensemble` int(11) DEFAULT NULL,
  `ensemble_note` text DEFAULT NULL,
  `trial_jml_hari` int(11) DEFAULT NULL,
  `trial_per_hari` int(11) DEFAULT NULL,
  `trial` int(11) DEFAULT NULL,
  `trial_note` text DEFAULT NULL,
  `extra_lesson_jml_hari` int(11) DEFAULT NULL,
  `extra_lesson_per_hari` int(11) DEFAULT NULL,
  `extra_lesson` int(11) DEFAULT NULL,
  `extra_lesson_note` text DEFAULT NULL,
  `kinerja_jml_hari` int(11) DEFAULT NULL,
  `kinerja_per_hari` int(11) DEFAULT NULL,
  `kinerja` int(11) DEFAULT NULL,
  `kinerja_note` text DEFAULT NULL,
  `week_20_hours_jml_hari` int(11) DEFAULT NULL,
  `week_20_hours_per_hari` int(11) DEFAULT NULL,
  `week_20_hours` int(11) DEFAULT NULL,
  `week_20_hours_note` text DEFAULT NULL,
  `konser_jml_hari` int(11) DEFAULT NULL,
  `konser_per_hari` int(11) DEFAULT NULL,
  `konser` int(11) DEFAULT NULL,
  `konser_note` text DEFAULT NULL,
  `set_up_konser_jml_hari` int(11) DEFAULT NULL,
  `set_up_konser_per_hari` int(11) DEFAULT NULL,
  `set_up_konser` int(11) DEFAULT NULL,
  `set_up_konser_note` text DEFAULT NULL,
  `set_down_konser_jml_hari` int(11) DEFAULT NULL,
  `set_down_konser_per_hari` int(11) DEFAULT NULL,
  `set_down_konser` int(11) DEFAULT NULL,
  `set_down_konser_note` text DEFAULT NULL,
  `set_up_bw_jml_hari` int(11) DEFAULT NULL,
  `set_up_bw_per_hari` int(11) DEFAULT NULL,
  `set_up_bw` int(11) DEFAULT NULL,
  `set_up_bw_note` text DEFAULT NULL,
  `set_down_bw_jml_hari` int(11) DEFAULT NULL,
  `set_down_bw_per_hari` int(11) DEFAULT NULL,
  `set_down_bw` int(11) DEFAULT NULL,
  `set_down_bw_note` text DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `kasbon` int(11) DEFAULT NULL,
  `grand_total` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_gaji`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gaji_freelance`
--

LOCK TABLES `gaji_freelance` WRITE;
/*!40000 ALTER TABLE `gaji_freelance` DISABLE KEYS */;
INSERT INTO `gaji_freelance` VALUES (3,2,'2022-12',540000,1,50000,50000,NULL,1,25000,25000,NULL,1,25000,25000,NULL,3,500000,1500000,NULL,0,0,0,NULL,1,100000,100000,NULL,1,125000,125000,NULL,1,125000,125000,NULL,1,125000,125000,NULL,1,125000,125000,NULL,2740000,500000,2240000),(4,2,'2023-01',360000,5,50000,250000,NULL,10,25000,250000,NULL,20,25000,500000,NULL,2,500000,1000000,NULL,0,0,0,NULL,0,100000,0,NULL,0,125000,0,NULL,0,125000,0,NULL,0,125000,0,NULL,0,125000,0,NULL,2360000,0,2360000);
/*!40000 ALTER TABLE `gaji_freelance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gaji_freelance_absen_kerja`
--

DROP TABLE IF EXISTS `gaji_freelance_absen_kerja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `gaji_freelance_absen_kerja` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_gaji_freelance` int(11) DEFAULT NULL,
  `bulan` char(7) DEFAULT NULL,
  `tanggal` text DEFAULT NULL,
  `kehadiran` text DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gaji_freelance_absen_kerja`
--

LOCK TABLES `gaji_freelance_absen_kerja` WRITE;
/*!40000 ALTER TABLE `gaji_freelance_absen_kerja` DISABLE KEYS */;
INSERT INTO `gaji_freelance_absen_kerja` VALUES (2,3,'2022-12','[\"01\",\"02\",\"03\",\"04\",\"05\",\"06\",\"07\",\"08\",\"09\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\",\"23\",\"24\",\"25\",\"26\",\"27\",\"28\",\"29\",\"30\",\"31\"]','[\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\"]','[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null]'),(3,4,'2023-01','[\"01\",\"02\",\"03\",\"04\",\"05\",\"06\",\"07\",\"08\",\"09\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\",\"23\",\"24\",\"25\",\"26\",\"27\",\"28\",\"29\",\"30\",\"31\"]','[\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"OFF\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"OFF\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"OFF\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"OFF\",\"HADIR\",\"HADIR\",\"HADIR\"]','[null,null,null,null,\"OFF\",null,null,null,null,null,null,\"OFF\",null,null,null,null,null,null,null,\"OFF\",null,null,null,null,null,null,null,\"OFF\",null,null,null]');
/*!40000 ALTER TABLE `gaji_freelance_absen_kerja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gaji_freelance_mengajar`
--

DROP TABLE IF EXISTS `gaji_freelance_mengajar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `gaji_freelance_mengajar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_gaji_freelance` int(11) DEFAULT NULL,
  `nama_siswa` varchar(80) DEFAULT NULL,
  `jumlah_pertemuan` int(11) DEFAULT NULL,
  `fee` int(11) DEFAULT NULL,
  `total_fee` int(11) DEFAULT NULL,
  `kelas` varchar(20) DEFAULT NULL,
  `notes` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gaji_freelance_mengajar`
--

LOCK TABLES `gaji_freelance_mengajar` WRITE;
/*!40000 ALTER TABLE `gaji_freelance_mengajar` DISABLE KEYS */;
INSERT INTO `gaji_freelance_mengajar` VALUES (3,3,'Dalmore',4,75000,300000,'DEBUT INTERNATIONAL',NULL),(4,3,'Abdul Haris',3,80000,240000,'REGULAR',NULL),(5,4,'Glen Morangie',4,90000,360000,'Reguler',NULL);
/*!40000 ALTER TABLE `gaji_freelance_mengajar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gaji_fulltime`
--

DROP TABLE IF EXISTS `gaji_fulltime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `gaji_fulltime` (
  `id_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `id_instruktur` int(11) DEFAULT NULL,
  `jabatan` varchar(40) DEFAULT NULL,
  `bulan` char(7) DEFAULT 'AKTIF',
  `gaji_pokok_jml_hari` int(11) DEFAULT NULL,
  `gaji_pokok_per_hari` int(11) DEFAULT NULL,
  `gaji_pokok` int(11) DEFAULT NULL,
  `kehadiran_harian_jml_hari` int(11) DEFAULT NULL,
  `kehadiran_harian_per_hari` int(11) DEFAULT NULL,
  `kehadiran_harian` int(11) DEFAULT NULL,
  `tunj_tambahan_jml_hari` int(11) DEFAULT NULL,
  `tunj_tambahan_per_hari` int(11) DEFAULT NULL,
  `tunj_tambahan` int(11) DEFAULT NULL,
  `bonus_jml_hari` int(11) DEFAULT NULL,
  `bonus_per_hari` int(11) DEFAULT NULL,
  `bonus` int(11) DEFAULT NULL,
  `event_konser_jml_hari` int(11) DEFAULT NULL,
  `event_konser_per_hari` int(11) DEFAULT NULL,
  `event_konser` int(11) DEFAULT NULL,
  `set_up_konser_jml_hari` int(11) DEFAULT NULL,
  `set_up_konser_per_hari` int(11) DEFAULT NULL,
  `set_up_konser` int(11) DEFAULT NULL,
  `set_down_konser_jml_hari` int(11) DEFAULT NULL,
  `set_down_konser_per_hari` int(11) DEFAULT NULL,
  `set_down_konser` int(11) DEFAULT NULL,
  `support_jml_hari` int(11) DEFAULT NULL,
  `support_per_hari` int(11) DEFAULT NULL,
  `support` int(11) DEFAULT NULL,
  `total_1` int(11) DEFAULT NULL,
  `libur_jml_hari` int(11) DEFAULT NULL,
  `libur_per_hari` int(11) DEFAULT NULL,
  `libur` int(11) DEFAULT NULL,
  `sakit_jml_hari` int(11) DEFAULT NULL,
  `sakit_per_hari` int(11) DEFAULT NULL,
  `sakit` int(11) DEFAULT NULL,
  `kasbon` int(11) DEFAULT NULL,
  `total_2` int(11) DEFAULT NULL,
  `lembur_jam_jml_jam` int(11) DEFAULT NULL,
  `lembur_jam_per_jam` int(11) DEFAULT NULL,
  `lembur_jam` int(11) DEFAULT NULL,
  `lembur_hari_jml_hari` int(11) DEFAULT NULL,
  `lembur_hari_per_hari` int(11) DEFAULT NULL,
  `lembur_hari` int(11) DEFAULT NULL,
  `sub_total` int(11) DEFAULT NULL,
  `total_penerimaan` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id_gaji`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gaji_fulltime`
--

LOCK TABLES `gaji_fulltime` WRITE;
/*!40000 ALTER TABLE `gaji_fulltime` DISABLE KEYS */;
INSERT INTO `gaji_fulltime` VALUES (1,1,'Instruktur Trainee','2022-12',1,900000,900000,1,77000,77000,1,21000,21000,1,800000,800000,1,70000,70000,2,125000,250000,2,125000,250000,0,0,0,2368000,0,0,0,1,77000,77000,100000,2191000,1,10000,10000,1,100000,100000,2301000,2301000,'Sakit tgl 20'),(3,1,'Instruktur Trainee','2023-01',1,1000000,1000000,26,77000,2002000,5,21000,105000,1,500000,500000,0,0,0,1,125000,125000,1,125000,125000,0,0,0,3857000,1,500000,500000,0,77000,0,0,3357000,0,10000,0,0,100000,0,3357000,3357000,NULL);
/*!40000 ALTER TABLE `gaji_fulltime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gaji_fulltime_absen_kerja`
--

DROP TABLE IF EXISTS `gaji_fulltime_absen_kerja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `gaji_fulltime_absen_kerja` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_gaji_fulltime` int(11) DEFAULT NULL,
  `bulan` char(7) DEFAULT NULL,
  `tanggal` text DEFAULT NULL,
  `kehadiran` text DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gaji_fulltime_absen_kerja`
--

LOCK TABLES `gaji_fulltime_absen_kerja` WRITE;
/*!40000 ALTER TABLE `gaji_fulltime_absen_kerja` DISABLE KEYS */;
INSERT INTO `gaji_fulltime_absen_kerja` VALUES (1,1,'2022-12','[\"01\",\"02\",\"03\",\"04\",\"05\",\"06\",\"07\",\"08\",\"09\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\",\"23\",\"24\",\"25\",\"26\",\"27\",\"28\",\"29\",\"30\",\"31\"]','[\"OFF\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"OFF\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"OFF\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"EVENT\",\"OFF\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\"]','[\"OFF\",null,null,null,null,null,\"OFF\",null,null,null,null,null,null,null,\"OFF\",null,null,null,null,null,null,null,null,null,\"BW\",\"OFF\",null,null,null,null,null]'),(3,3,'2023-01','[\"01\",\"02\",\"03\",\"04\",\"05\",\"06\",\"07\",\"08\",\"09\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\",\"23\",\"24\",\"25\",\"26\",\"27\",\"28\",\"29\",\"30\",\"31\"]','[\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"OFF\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"OFF\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"OFF\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"HADIR\",\"OFF\",\"HADIR\",\"EVENT\"]','[null,null,null,null,null,null,\"OFF\",null,null,null,null,null,null,null,\"OFF\",null,null,null,null,null,null,\"OFF\",null,null,null,null,null,null,\"OFF\",null,\"BW\"]');
/*!40000 ALTER TABLE `gaji_fulltime_absen_kerja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gaji_fulltime_mengajar`
--

DROP TABLE IF EXISTS `gaji_fulltime_mengajar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `gaji_fulltime_mengajar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_gaji_fulltime` int(11) DEFAULT NULL,
  `nama_siswa` varchar(80) DEFAULT NULL,
  `durasi` int(11) DEFAULT NULL,
  `jumlah_pertemuan` int(11) DEFAULT NULL,
  `debut` int(11) DEFAULT NULL,
  `regular` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gaji_fulltime_mengajar`
--

LOCK TABLES `gaji_fulltime_mengajar` WRITE;
/*!40000 ALTER TABLE `gaji_fulltime_mengajar` DISABLE KEYS */;
INSERT INTO `gaji_fulltime_mengajar` VALUES (1,1,'Dalmore',60,3,1,0,'GUITAR'),(2,1,'Abdul Haris',60,3,0,1,'GUITAR'),(6,3,'Glen Morangie',60,4,1,0,NULL);
/*!40000 ALTER TABLE `gaji_fulltime_mengajar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gaji_staff`
--

DROP TABLE IF EXISTS `gaji_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `gaji_staff` (
  `id_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `nama_staff` varchar(80) DEFAULT NULL,
  `jabatan` varchar(40) DEFAULT NULL,
  `dari_bulan` char(7) DEFAULT 'AKTIF',
  `sampai_bulan` char(7) DEFAULT NULL,
  `gaji_pokok_jml_hari` int(11) DEFAULT NULL,
  `gaji_pokok_per_hari` int(11) DEFAULT NULL,
  `gaji_pokok` int(11) DEFAULT NULL,
  `tunj_harian_jml_hari` varchar(45) DEFAULT NULL,
  `tunj_harian_per_hari` int(11) DEFAULT NULL,
  `tunj_harian` int(11) DEFAULT NULL,
  `transport_jml_hari` int(11) DEFAULT NULL,
  `transport_per_hari` int(11) DEFAULT NULL,
  `transport` int(11) DEFAULT NULL,
  `tunj_tambahan_jml_hari` int(11) DEFAULT NULL,
  `tunj_tambahan_per_hari` int(11) DEFAULT NULL,
  `tunj_tambahan` int(11) DEFAULT NULL,
  `bonus_jml_hari` int(11) DEFAULT NULL,
  `bonus_per_hari` int(11) DEFAULT NULL,
  `bonus` int(11) DEFAULT NULL,
  `total_1` int(11) DEFAULT NULL,
  `libur_jml_hari` int(11) DEFAULT NULL,
  `libur_per_hari` int(11) DEFAULT NULL,
  `libur` int(11) DEFAULT NULL,
  `sakit_jml_hari` int(11) DEFAULT NULL,
  `sakit_per_hari` int(11) DEFAULT NULL,
  `sakit` int(11) DEFAULT NULL,
  `kasbon` int(11) DEFAULT NULL,
  `total_2` int(11) DEFAULT NULL,
  `lembur_jam_jml_jam` int(11) DEFAULT NULL,
  `lembur_jam_per_jam` int(11) DEFAULT NULL,
  `lembur_jam` int(11) DEFAULT NULL,
  `lembur_hari_jml_hari` int(11) DEFAULT NULL,
  `lembur_hari_per_hari` int(11) DEFAULT NULL,
  `lembur_hari` int(11) DEFAULT NULL,
  `sub_total` int(11) DEFAULT NULL,
  `total_penerimaan` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id_gaji`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gaji_staff`
--

LOCK TABLES `gaji_staff` WRITE;
/*!40000 ALTER TABLE `gaji_staff` DISABLE KEYS */;
INSERT INTO `gaji_staff` VALUES (1,'Ody','IT','2022-12','2023-01',1,1000000,1000000,'26',20000,520000,26,30000,780000,0,1000000,0,0,500000,0,2300000,2,10000,20000,2,100000,200000,500000,1580000,2,10000,20000,2,10000,20000,1620000,1620000,'Sakit tgl 24');
/*!40000 ALTER TABLE `gaji_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gaji_staff_absen_kerja`
--

DROP TABLE IF EXISTS `gaji_staff_absen_kerja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `gaji_staff_absen_kerja` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_gaji_staff` int(11) DEFAULT NULL,
  `bulan` char(7) DEFAULT NULL,
  `tanggal` text DEFAULT NULL,
  `masuk` text DEFAULT NULL,
  `keluar` text DEFAULT NULL,
  `lembur` text DEFAULT NULL,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gaji_staff_absen_kerja`
--

LOCK TABLES `gaji_staff_absen_kerja` WRITE;
/*!40000 ALTER TABLE `gaji_staff_absen_kerja` DISABLE KEYS */;
INSERT INTO `gaji_staff_absen_kerja` VALUES (1,1,'2022-12','[\"01\",\"02\",\"03\",\"04\",\"05\",\"06\",\"07\",\"08\",\"09\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\",\"23\",\"24\",\"25\",\"26\",\"27\",\"28\",\"29\",\"30\",\"31\"]','[\"08.00\",\"08.00\",\"08.00\",\"OFF\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"OFF\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"OFF\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"OFF\",\"08.00\",\"08.00\"]','[\"17.00\",\"17.00\",\"17.00\",\"OFF\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"OFF\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"OFF\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"OFF\",\"17.00\",\"17.00\"]','[null,null,null,\"OFF\",null,null,null,null,null,null,null,\"OFF\",null,null,null,null,null,null,null,null,null,\"OFF\",null,null,null,null,null,null,\"OFF\",\"2 jam\",\"2 jam\"]',NULL),(2,1,'2023-01','[\"01\",\"02\",\"03\",\"04\",\"05\",\"06\",\"07\",\"08\",\"09\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\",\"23\",\"24\",\"25\",\"26\",\"27\",\"28\",\"29\",\"30\",\"31\"]','[\"08.00\",\"OFF\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"OFF\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"OFF\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"08.00\",\"OFF\"]','[\"17.00\",\"OFF\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"OFF\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"OFF\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"17.00\",\"OFF\"]','[null,\"OFF\",null,null,null,null,null,null,\"OFF\",null,null,null,null,null,null,null,null,null,null,null,\"OFF\",null,null,null,null,null,null,null,\"2 jam\",\"2 jam\",\"OFF\"]','Libur tanggal merah');
/*!40000 ALTER TABLE `gaji_staff_absen_kerja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instruktur`
--

DROP TABLE IF EXISTS `instruktur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `instruktur` (
  `id_instruktur` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengguna` int(11) DEFAULT NULL,
  `id_penempatan` int(11) DEFAULT NULL,
  `id_studio` varchar(60) DEFAULT NULL,
  `id_instrumen` varchar(60) DEFAULT NULL,
  `nama_instruktur` varchar(80) DEFAULT NULL,
  `email_instruktur` varchar(80) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `jenis_kelamin` enum('LAKI-LAKI','PEREMPUAN') DEFAULT NULL,
  `jenis_instruktur` enum('FULL TIME','FREELANCE') DEFAULT NULL,
  PRIMARY KEY (`id_instruktur`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instruktur`
--

LOCK TABLES `instruktur` WRITE;
/*!40000 ALTER TABLE `instruktur` DISABLE KEYS */;
INSERT INTO `instruktur` VALUES (1,5,1,'[\"1\"]','[\"2\",\"3\",\"4\"]','REYMOND','instruktur@gmail.com','0818350485','LAKI-LAKI','FULL TIME'),(2,8,1,'[\"1\",\"6\"]','[\"1\",\"2\"]','JILL','glenlivet@gmail.com','0818350111','LAKI-LAKI','FREELANCE'),(3,13,1,'[\"1\",\"2\"]','[\"1\"]','OLA','ola@gmail.com','0818350485','PEREMPUAN','FULL TIME'),(4,14,1,'[\"1\",\"2\"]','[\"1\"]','AGHI','aghi@gmail.com','0818350485','LAKI-LAKI','FULL TIME'),(5,15,1,'[\"1\",\"2\"]','[\"1\"]','TURAH','turah@gmail.com','0818350485','LAKI-LAKI','FULL TIME'),(6,16,2,'[\"9\",\"10\"]','[\"1\"]','SAMUSU','samusu@gmail.com','0818350485','LAKI-LAKI','FREELANCE'),(7,22,1,'[\"1\",\"2\"]','[\"1\"]','HONEY','honey@gmail.com','0818350485','LAKI-LAKI','FULL TIME'),(8,23,1,'[\"1\",\"2\"]','[\"1\"]','WHERDA','wherda@gmail.com','0818350485','LAKI-LAKI','FREELANCE'),(9,24,1,'[\"1\",\"2\"]','[\"1\"]','PADMA','padma@gmail.com','0818350485','LAKI-LAKI','FULL TIME'),(10,25,1,'[\"1\",\"2\"]','[\"1\"]','SANTI','santi@gmail.com','0818350485','LAKI-LAKI','FREELANCE');
/*!40000 ALTER TABLE `instruktur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instrumen`
--

DROP TABLE IF EXISTS `instrumen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `instrumen` (
  `id_instrumen` int(11) NOT NULL AUTO_INCREMENT,
  `nama_instrumen` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id_instrumen`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instrumen`
--

LOCK TABLES `instrumen` WRITE;
/*!40000 ALTER TABLE `instrumen` DISABLE KEYS */;
INSERT INTO `instrumen` VALUES (1,'DRUM'),(2,'GUITAR'),(3,'BIOLA'),(4,'PIANO'),(5,'DANCE'),(6,'THEATRE'),(7,'VLOG'),(8,'MUSIC PRODUCTION'),(9,'VOCAL');
/*!40000 ALTER TABLE `instrumen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jadwal`
--

DROP TABLE IF EXISTS `jadwal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `jadwal` (
  `id_jadwal` int(11) NOT NULL AUTO_INCREMENT,
  `id_instruktur` int(11) DEFAULT NULL,
  `id_studio` int(11) DEFAULT NULL,
  `id_instrumen` int(11) DEFAULT NULL,
  `bulan` char(8) DEFAULT NULL,
  `hari` enum('SENIN','SELASA','RABU','KAMIS','JUMAT','SABTU','MINGGU') DEFAULT NULL,
  `jam_mulai` char(5) DEFAULT NULL,
  `jam_selesai` char(5) DEFAULT NULL,
  PRIMARY KEY (`id_jadwal`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jadwal`
--

LOCK TABLES `jadwal` WRITE;
/*!40000 ALTER TABLE `jadwal` DISABLE KEYS */;
INSERT INTO `jadwal` VALUES (17,3,1,1,'2023-01','SENIN','11:00','13:00'),(18,3,1,1,'2023-01','SENIN','14:00','16:00'),(19,2,2,1,'2023-01','SELASA','10:00','12:00'),(20,2,1,1,'2023-01','SENIN','16:00','18:00'),(21,2,1,1,'2023-01','RABU','10:00','12:00'),(22,2,1,1,'2023-01','KAMIS','10:00','12:00'),(23,2,1,1,'2023-01','JUMAT','10:00','12:00'),(24,2,2,1,'2023-01','SABTU','12:00','14:00'),(25,4,4,1,'2023-01','SENIN','10:00','11:00'),(26,4,2,1,'2023-01','SENIN','11:00','12:00'),(27,4,2,1,'2023-01','SABTU','11:00','12:00'),(28,4,1,1,'2023-01','SABTU','14:00','16:00'),(29,5,2,1,'2023-01','SABTU','17:00','18:00'),(30,5,2,1,'2023-01','JUMAT','13:00','15:00'),(31,1,6,2,'2023-01','JUMAT','10:00','12:00'),(32,1,8,2,'2023-01','SABTU','12:00','13:00'),(33,3,2,1,'2023-01','JUMAT','19:00','20:00'),(34,3,2,1,'2023-01','SABTU','19:00','20:00'),(35,4,2,1,'2023-01','JUMAT','18:00','19:00'),(36,4,2,1,'2023-01','SABTU','18:00','19:00'),(37,5,2,1,'2023-01','JUMAT','17:00','18:00'),(38,2,1,1,'2023-02','SELASA','10:00','12:00'),(39,3,2,1,'2023-02','RABU','12:00','14:00');
/*!40000 ALTER TABLE `jadwal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jadwal_harian`
--

DROP TABLE IF EXISTS `jadwal_harian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `jadwal_harian` (
  `id_jadwal_harian` int(11) NOT NULL AUTO_INCREMENT,
  `id_penempatan` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `note2` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `merge` text DEFAULT NULL,
  `cells` text DEFAULT NULL,
  `column` text DEFAULT NULL,
  `style` text DEFAULT NULL,
  PRIMARY KEY (`id_jadwal_harian`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jadwal_harian`
--

LOCK TABLES `jadwal_harian` WRITE;
/*!40000 ALTER TABLE `jadwal_harian` DISABLE KEYS */;
/*!40000 ALTER TABLE `jadwal_harian` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jadwal_pengubahan`
--

DROP TABLE IF EXISTS `jadwal_pengubahan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `jadwal_pengubahan` (
  `id_jadwal_pengubahan` int(11) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(11) DEFAULT NULL,
  `id_jadwal_sebelum` int(11) DEFAULT NULL,
  `id_jadwal_setelah` int(11) DEFAULT NULL,
  `tanggal_sebelum` date DEFAULT NULL,
  `tanggal_setelah` date DEFAULT NULL,
  `jam_sebelum` char(11) DEFAULT NULL,
  `jam_setelah` char(11) DEFAULT NULL,
  `status` enum('MENUNGGU KONFIRMASI','DIKONFIRMASI','DITOLAK') DEFAULT 'MENUNGGU KONFIRMASI',
  `waktu_pengajuan` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_jadwal_pengubahan`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jadwal_pengubahan`
--

LOCK TABLES `jadwal_pengubahan` WRITE;
/*!40000 ALTER TABLE `jadwal_pengubahan` DISABLE KEYS */;
INSERT INTO `jadwal_pengubahan` VALUES (1,3,38,39,'2023-02-14','2023-02-08','10:30-11:00','12:00-12:30','DIKONFIRMASI','2023-02-06 04:07:01'),(2,3,38,38,'2023-02-07','2023-02-07','10:30-11:00','11:00-11:30','MENUNGGU KONFIRMASI','2023-02-07 11:10:02');
/*!40000 ALTER TABLE `jadwal_pengubahan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jadwal_siswa`
--

DROP TABLE IF EXISTS `jadwal_siswa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `jadwal_siswa` (
  `id_jadwal_siswa` int(11) NOT NULL AUTO_INCREMENT,
  `id_jadwal` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `jam_mulai` char(5) DEFAULT NULL,
  `jam_selesai` char(5) DEFAULT NULL,
  PRIMARY KEY (`id_jadwal_siswa`)
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jadwal_siswa`
--

LOCK TABLES `jadwal_siswa` WRITE;
/*!40000 ALTER TABLE `jadwal_siswa` DISABLE KEYS */;
INSERT INTO `jadwal_siswa` VALUES (1,17,1,'2023-01-02','11:00','11:30'),(2,17,1,'2023-01-09','11:00','11:30'),(3,17,1,'2023-01-16','11:00','11:30'),(4,17,1,'2023-01-23','11:00','11:30'),(5,17,3,'2023-01-02','11:30','12:00'),(6,17,3,'2023-01-09','11:30','12:00'),(7,17,3,'2023-01-16','11:30','12:00'),(8,17,3,'2023-01-23','11:30','12:00'),(9,17,5,'2023-01-02','12:00','12:30'),(10,17,5,'2023-01-09','12:00','12:30'),(11,17,5,'2023-01-16','12:00','12:30'),(12,17,5,'2023-01-23','11:30','12:00'),(13,17,7,'2023-01-02','12:30','13:00'),(14,17,7,'2023-01-09','12:30','13:00'),(15,17,7,'2023-01-16','12:30','13:00'),(16,17,7,'2023-01-23','12:30','13:00'),(17,23,8,'2023-01-06','10:00','10:30'),(18,23,8,'2023-01-13','10:00','10:30'),(19,23,8,'2023-01-20','10:00','10:30'),(20,23,8,'2023-01-27','10:00','10:30'),(21,23,9,'2023-01-06','10:00','10:30'),(22,23,9,'2023-01-13','10:00','10:30'),(23,23,9,'2023-01-20','10:00','10:30'),(24,23,9,'2023-01-27','10:00','10:30'),(25,23,10,'2023-01-06','10:30','11:00'),(26,23,10,'2023-01-13','10:30','11:00'),(27,23,10,'2023-01-20','10:30','11:00'),(28,23,10,'2023-01-27','10:30','11:00'),(29,23,11,'2023-01-06','11:00','12:00'),(30,23,11,'2023-01-13','11:00','12:00'),(31,23,11,'2023-01-20','11:00','12:00'),(32,23,11,'2023-01-27','11:00','12:00'),(33,24,5,'2023-01-07','12:00','12:30'),(34,24,5,'2023-01-14','12:00','12:30'),(35,24,5,'2023-01-21','12:00','12:30'),(36,24,5,'2023-01-28','12:00','12:30'),(37,24,8,'2023-01-07','12:30','13:00'),(38,24,8,'2023-01-14','12:30','13:00'),(39,24,8,'2023-01-21','12:30','13:00'),(40,24,8,'2023-01-28','12:30','13:00'),(41,24,9,'2023-01-07','13:00','13:30'),(42,24,9,'2023-01-14','13:00','13:30'),(43,24,9,'2023-01-21','13:00','13:30'),(44,24,9,'2023-01-28','13:00','13:30'),(45,24,11,'2023-01-07','13:30','14:00'),(46,24,11,'2023-01-14','13:30','14:00'),(47,24,11,'2023-01-21','13:30','14:00'),(48,24,11,'2023-01-28','13:30','14:00'),(49,27,10,'2023-01-07','11:00','12:00'),(50,27,10,'2023-01-14','11:00','12:00'),(51,27,10,'2023-01-21','11:00','12:00'),(52,27,10,'2023-01-28','11:00','12:00'),(53,27,11,'2023-01-07','11:00','12:00'),(54,27,11,'2023-01-14','11:00','12:00'),(55,27,11,'2023-01-21','11:00','12:00'),(56,27,11,'2023-01-28','11:00','12:00'),(57,18,1,'2023-01-02','14:00','14:30'),(58,18,1,'2023-01-09','14:00','14:30'),(59,18,1,'2023-01-16','14:00','14:30'),(60,18,1,'2023-01-23','14:00','14:30'),(61,18,3,'2023-01-02','14:30','15:00'),(62,18,3,'2023-01-09','14:30','15:00'),(63,18,3,'2023-01-16','14:30','15:00'),(64,18,3,'2023-01-23','14:30','15:00'),(65,18,8,'2023-01-02','15:00','15:30'),(66,18,8,'2023-01-09','15:00','15:30'),(67,18,8,'2023-01-16','15:00','15:30'),(68,18,8,'2023-01-23','15:00','15:30'),(69,18,9,'2023-01-02','15:30','16:00'),(70,18,9,'2023-01-09','15:30','16:00'),(71,18,9,'2023-01-16','15:30','16:00'),(72,18,9,'2023-01-23','15:30','16:00'),(73,28,1,'2023-01-07','14:00','15:00'),(74,28,1,'2023-01-14','14:00','15:00'),(75,28,1,'2023-01-21','14:00','15:00'),(76,28,1,'2023-01-28','14:00','15:00'),(77,28,5,'2023-01-07','14:00','15:00'),(78,28,5,'2023-01-14','14:00','15:00'),(79,28,5,'2023-01-21','14:00','15:00'),(80,28,5,'2023-01-28','14:00','15:00'),(81,28,7,'2023-01-07','15:00','16:00'),(82,28,7,'2023-01-14','15:00','16:00'),(83,28,7,'2023-01-21','15:00','16:00'),(84,28,7,'2023-01-28','15:00','16:00'),(85,28,9,'2023-01-07','15:00','16:00'),(86,28,9,'2023-01-14','15:00','16:00'),(87,28,9,'2023-01-21','15:00','16:00'),(88,28,9,'2023-01-28','15:00','16:00'),(89,30,1,'2023-01-06','13:00','13:30'),(90,30,1,'2023-01-13','13:00','13:30'),(91,30,1,'2023-01-20','13:00','13:30'),(92,30,1,'2023-01-27','13:00','13:30'),(93,29,8,'2023-01-07','17:00','17:30'),(94,29,8,'2023-01-14','17:00','17:30'),(95,29,8,'2023-01-21','17:00','17:30'),(96,29,8,'2023-01-28','17:00','17:30'),(97,29,11,'2023-01-07','17:30','18:00'),(98,29,11,'2023-01-14','17:30','18:00'),(99,29,11,'2023-01-21','17:30','18:00'),(100,29,11,'2023-01-28','17:30','18:00'),(101,31,2,'2023-01-06','10:00','11:00'),(102,31,2,'2023-01-13','10:00','11:00'),(103,31,2,'2023-01-20','10:00','11:00'),(104,31,2,'2023-01-27','10:00','11:00'),(105,31,6,'2023-01-06','11:00','12:00'),(106,31,6,'2023-01-13','11:00','12:00'),(107,31,6,'2023-01-20','11:00','12:00'),(108,31,6,'2023-01-27','11:00','12:00'),(109,32,2,'2023-01-07','12:00','12:30'),(110,32,2,'2023-01-14','12:00','12:30'),(111,32,2,'2023-01-21','12:00','12:30'),(112,32,2,'2023-01-28','12:00','12:30'),(113,32,6,'2023-01-07','12:30','13:00'),(114,32,6,'2023-01-14','12:30','13:00'),(115,32,6,'2023-01-21','12:30','13:00'),(116,32,6,'2023-01-28','12:30','13:00'),(117,33,9,'2023-01-06','19:30','20:00'),(118,33,9,'2023-01-13','19:30','20:00'),(119,33,9,'2023-01-20','19:30','20:00'),(120,33,9,'2023-01-27','19:30','20:00'),(121,33,11,'2023-01-06','19:00','19:30'),(122,33,11,'2023-01-13','19:00','19:30'),(123,33,11,'2023-01-20','19:00','19:30'),(124,33,11,'2023-01-27','19:00','19:30'),(125,34,3,'2023-01-07','19:00','19:30'),(126,34,3,'2023-01-14','19:00','19:30'),(127,34,3,'2023-01-21','19:00','19:30'),(128,34,3,'2023-01-28','19:00','19:30'),(129,34,5,'2023-01-07','19:30','20:00'),(130,34,5,'2023-01-14','19:30','20:00'),(131,34,5,'2023-01-21','19:30','20:00'),(132,34,5,'2023-01-28','19:30','20:00'),(133,35,11,'2023-01-06','18:00','19:00'),(134,35,11,'2023-01-13','18:00','19:00'),(135,35,11,'2023-01-20','18:00','19:00'),(136,35,11,'2023-01-27','18:00','19:00'),(137,37,10,'2023-01-06','17:00','18:00'),(138,37,10,'2023-01-13','17:00','18:00'),(139,37,10,'2023-01-20','17:00','18:00'),(140,37,10,'2023-01-27','17:00','18:00'),(141,38,1,'2023-02-07','10:00','10:30'),(142,38,1,'2023-02-14','10:00','10:30'),(143,38,1,'2023-02-21','10:00','10:30'),(144,38,1,'2023-02-28','10:00','10:30'),(145,38,3,'2023-02-07','10:30','11:00'),(147,38,3,'2023-02-21','10:30','11:00'),(148,38,3,'2023-02-28','10:30','11:00'),(149,38,5,'2023-02-07','11:00','11:30'),(150,38,5,'2023-02-14','11:00','11:30'),(151,38,5,'2023-02-21','11:00','11:30'),(152,38,5,'2023-02-28','11:00','11:30'),(153,38,7,'2023-02-07','11:30','12:00'),(154,38,7,'2023-02-14','11:30','12:00'),(155,38,7,'2023-02-21','11:30','12:00'),(156,38,7,'2023-02-28','11:30','12:00'),(157,39,8,'2023-02-01','12:00','12:30'),(158,39,8,'2023-02-08','12:00','12:30'),(159,39,8,'2023-02-15','12:00','12:30'),(160,39,8,'2023-02-22','12:00','12:30'),(161,39,9,'2023-02-01','12:30','13:00'),(162,39,9,'2023-02-08','12:30','13:00'),(163,39,9,'2023-02-15','12:30','13:00'),(164,39,9,'2023-02-22','12:30','13:00'),(165,39,3,'2023-02-08','12:00','12:30');
/*!40000 ALTER TABLE `jadwal_siswa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kelas`
--

DROP TABLE IF EXISTS `kelas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `kelas` (
  `id_kelas` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kelas` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id_kelas`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kelas`
--

LOCK TABLES `kelas` WRITE;
/*!40000 ALTER TABLE `kelas` DISABLE KEYS */;
INSERT INTO `kelas` VALUES (1,'DEBUT'),(2,'GROUP CLASS'),(3,'DEBUT INTERNATIONAL'),(4,'REGULAR'),(5,'INTERNATIONAL'),(6,'SPECIAL NEED'),(7,'MASTER CLASS');
/*!40000 ALTER TABLE `kelas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `penempatan`
--

DROP TABLE IF EXISTS `penempatan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `penempatan` (
  `id_penempatan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_penempatan` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id_penempatan`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `penempatan`
--

LOCK TABLES `penempatan` WRITE;
/*!40000 ALTER TABLE `penempatan` DISABLE KEYS */;
INSERT INTO `penempatan` VALUES (1,'PENAMPARAN'),(2,'RENON'),(3,'TABANAN'),(4,'JIMBARAN');
/*!40000 ALTER TABLE `penempatan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pengguna`
--

DROP TABLE IF EXISTS `pengguna`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `pengguna` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(80) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(60) NOT NULL,
  `foto_profile` varchar(60) DEFAULT NULL,
  `level_user` enum('ADMIN','GENERAL ADMIN','ACCOUNTING','INSTRUKTUR','SISWA') DEFAULT NULL,
  `status` enum('AKTIF','NONAKTIF') DEFAULT 'AKTIF',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pengguna`
--

LOCK TABLES `pengguna` WRITE;
/*!40000 ALTER TABLE `pengguna` DISABLE KEYS */;
INSERT INTO `pengguna` VALUES (1,'Admin','admin','$2y$10$dp0BrqVPO8S79feyy8Vjj.gCT9jkE1mVAwnOgVyHXgp3.SKydDOCq','storage/foto_profile/1667395175.jpg','GENERAL ADMIN','AKTIF'),(2,'Azrul Ananda','azrul','$2y$10$AjF.1INIpRCHMljxGPCOtOiRAR.E5fdSYn81bG/dCXKJMqq0QLqI2','storage/foto_profile/1667390529.jpg','ADMIN','AKTIF'),(3,'Hatten','accounting','$2y$10$Z0UzSrhb3BGh2MY50ewQ0OxHGTnCe9pcD3.ea5WqOnP7ojjUphmEy','storage/foto_profile/1667488363.jpg','ACCOUNTING','AKTIF'),(4,'Macallan','azrul_ananda','$2y$10$sh3KQT7RHcXiECwqpXDjNeBZehyK1RmauYu29hrzZ7rFzjaq8q8wC','storage/foto_profile/1667488954.jpg','ACCOUNTING','AKTIF'),(5,'REYMOND','instruktur','$2y$10$.xWe6yFD6vAKzr.W3UCD1ORP6/A4GkbIs5A5/hOwCEbWBfVGeTspq','storage/foto_profile/1667554452.jpg','INSTRUKTUR','AKTIF'),(6,'KYRON','arunika','$2y$10$RQ/UVDg/X9JVi/y2w4.w6eJ1zr5B5bb/5R/xL2b9aTIS3Pq7UpvWq','storage/foto_profile/1667572137.jpg','SISWA','AKTIF'),(7,'PT JUNA','dalmore','$2y$10$3zovoEhL3kaNwX.IVXjwHeevruqBClIvLYGTUjPGcfziIZRFT9jye','storage/foto_profile/1667570062.jpg','SISWA','AKTIF'),(8,'JILL','glenlivet','$2y$10$feGaBe5HkB.hbh/fL7istOUcds8FZIlEUVOQVU2.bEq0SY7teuJRC','storage/foto_profile/1669245732.jpg','INSTRUKTUR','AKTIF'),(9,'HUNI','anggaalvian','$2y$10$6UAYkqS5DQcW15ugrGtG9ePI7fIJObOOeoklWJPX1HYzwUCwgf8.W','storage/foto_profile/1669277926.jpg','SISWA','AKTIF'),(10,'KEANU','alvah','$2y$10$GSBXnCV.jc6C6.sJRZYEY.ysc1NLm7gkoeXc8bYYQ/yKayDh5IRd6','storage/foto_profile/1669278007.jpg','SISWA','AKTIF'),(11,'PRISHA','AlfonsoRyan','$2y$10$dTF7hh0qoJsAFa1Lt4Md/OxbOS2BK.dkbi9APgugCDsFyEwe3/WBC','storage/foto_profile/1669278074.jpg','SISWA','AKTIF'),(12,'LUNA','AbdulHaris','$2y$10$aUdF75nMUkSmJf.6TaY7YuRKNF.l3nuYesAUDJaxfLBeVLdGMr5Gu','storage/foto_profile/1669278115.jpg','SISWA','AKTIF'),(13,'OLA','ola','$2y$10$cYOc2ko2w.Sd1I47u/P77uruYn944/HsSdF5hIg7Cmdkb216eO2X.','storage/foto_profile/1674643741.jpg','INSTRUKTUR','AKTIF'),(14,'AGHI','aghi','$2y$10$ulLLb59/1zqAYn/Tyfo.ROE85rhnNVUL./6.Wx7g0tEBcCrPNSc8.','storage/foto_profile/1674643805.jpg','INSTRUKTUR','AKTIF'),(15,'TURAH','turah','$2y$10$JDJjA6SQglbYdtyEt.iOTeGmLo2Zue/aVF8d5RgcIMoT2k9ORaooa','storage/foto_profile/1674643866.jpg','INSTRUKTUR','AKTIF'),(16,'SAMUSU','samusu','$2y$10$rZWVEIsRVh2ZKICw8.vviexJeJVXtzXpcEC2bLYcpDDuqCTSGLvjK','storage/foto_profile/1674643972.jpg','INSTRUKTUR','AKTIF'),(17,'KHEN','khen','$2y$10$QKqxJXkZDlJT838B7YWwdOl8oSI0mWexUdswApDEf73RAcLt9Ncou','storage/foto_profile/1674820191.jpg','SISWA','AKTIF'),(18,'WARREN','warren','$2y$10$QKqxJXkZDlJT838B7YWwdOl8oSI0mWexUdswApDEf73RAcLt9Ncou','storage/foto_profile/1674820152.jpg','SISWA','AKTIF'),(19,'JERRY','jerry','$2y$10$QKqxJXkZDlJT838B7YWwdOl8oSI0mWexUdswApDEf73RAcLt9Ncou','storage/foto_profile/1674820161.jpg','SISWA','AKTIF'),(20,'NAREN','naren','$2y$10$QKqxJXkZDlJT838B7YWwdOl8oSI0mWexUdswApDEf73RAcLt9Ncou','storage/foto_profile/1674820169.jpg','SISWA','AKTIF'),(21,'TURAH','turah','$2y$10$QKqxJXkZDlJT838B7YWwdOl8oSI0mWexUdswApDEf73RAcLt9Ncou','storage/foto_profile/1674820182.jpg','SISWA','AKTIF'),(22,'HONEY','honey','$2y$10$feGaBe5HkB.hbh/fL7istOUcds8FZIlEUVOQVU2.bEq0SY7teuJRC','storage/foto_profile/1669245732.jpg','INSTRUKTUR','AKTIF'),(23,'WHERDA','wherda','$2y$10$feGaBe5HkB.hbh/fL7istOUcds8FZIlEUVOQVU2.bEq0SY7teuJRC','storage/foto_profile/1669245732.jpg','INSTRUKTUR','AKTIF'),(24,'PADMA','padma','$2y$10$feGaBe5HkB.hbh/fL7istOUcds8FZIlEUVOQVU2.bEq0SY7teuJRC','storage/foto_profile/1669245732.jpg','INSTRUKTUR','AKTIF'),(25,'SANTI','santi','$2y$10$feGaBe5HkB.hbh/fL7istOUcds8FZIlEUVOQVU2.bEq0SY7teuJRC','storage/foto_profile/1669245732.jpg','INSTRUKTUR','AKTIF');
/*!40000 ALTER TABLE `pengguna` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting_menu`
--

DROP TABLE IF EXISTS `setting_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `setting_menu` (
  `level_user` enum('ADMIN','GENERAL ADMIN','ACCOUNTING','INSTRUKTUR','SISWA') NOT NULL,
  `aksi` char(50) NOT NULL,
  `status` enum('AKTIF','NONAKTIF') DEFAULT 'AKTIF',
  PRIMARY KEY (`level_user`,`aksi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting_menu`
--

LOCK TABLES `setting_menu` WRITE;
/*!40000 ALTER TABLE `setting_menu` DISABLE KEYS */;
INSERT INTO `setting_menu` VALUES ('ADMIN','CREATE ACCOUNTING','AKTIF'),('ADMIN','KONFIRMASI ABSENSI SISWA','NONAKTIF'),('ADMIN','MENU ABSENSI SISWA','NONAKTIF'),('ADMIN','MENU ACCOUNTING','AKTIF'),('ADMIN','MENU ADMIN','NONAKTIF'),('ADMIN','MENU INSTRUKTUR','AKTIF'),('ADMIN','MENU INSTRUMEN','NONAKTIF'),('ADMIN','MENU KELAS','NONAKTIF'),('ADMIN','MENU PENEMPATAN','NONAKTIF'),('ADMIN','MENU STUDIO','NONAKTIF'),('GENERAL ADMIN','CETAK SLIP GAJI INSTRUKTUR FULLTIME','AKTIF'),('GENERAL ADMIN','CETAK SLIP GAJI STAFF','AKTIF'),('GENERAL ADMIN','CREATE & UPDATE SISWA JADWAL MENGAJAR','AKTIF'),('GENERAL ADMIN','CREATE ACCOUNTING','AKTIF'),('GENERAL ADMIN','CREATE ADMIN','AKTIF'),('GENERAL ADMIN','CREATE INSTRUKTUR','AKTIF'),('GENERAL ADMIN','CREATE INSTRUMEN','AKTIF'),('GENERAL ADMIN','CREATE JADWAL MENGAJAR','AKTIF'),('GENERAL ADMIN','CREATE KELAS','AKTIF'),('GENERAL ADMIN','CREATE PENEMPATAN','AKTIF'),('GENERAL ADMIN','CREATE SISWA','AKTIF'),('GENERAL ADMIN','CREATE STUDIO','AKTIF'),('GENERAL ADMIN','DELETE INSTRUMEN','AKTIF'),('GENERAL ADMIN','DELETE JADWAL MENGAJAR','AKTIF'),('GENERAL ADMIN','DELETE KELAS','AKTIF'),('GENERAL ADMIN','DELETE PENEMPATAN','AKTIF'),('GENERAL ADMIN','DELETE STUDIO','AKTIF'),('GENERAL ADMIN','EDIT SLIP GAJI INSTRUKTUR FULLTIME','AKTIF'),('GENERAL ADMIN','EDIT SLIP GAJI STAFF','AKTIF'),('GENERAL ADMIN','HAPUS SLIP GAJI INSTRUKTUR FULLTIME','AKTIF'),('GENERAL ADMIN','HAPUS SLIP GAJI STAFF','AKTIF'),('GENERAL ADMIN','INPUT SLIP GAJI INSTRUKTUR FULLTIME','AKTIF'),('GENERAL ADMIN','INPUT SLIP GAJI STAFF','AKTIF'),('GENERAL ADMIN','KONFIRMASI ABSENSI SISWA','NONAKTIF'),('GENERAL ADMIN','KONFIRMASI PENGUBAHAN JADWAL','AKTIF'),('GENERAL ADMIN','MENU ABSENSI SISWA','NONAKTIF'),('GENERAL ADMIN','MENU ACCOUNTING','AKTIF'),('GENERAL ADMIN','MENU ADMIN','AKTIF'),('GENERAL ADMIN','MENU INSTRUKTUR','AKTIF'),('GENERAL ADMIN','MENU INSTRUMEN','AKTIF'),('GENERAL ADMIN','MENU JADWAL HARIAN','AKTIF'),('GENERAL ADMIN','MENU JADWAL MENGAJAR','AKTIF'),('GENERAL ADMIN','MENU PENGUBAHAN JADWAL','AKTIF'),('GENERAL ADMIN','MENU SISWA','AKTIF'),('GENERAL ADMIN','MENU UBAH KATA SANDI','AKTIF'),('GENERAL ADMIN','MENU UBAH PROFIL','AKTIF'),('GENERAL ADMIN','NONAKTIFKAN ACCOUNTING','AKTIF'),('GENERAL ADMIN','NONAKTIFKAN ADMIN','AKTIF'),('GENERAL ADMIN','NONAKTIFKAN INSTRUKTUR','AKTIF'),('GENERAL ADMIN','NONAKTIFKAN SISWA','AKTIF'),('GENERAL ADMIN','PRINT JADWAL HARIAN','AKTIF'),('GENERAL ADMIN','RESET JADWAL HARIAN','AKTIF'),('GENERAL ADMIN','UPDATE ACCOUNTING','AKTIF'),('GENERAL ADMIN','UPDATE ADMIN','AKTIF'),('GENERAL ADMIN','UPDATE INSTRUKTUR','AKTIF'),('GENERAL ADMIN','UPDATE INSTRUMEN','AKTIF'),('GENERAL ADMIN','UPDATE JADWAL HARIAN','AKTIF'),('GENERAL ADMIN','UPDATE JADWAL MENGAJAR','AKTIF'),('GENERAL ADMIN','UPDATE KELAS','AKTIF'),('GENERAL ADMIN','UPDATE PENEMPATAN','AKTIF'),('GENERAL ADMIN','UPDATE SISWA','AKTIF'),('GENERAL ADMIN','UPDATE STUDIO','AKTIF'),('ACCOUNTING','KONFIRMASI ABSENSI SISWA','AKTIF'),('ACCOUNTING','MENU ABSENSI SISWA','AKTIF'),('INSTRUKTUR','EDIT ABSENSI SISWA','AKTIF'),('INSTRUKTUR','INPUT ABSENSI SISWA','AKTIF'),('SISWA','ADD PENGUBAHAN JADWAL','AKTIF');
/*!40000 ALTER TABLE `setting_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `siswa`
--

DROP TABLE IF EXISTS `siswa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `siswa` (
  `id_siswa` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengguna` int(11) DEFAULT NULL,
  `id_penempatan` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `id_instrumen` int(11) DEFAULT NULL,
  `nama_siswa` varchar(80) DEFAULT NULL,
  `email_siswa` varchar(80) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `sekolah` varchar(80) DEFAULT NULL,
  `jenis_kelamin` enum('LAKI-LAKI','PEREMPUAN') DEFAULT NULL,
  `alamat` varchar(180) DEFAULT NULL,
  `email_orangtua` varchar(80) DEFAULT NULL,
  `no_hp_orangtua` varchar(20) DEFAULT NULL,
  `tangan_dominan` enum('KANAN','KIRI') DEFAULT NULL,
  `sosial_media` text DEFAULT NULL,
  PRIMARY KEY (`id_siswa`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `siswa`
--

LOCK TABLES `siswa` WRITE;
/*!40000 ALTER TABLE `siswa` DISABLE KEYS */;
INSERT INTO `siswa` VALUES (1,6,1,7,1,'KYRON','crithfey_idemoto@gmail.com','2009-11-30','Bali Kiddy','LAKI-LAKI','Jalan Raya Danau','trisnawati@gmail.com','0818350485','KANAN','{\"instagram\":\"arunika1\",\"twitter\":\"arunika2\",\"facebook\":\"arunika3\",\"youtube\":\"arunika4\"}'),(2,7,1,3,2,'PT JUNA','admin@dalmore.id','2002-11-24','Jembatan Budaya School','LAKI-LAKI','Jalan Raya Danau','azrul_ananda@gmail.com','0818350485','KIRI','{\"instagram\":\"dalmore\",\"twitter\":\"dalmore\",\"facebook\":\"dalmore\",\"youtube\":\"dalmore\"}'),(3,9,1,1,1,'HUNI','anggaalvian@gmail.com','2002-11-30','CHIS Bali','LAKI-LAKI','Jalan Raya Danau','glenlivet@gmail.com','0818350111','KANAN','{\"instagram\":null,\"twitter\":null,\"facebook\":null,\"youtube\":null}'),(4,10,2,1,1,'KEANU','alvah@gmail.com','2002-11-29','CHIS Bali','LAKI-LAKI','Jalan Raya Danau','trisnawati@gmail.com','0818350485','KANAN','{\"instagram\":null,\"twitter\":null,\"facebook\":null,\"youtube\":null}'),(5,11,1,1,1,'PRISHA','AlfonsoRyan@gmail.com','2002-11-28','Jembatan Budaya School','LAKI-LAKI','Perum Kampial Indah Blok A / 38 B Nusa Dua Kuta Selatan 80363','glenlivet@gmail.com','0818350111','KIRI','{\"instagram\":null,\"twitter\":null,\"facebook\":null,\"youtube\":null}'),(6,12,1,4,2,'LUNA','AbdulHaris@gmail.com','2002-11-02','Bali Kiddy','LAKI-LAKI','Jalan Raya Danau','nyobaaja800@gmail.com','+62818350485','KANAN','{\"instagram\":null,\"twitter\":null,\"facebook\":null,\"youtube\":null}'),(7,17,1,4,1,'KHEN','samusu@gmail.com','2005-01-31','Jembatan Budaya School','LAKI-LAKI','Perum Kampial Indah Blok A / 38 B Nusa Dua Kuta Selatan 80363','samusu@gmail.com','0818350485','KANAN','{\"instagram\":null,\"twitter\":null,\"facebook\":null,\"youtube\":null}'),(8,18,1,4,1,'WARREN','samusu@gmail.com','2005-01-31','Jembatan Budaya School','LAKI-LAKI','Perum Kampial Indah Blok A / 38 B Nusa Dua Kuta Selatan 80363','samusu@gmail.com','0818350485','KANAN','{\"instagram\":null,\"twitter\":null,\"facebook\":null,\"youtube\":null}'),(9,19,1,4,1,'JERRY','samusu@gmail.com','2005-01-31','Jembatan Budaya School','LAKI-LAKI','Perum Kampial Indah Blok A / 38 B Nusa Dua Kuta Selatan 80363','samusu@gmail.com','0818350485','KANAN','{\"instagram\":null,\"twitter\":null,\"facebook\":null,\"youtube\":null}'),(10,20,1,4,1,'NAREN','samusu@gmail.com','2005-01-31','Jembatan Budaya School','LAKI-LAKI','Perum Kampial Indah Blok A / 38 B Nusa Dua Kuta Selatan 80363','samusu@gmail.com','0818350485','KANAN','{\"instagram\":null,\"twitter\":null,\"facebook\":null,\"youtube\":null}'),(11,21,1,4,1,'TURAH','samusu@gmail.com','2005-01-31','Jembatan Budaya School','LAKI-LAKI','Perum Kampial Indah Blok A / 38 B Nusa Dua Kuta Selatan 80363','samusu@gmail.com','0818350485','KANAN','{\"instagram\":null,\"twitter\":null,\"facebook\":null,\"youtube\":null}');
/*!40000 ALTER TABLE `siswa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `studio`
--

DROP TABLE IF EXISTS `studio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `studio` (
  `id_studio` int(11) NOT NULL AUTO_INCREMENT,
  `id_penempatan` int(11) DEFAULT NULL,
  `id_instrumen` varchar(60) DEFAULT NULL,
  `nama_studio` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id_studio`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `studio`
--

LOCK TABLES `studio` WRITE;
/*!40000 ALTER TABLE `studio` DISABLE KEYS */;
INSERT INTO `studio` VALUES (1,1,'[\"1\"]','ST1 PENAMPARAN'),(2,1,'[\"1\"]','ST2 PENAMPARAN'),(3,1,'[\"3\",\"4\",\"9\"]','ST3 PENAMPARAN'),(4,1,'[\"1\"]','ST4 PENAMPARAN'),(5,1,'[\"3\",\"5\",\"6\",\"9\"]','ST5 PENAMPARAN'),(6,1,'[\"2\",\"3\",\"9\"]','ST6 PENAMPARAN'),(7,1,'[\"3\",\"7\",\"8\"]','ST7 PENAMPARAN'),(8,1,'[\"2\",\"3\",\"4\",\"9\"]','ST8 PENAMPARAN'),(9,2,'[\"1\"]','ST1 RENON'),(10,2,'[\"2\"]','ST2 RENON'),(11,2,'[\"4\"]','ST3 RENON'),(12,2,'[\"1\"]','ST4 RENON'),(13,2,'[\"1\"]','ST5 RENON'),(14,4,'[\"4\",\"9\"]','ST1 JIMBARAN'),(15,4,'[\"2\"]','ST2 JIMBARAN'),(16,4,'[\"1\"]','ST3 JIMBARAN'),(17,3,'[\"4\"]','ST1 TABANAN'),(18,3,'[\"9\"]','ST2 TABANAN'),(19,3,'[\"2\"]','ST3 TABANAN'),(20,3,'[\"1\"]','ST4 TABANAN');
/*!40000 ALTER TABLE `studio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'bali_rudiment'
--

--
-- Dumping routines for database 'bali_rudiment'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-10  0:04:25
