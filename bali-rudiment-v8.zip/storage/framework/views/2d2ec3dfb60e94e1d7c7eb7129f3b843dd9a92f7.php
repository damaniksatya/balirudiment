<?php $__env->startSection('title','Input/Edit Data Mengajar'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php
  $back_url = request()->get('back_url');
?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(url($back_url ?: 'slip-gaji/fulltime')); ?>">Slip Gaji Instruktur Full Time</a></li>
                  <li class="breadcrumb-item active">Input/Edit Data Mengajar</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="<?php echo e(url($back_url ?: 'slip-gaji/fulltime')); ?>">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input/Edit Data Mengajar
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <form class="row" method="post" action="<?php echo e(url('slip-gaji/fulltime/mengajar')); ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="id_gaji_fulltime" value="<?php echo e($info->id_gaji); ?>">
      <input type="hidden" name="back_url" value="<?php echo e($back_url); ?>">
      <input type="hidden" name="jumlah_data" value="<?php echo e(count($data) + \App\GajiFulltimeMengajar::ADDITION_ROW); ?>">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body pb-0">
            <table class="mb-3">
              <tr>
                <td>Nama</td>
                <td class="text-center" style="width: 15px">:</td>
                <td><?php echo e($info->instruktur->nama_instruktur); ?></td>
              </tr>
              <tr>
                <td>Jabatan</td>
                <td class="text-center">:</td>
                <td><?php echo e($info->jabatan); ?></td>
              </tr>
              <tr>
                <td>Bulan</td>
                <td class="text-center">:</td>
                <td><?php echo e(\App\Http\Controllers\HelperController::setNamaBulan($info->bulan)); ?></td>
              </tr>
            </table>
            <table class="table table-sm table-bordered">
              <thead>
              <tr>
                <th class="text-center" style="width: 30px">No</th>
                <th class="text-center">Nama Siswa</th>
                <th class="text-center" style="width: 70px">Durasi (Menit)</th>
                <th class="text-center" style="width: 100px">Jumlah Pertemuan</th>
                <th class="text-center" style="width: 70px">Debut</th>
                <th class="text-center" style="width: 70px">Regular</th>
                <th class="text-center">Notes</th>
              </tr>
              </thead>
              <tbody>
              <?php for($index=0; $index<(count($data) + \App\GajiFulltimeMengajar::ADDITION_ROW); $index++): ?>
                <?php
                  $exists = array_key_exists($index, $data);
                  if($exists){
                    $t = $data[$index];
                  }
                  else{
                    $t = [
                      'id' => null,
                      'nama_siswa' => null,
                      'durasi' => null,
                      'jumlah_pertemuan' => null,
                      'debut' => null,
                      'regular' => null,
                      'notes' => null,
                    ];
                  };
                ?>
                <input type="hidden" name="id<?php echo e($index); ?>" value="<?php echo e($t['id']); ?>">
                <tr>
                  <td class="text-center"><?php echo e($index+1); ?></td>
                  <td class="p-1">
                    <input type="text" class="form-control form-control-sm"
                           value="<?php echo e($t['nama_siswa']); ?>"
                           title="Masukkan Nama Siswa" name="nama_siswa<?php echo e($index); ?>">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-center"
                           value="<?php echo e($t['durasi']); ?>" min="0"
                           title="Masukkan Durasi Mengajar" name="durasi<?php echo e($index); ?>">
                  </td>
                  <td class="p-1">
                    <input type="text" class="form-control form-control-sm text-center" min="0"
                           value="<?php echo e($t['jumlah_pertemuan']); ?>"
                           title="Masukkan Jumlah Pertemuan" name="jumlah_pertemuan<?php echo e($index); ?>">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-center" min="0"
                           value="<?php echo e($t['debut']); ?>"
                           title="Masukkan Jumlah Debut" name="debut<?php echo e($index); ?>">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-center" min="0"
                           value="<?php echo e($t['regular']); ?>"
                           title="Masukkan Jumlah Regular" name="regular<?php echo e($index); ?>">
                  </td>
                  <td class="p-1">
                    <input type="text" class="form-control form-control-sm"
                           value="<?php echo e($t['notes']); ?>"
                           title="Notes" name="notes<?php echo e($index); ?>">
                  </td>
                </tr>
              <?php endfor; ?>
              </tbody>
            </table>
            <div class="form-group text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-12 mb-3 mt-0">
        
        
        
        
        
      </div>
    </form>

  </div>

  <style>
    /* Chrome, Safari, Edge, Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }

    /* Firefox */
    input[type=number] {
      -moz-appearance: textfield;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();

      function changeOff(bln, tgl, is_checked) {
          $(`[name=masuk-${bln}-${tgl}]`).val(is_checked ? 'OFF' : null);
          $(`[name=keluar-${bln}-${tgl}]`).val(is_checked ? 'OFF' : null);
          $(`[name=lembur-${bln}-${tgl}]`).val(is_checked ? 'OFF' : null);

          if(is_checked){
              $(`#td-off-${bln}-${tgl}`).show();
              $(`#td-masuk-${bln}-${tgl}`).hide();
              $(`#td-keluar-${bln}-${tgl}`).hide();
              $(`#td-lembur-${bln}-${tgl}`).hide();
          }
          else{
              $(`#td-off-${bln}-${tgl}`).hide();
              $(`#td-masuk-${bln}-${tgl}`).show();
              $(`#td-keluar-${bln}-${tgl}`).show();
              $(`#td-lembur-${bln}-${tgl}`).show();
          }
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>