<?php

namespace App\Http\Controllers;

use App\Admin;
use App\Instruktur;
use App\JadwalHarian;
use App\JadwalSiswa;
use App\Penempatan;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class JadwalHarianController extends Controller
{
  public function index()
  {
    $level_user = Auth::user()->level_user;
    $data_penempatan = Penempatan::getData();
    if($level_user == User::L_GENERAL_ADMIN){
      $val = HelperController::getValue('jadwal_harian', ['id_penempatan','tanggal']);
      $tanggal = $val['tanggal'] ? date('Y-m-d', strtotime($val['tanggal'])) : date('Y-m-d');
      $id_penempatan = $val['id_penempatan'] ?: (count($data_penempatan) ? $data_penempatan[0]['id_penempatan'] : null);
      $data = $this->getDataSpreadsheet($tanggal, $id_penempatan);
    }
    elseif($level_user == User::L_ADMIN){
      $val = HelperController::getValue('jadwal_harian', ['tanggal']);
      $tanggal = $val['tanggal'] ? date('Y-m-d', strtotime($val['tanggal'])) : date('Y-m-d');
      $id_penempatan = Admin::getIdPenempatan();
      $data = $this->getDataSpreadsheet($tanggal, $id_penempatan);
    }
//    dd($data);

    return view('pages.jadwal_harian.index')
      ->with('data_penempatan', isset($data_penempatan) ? $data_penempatan : [])
      ->with('tanggal', $tanggal)
      ->with('id_penempatan', $id_penempatan)
      ->with('level_user', $level_user)
      ->with('data', json_encode($data['data']))
      ->with('merge_cell', json_encode($data['merge_cell']))
      ->with('read_only', json_encode($data['read_only']))
      ->with('column', json_encode($data['column']))
      ->with('style', json_encode($data['style']))
      ->with('info', $data['info']);
  }

  public function indexInstruktur()
  {
    $val = HelperController::getValue('jadwal_harian', ['id_penempatan','tanggal']);
    $tanggal = $val['tanggal'] ? date('Y-m-d', strtotime($val['tanggal'])) : date('Y-m-d');
    $id_penempatan = Instruktur::getIdPenempatan();
//    $nama_instruktur = Instruktur::getNamaInstruktur();
    $data = $this->getDataSpreadsheet($tanggal, $id_penempatan);
    $data_penempatan = Penempatan::getData();

    $tanggal_f = HelperController::setNamaBulan(null, $tanggal);
    $hari = HelperController::getNamaHari($tanggal);
    $nama_tempat = Penempatan::getNamaTempat($id_penempatan);
//    dd($data);
    return view('pages.jadwal_harian.index_instruktur')
      ->with('data_penempatan', isset($data_penempatan) ? $data_penempatan : [])
      ->with('tanggal', $tanggal)
      ->with('id_penempatan', $id_penempatan)
      ->with('tanggal_f', $tanggal_f)
      ->with('hari', $hari)
      ->with('nama_tempat', $nama_tempat)
      ->with('data', $data['data'])
      ->with('merge_cell', $data['merge_cell'])
      ->with('read_only', $data['read_only'])
      ->with('column', $data['column'])
      ->with('style', $data['style'])
      ->with('info', $data['info']);
  }

  private function getDataSpreadsheet($tanggal, $id_penempatan)
  {
    $info_jadwal = JadwalHarian::getInfo($tanggal, $id_penempatan);
    if($info_jadwal){
      return [
        'data' => json_decode($info_jadwal->data),
        'merge_cell' => json_decode($info_jadwal->merge, true),
        'read_only' => json_decode($info_jadwal->cells, true),
        'column' => json_decode($info_jadwal->column, true),
        'style' => json_decode($info_jadwal->style, true),
        'info' => $info_jadwal,
      ];
    }

    $data_instruktur = Instruktur::getDataAktif($id_penempatan);
    $header = [['JAM'],['']];
    $body = [];

    foreach ($data_instruktur as $index=>$d){
      $header[0][] = $d->nama_instruktur;
      $header[0][] = '';
      $header[1][] = 'MURID';
      $header[1][] = 'ST';
    }

    $header[0][] = 'JAM';
    $header[1][] = '';

    $param = [
      'tanggal' => $tanggal,
      'id_penempatan' => $id_penempatan
    ];
//    dd($param);

    foreach(JadwalHarian::$jam_ke as $index_jam=>$jam){
      $temp = [$jam];
      $param['jam_mulai'] = $jam;
      $param['jam_selesai'] = HelperController::getNextJam($jam);
      foreach ($data_instruktur as $index_instruktur=>$instruktur){
        $param['id_instruktur'] = $instruktur->id_instruktur;
        $data_jadwal_siswa = JadwalSiswa::getNamaSiswaJadwalHarian($param);
        $temp[] = $data_jadwal_siswa['nama_siswa'];
        $temp[] = $data_jadwal_siswa['no_studio'];
      }
      $temp[] = $jam;
      $body[] = $temp;
    }

    $data = array_merge($header, $body);
    $merge_cell = $this->setMergeCell($data_instruktur, $data);
    $read_only = $this->setReadOnly($data);
    $column = $this->setColumnWidth($data_instruktur);

//    dd($header, $merge_cell, $body, $read_only);
    return [
      'data' => $data,
      'merge_cell' => $merge_cell,
      'read_only' => $read_only,
      'column' => $column,
      'style' => [],
      'info' => null
    ];
  }

  private function setColumnWidth($data_instruktur)
  {
    $result = [['width' => '45px']];
    foreach ($data_instruktur as $index=>$d){
      $result[] = ['width' => '150px'];
      $result[] = ['width' => '30px'];
    }
    $result[] = ['width' => '45px'];

    return $result;
  }

  private function setReadOnly($data)
  {
    $result = [];
    foreach ($data as $index=>$d){
      foreach($d as $index2=>$a){
        if($index <= 1 || $index2 == 0 || count($d) == $index2+1){
          $column = HelperController::getColumnAlphabeticalNameByNumber($index2+1);
          $row = $index+1;
          $result[$column.$row] = ['readonly'=>true];
        }
      }
    }
    return $result;
  }

  private function setMergeCell($data_instruktur, $data)
  {
    $merge_cell = [];
    foreach ($data_instruktur as $index=>$d){
      $number_column = ($index + 1) * 2;
      $column_alphabet = HelperController::getColumnAlphabeticalNameByNumber($number_column);
      $merge_cell[$column_alphabet.'1'] = [2,1]; //Merge Nama Instruktur
    }

    $column_alphabet = HelperController::getColumnAlphabeticalNameByNumber(count($data[0]));
    $merge_cell['A1'] = [1, 2]; //Merge Jam Ke
    $merge_cell[$column_alphabet.'1'] = [1, 2]; //Merge Jam Ke

//    for($row=0; $row<count($data); $row++){
//      for($col=0; $col<count($data[$row]); $col++){
//
//      }
//    }
//    dd($data);

    return $merge_cell;
  }

  public function store(Request $req)
  {
//    return $req;
    $data_column = [];
    foreach($req->column as $c){
      $data_column[] = ['width'=>$c];
    }
    $data_cells = [];
    foreach($req->cells as $key=>$c){
      $data_cells[$key] = ['readonly' => true];
    }

    JadwalHarian::insertOrUpdate([
      'id_penempatan' => $req->id_penempatan,
      'tanggal' => date('Y-m-d', strtotime($req->tanggal)),
      'note' => $req->note,
      'note2' => $req->note2,
      'data' => json_encode($req->data),
      'merge' => $req->merge ? json_encode($req->merge) : '{}',
      'cells' => $data_cells ? json_encode($data_cells) : '{}',
      'column' => json_encode($data_column),
      'style' => $req->style ? json_encode($req->style) : '{}',
    ]);

    return response()->json('Berhasil menyimpan data', 200);
  }

  public function printJadwal(Request $req)
  {
    $data = $this->getDataSpreadsheet($req->tanggal, $req->id_penempatan);
    $data['tanggal'] = $req->tanggal;
    $data['tanggal_f'] = HelperController::setNamaBulan(null, $req->tanggal);
    $data['hari'] = HelperController::getNamaHari($req->tanggal);
    $data['nama_tempat'] = Penempatan::getNamaTempat($req->id_penempatan);
//    dd($data);

    $pdf = \App::make('dompdf.wrapper');
    $pdf->setPaper('a4', 'landscape');
    $pdf->loadView('pdf.jadwal_harian', $data);
    return $pdf->stream("Jadwal Harian.pdf");
  }

  public function resetJadwal(Request $req)
  {
    JadwalHarian::deleteData($req->id_penempatan, $req->tanggal);
    return back()->with('success','Berhasil reset jadwal');
  }
}
