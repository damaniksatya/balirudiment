@extends('layouts.main')

@section('title','Input/Edit Data Mengajar')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@php
  $back_url = request()->get('back_url');
@endphp

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="{{ url($back_url ?: 'slip-gaji/fulltime') }}">Slip Gaji Instruktur Full Time</a></li>
                  <li class="breadcrumb-item active">Input/Edit Data Mengajar</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="{{ url($back_url ?: 'slip-gaji/fulltime') }}">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input/Edit Data Mengajar
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <form class="row" method="post" action="{{ url('slip-gaji/fulltime/mengajar') }}">
      @csrf
      <input type="hidden" name="id_gaji_fulltime" value="{{ $info->id_gaji }}">
      <input type="hidden" name="back_url" value="{{ $back_url }}">
      <input type="hidden" name="jumlah_data" value="{{ count($data) + \App\GajiFulltimeMengajar::ADDITION_ROW }}">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body pb-0">
            <table class="mb-3">
              <tr>
                <td>Nama</td>
                <td class="text-center" style="width: 15px">:</td>
                <td>{{ $info->instruktur->nama_instruktur }}</td>
              </tr>
              <tr>
                <td>Jabatan</td>
                <td class="text-center">:</td>
                <td>{{ $info->jabatan }}</td>
              </tr>
              <tr>
                <td>Bulan</td>
                <td class="text-center">:</td>
                <td>{{ \App\Http\Controllers\HelperController::setNamaBulan($info->bulan) }}</td>
              </tr>
            </table>
            <table class="table table-sm table-bordered">
              <thead>
              <tr>
                <th class="text-center" style="width: 30px">No</th>
                <th class="text-center">Nama Siswa</th>
                <th class="text-center" style="width: 70px">Durasi (Menit)</th>
                <th class="text-center" style="width: 100px">Jumlah Pertemuan</th>
                <th class="text-center" style="width: 70px">Debut</th>
                <th class="text-center" style="width: 70px">Regular</th>
                <th class="text-center">Notes</th>
              </tr>
              </thead>
              <tbody>
              @for($index=0; $index<(count($data) + \App\GajiFulltimeMengajar::ADDITION_ROW); $index++)
                @php
                  $exists = array_key_exists($index, $data);
                  if($exists){
                    $t = $data[$index];
                  }
                  else{
                    $t = [
                      'id' => null,
                      'nama_siswa' => null,
                      'durasi' => null,
                      'jumlah_pertemuan' => null,
                      'debut' => null,
                      'regular' => null,
                      'notes' => null,
                    ];
                  };
                @endphp
                <input type="hidden" name="id{{ $index }}" value="{{ $t['id'] }}">
                <tr>
                  <td class="text-center">{{ $index+1 }}</td>
                  <td class="p-1">
                    <input type="text" class="form-control form-control-sm"
                           value="{{ $t['nama_siswa'] }}"
                           title="Masukkan Nama Siswa" name="nama_siswa{{ $index }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-center"
                           value="{{ $t['durasi'] }}" min="0"
                           title="Masukkan Durasi Mengajar" name="durasi{{ $index }}">
                  </td>
                  <td class="p-1">
                    <input type="text" class="form-control form-control-sm text-center" min="0"
                           value="{{ $t['jumlah_pertemuan'] }}"
                           title="Masukkan Jumlah Pertemuan" name="jumlah_pertemuan{{ $index }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-center" min="0"
                           value="{{ $t['debut'] }}"
                           title="Masukkan Jumlah Debut" name="debut{{ $index }}">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-center" min="0"
                           value="{{ $t['regular'] }}"
                           title="Masukkan Jumlah Regular" name="regular{{ $index }}">
                  </td>
                  <td class="p-1">
                    <input type="text" class="form-control form-control-sm"
                           value="{{ $t['notes'] }}"
                           title="Notes" name="notes{{ $index }}">
                  </td>
                </tr>
              @endfor
              </tbody>
            </table>
            <div class="form-group text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-12 mb-3 mt-0">
        {{--<div class="card">--}}
        {{--<div class="card-body text-right">--}}
        {{--<button type="submit" class="btn btn-primary">Simpan</button>--}}
        {{--</div>--}}
        {{--</div>--}}
      </div>
    </form>

  </div>

  <style>
    /* Chrome, Safari, Edge, Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }

    /* Firefox */
    input[type=number] {
      -moz-appearance: textfield;
    }
  </style>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();

      function changeOff(bln, tgl, is_checked) {
          $(`[name=masuk-${bln}-${tgl}]`).val(is_checked ? 'OFF' : null);
          $(`[name=keluar-${bln}-${tgl}]`).val(is_checked ? 'OFF' : null);
          $(`[name=lembur-${bln}-${tgl}]`).val(is_checked ? 'OFF' : null);

          if(is_checked){
              $(`#td-off-${bln}-${tgl}`).show();
              $(`#td-masuk-${bln}-${tgl}`).hide();
              $(`#td-keluar-${bln}-${tgl}`).hide();
              $(`#td-lembur-${bln}-${tgl}`).hide();
          }
          else{
              $(`#td-off-${bln}-${tgl}`).hide();
              $(`#td-masuk-${bln}-${tgl}`).show();
              $(`#td-keluar-${bln}-${tgl}`).show();
              $(`#td-lembur-${bln}-${tgl}`).show();
          }
      }
  </script>
@endsection