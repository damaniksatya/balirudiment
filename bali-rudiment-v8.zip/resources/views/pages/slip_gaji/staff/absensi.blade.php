@extends('layouts.main')

@section('title','Input/Edit Data Absensi')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="{{ url('slip-gaji/staff') }}">Absensi</a></li>
                  <li class="breadcrumb-item active">Input/Edit</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="{{ url('slip-gaji/staff') }}">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input/Edit Absensi
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <form class="row" method="post" action="{{ url('slip-gaji/staff/absensi') }}">
      @csrf
      <input type="hidden" name="id_gaji_staff" value="{{ $info->id_gaji }}">
      <input type="hidden" name="arr_tgl" value="{{ json_encode($arr_tgl) }}">
      @foreach($data as $bln=>$d)
        <div class="col-lg-6">
          <div class="card">
            <div class="card-body pb-0">
              <table class="mb-3">
                <tr>
                  <td>Nama</td>
                  <td class="text-center" style="width: 15px">:</td>
                  <td>{{ $info->nama_staff }}</td>
                </tr>
                <tr>
                  <td>Jabatan</td>
                  <td class="text-center">:</td>
                  <td>{{ $info->jabatan }}</td>
                </tr>
                <tr>
                  <td>Bulan</td>
                  <td class="text-center">:</td>
                  <td>{{ \App\Http\Controllers\HelperController::setNamaBulan($bln) }}</td>
                </tr>
              </table>
              <table class="table table-sm table-bordered">
                <thead>
                <tr>
                  <th class="text-center">Tanggal</th>
                  <th class="text-center">Masuk</th>
                  <th class="text-center">Keluar</th>
                  <th class="text-center">Lembur</th>
                  <th class="text-center">Off</th>
                </tr>
                </thead>
                <tbody>
                @foreach($d['data'] as $tgl=>$t)
                  <tr>
                    <td class="text-center">{{ $tgl }}</td>
                    @php
                      $is_off = $t['masuk'] == 'OFF' && $t['keluar'] == 'OFF' && $t['lembur'] == 'OFF';
                    @endphp
                    <td colspan="3" id="td-off-{{ $bln }}-{{ $tgl }}" class="text-center bg-soft-danger" style="display: {{ $is_off ? 'table-cell' : 'none' }};">
                      <div style="padding: 3px">OFF</div>
                    </td>
                    <td class="p-1" id="td-masuk-{{ $bln }}-{{ $tgl }}" style="display: {{ !$is_off ? 'table-cell' : 'none' }}">
                      <input type="text" class="form-control form-control-sm"
                             value="{{ $t['masuk'] }}"
                             {{--value="08.00"--}}
                             title="Masuk Tanggal {{ $tgl }}" name="masuk-{{ $bln }}-{{ $tgl }}">
                    </td>
                    <td class="p-1" id="td-keluar-{{ $bln }}-{{ $tgl }}" style="display: {{ !$is_off ? 'table-cell' : 'none' }}">
                      <input type="text" class="form-control form-control-sm"
                             value="{{ $t['keluar'] }}"
                             {{--value="17.00"--}}
                             title="Keluar Tanggal {{ $tgl }}" name="keluar-{{ $bln }}-{{ $tgl }}">
                    </td>
                    <td class="p-1" id="td-lembur-{{ $bln }}-{{ $tgl }}" style="display: {{ !$is_off ? 'table-cell' : 'none' }}">
                      <input type="text" class="form-control form-control-sm" value="{{ $t['lembur'] }}"
                             title="Lembur Tanggal {{ $tgl }}" name="lembur-{{ $bln }}-{{ $tgl }}">
                    </td>
                    <td class="text-center">
                      <div class="custom-control custom-checkbox" style="margin-left: 7px; cursor: pointer">
                        <input type="checkbox" class="custom-control-input" id="off-{{ $bln }}-{{ $tgl }}"
                               onchange="changeOff('{{ $bln }}','{{ $tgl }}', this.checked)" {{ $is_off ? 'checked' : '' }}>
                        <label class="custom-control-label" style="cursor: pointer" for="off-{{ $bln }}-{{ $tgl }}"></label>
                      </div>
                    </td>
                  </tr>
                @endforeach
                </tbody>
              </table>
              <div class="form-group">
                <label class="col-form-label" for="note">Note</label>
                <textarea name="note-{{ $bln }}" id="note" class="form-control" rows="5">{{ $d['note'] }}</textarea>
              </div>
            </div>
          </div>
        </div>
      @endforeach
      <div class="col-lg-12 mb-3 mt-0">
        {{--<div class="card">--}}
          {{--<div class="card-body text-right">--}}
            <button type="submit" class="btn btn-primary">Simpan</button>
          {{--</div>--}}
        {{--</div>--}}
      </div>
    </form>

  </div>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();

      function changeOff(bln, tgl, is_checked) {
          $(`[name=masuk-${bln}-${tgl}]`).val(is_checked ? 'OFF' : null);
          $(`[name=keluar-${bln}-${tgl}]`).val(is_checked ? 'OFF' : null);
          $(`[name=lembur-${bln}-${tgl}]`).val(is_checked ? 'OFF' : null);

          if(is_checked){
              $(`#td-off-${bln}-${tgl}`).show();
              $(`#td-masuk-${bln}-${tgl}`).hide();
              $(`#td-keluar-${bln}-${tgl}`).hide();
              $(`#td-lembur-${bln}-${tgl}`).hide();
          }
          else{
              $(`#td-off-${bln}-${tgl}`).hide();
              $(`#td-masuk-${bln}-${tgl}`).show();
              $(`#td-keluar-${bln}-${tgl}`).show();
              $(`#td-lembur-${bln}-${tgl}`).show();
          }
      }
  </script>
@endsection