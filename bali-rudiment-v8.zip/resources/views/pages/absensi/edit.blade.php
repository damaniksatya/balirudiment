@extends('layouts.main')

@section('title','Edit Data Absensi')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="{{ url(request()->get('back_url') ?: 'absensi/instruktur') }}">Absensi</a></li>
                  <li class="breadcrumb-item active">Edit</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="{{ url(request()->get('back_url') ?: 'absensi/instruktur') }}">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Edit Absensi
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="{{ url('absensi') }}">
            @csrf @method('put')
            <input type="hidden" name="id_absensi" value="{{ $info->id_absensi }}">
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_jadwal">Jadwal</label>
                <div class="col-lg-9">
                  <div class="card shadow-none mt-2 mb-0" style="background-color: rgba(0, 0, 0, 0.07)">
                    <div class="card-body">
                      <table class="table table-sm table-borderless mb-0">
                        <tr>
                          <td style="width: 100px">Hari</td>
                          <td class="px-0" style="width: 5px">:</td>
                          <td>{{ $info->jadwal->hari }}</td>
                        </tr>
                        <tr>
                          <td>Tanggal</td>
                          <td class="px-0">:</td>
                          <td>{{ \App\Http\Controllers\HelperController::setNamaBulan(null, $info->tanggal) }}</td>
                        </tr>
                        <tr>
                          <td>Jam</td>
                          <td class="px-0">:</td>
                          <td>{{ $info->jadwal->jam_mulai .'-'. $info->jadwal->jam_selesai }}</td>
                        </tr>
                        <tr>
                          <td>Studio</td>
                          <td class="px-0">:</td>
                          <td>{{ $info->jadwal->nama_studio }}</td>
                        </tr>
                        <tr>
                          <td>Instrumen</td>
                          <td class="px-0">:</td>
                          <td>{{ $info->jadwal->nama_instrumen }}</td>
                        </tr>
                        <tr>
                          <td>Instruktur</td>
                          <td class="px-0">:</td>
                          <td>{{ $info->jadwal->nama_instruktur }}</td>
                        </tr>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="report">Report</label>
                <div class="col-lg-9">
                  <textarea id="report" name="report" class="form-control" rows="10" required>{{ old('report') ?: $info->report }}</textarea>
                </div>
              </div>
              <div class="form-group row">
                <div class="col-lg-12">
                  <table class="table table-bordered mb-0">
                    <thead>
                    <tr>
                      <th>Nama Siswa</th>
                      <th colspan="4" class="text-center">Kehadiran</th>
                    </tr>
                    </thead>
                    <tbody>
                    @php $arr_id_siswa = []; @endphp
                    @foreach($data_siswa as $d)
                      @php $arr_id_siswa[] = $d['id_siswa']; @endphp
                      <tr>
                        <td><label class="form-check-label">{{ $d['siswa']['nama_siswa'] }}</label></td>
                        <td>
                          <div class="form-check">
                            <input class="form-check-input" type="radio" name="kehadiran{{ $d['id_siswa'] }}" style="cursor: pointer"
                                   {{ $d['kehadiran'] == \App\Absensi::K_HADIR ? 'checked' : '' }}
                                   id="kehadiran{{ $d['id_siswa'] }}{{ \App\Absensi::K_HADIR }}" value="{{ \App\Absensi::K_HADIR }}" >
                            <label class="form-check-label" for="kehadiran{{ $d['id_siswa'] }}{{ \App\Absensi::K_HADIR }}" style="cursor: pointer">
                              {{ ucwords(strtolower(\App\Absensi::K_HADIR)) }}
                            </label>
                          </div>
                        </td>
                        <td>
                          <div class="form-check">
                            <input class="form-check-input" type="radio" name="kehadiran{{ $d['id_siswa'] }}" style="cursor: pointer"
                                   {{ $d['kehadiran'] == \App\Absensi::K_IZIN ? 'checked' : '' }}
                                   id="kehadiran{{ $d['id_siswa'] }}{{ \App\Absensi::K_IZIN }}" value="{{ \App\Absensi::K_IZIN }}">
                            <label class="form-check-label" for="kehadiran{{ $d['id_siswa'] }}{{ \App\Absensi::K_IZIN }}" style="cursor: pointer">
                              {{ ucwords(strtolower(\App\Absensi::K_IZIN)) }}
                            </label>
                          </div>
                        </td>
                        <td>
                          <div class="form-check">
                            <input class="form-check-input" type="radio" name="kehadiran{{ $d['id_siswa'] }}" style="cursor: pointer"
                                   {{ $d['kehadiran'] == \App\Absensi::K_SAKIT ? 'checked' : '' }}
                                   id="kehadiran{{ $d['id_siswa'] }}{{ \App\Absensi::K_SAKIT }}" value="{{ \App\Absensi::K_SAKIT }}">
                            <label class="form-check-label" for="kehadiran{{ $d['id_siswa'] }}{{ \App\Absensi::K_SAKIT }}" style="cursor: pointer">
                              {{ ucwords(strtolower(\App\Absensi::K_SAKIT)) }}
                            </label>
                          </div>
                        </td>
                        <td>
                          <div class="form-check">
                            <input class="form-check-input" type="radio" name="kehadiran{{ $d['id_siswa'] }}" style="cursor: pointer"
                                   {{ $d['kehadiran'] == \App\Absensi::K_TIDAK_HADIR ? 'checked' : '' }}
                                   id="kehadiran{{ $d['id_siswa'] }}{{ \App\Absensi::K_TIDAK_HADIR }}" value="{{ \App\Absensi::K_TIDAK_HADIR }}">
                            <label class="form-check-label" for="kehadiran{{ $d['id_siswa'] }}{{ \App\Absensi::K_TIDAK_HADIR }}" style="cursor: pointer">
                              {{ ucwords(strtolower(\App\Absensi::K_TIDAK_HADIR)) }}
                            </label>
                          </div>
                        </td>
                      </tr>
                    @endforeach
                    </tbody>
                  </table>

                  <input type="hidden" name="id_siswa" value="{{ json_encode($arr_id_siswa) }}">
                </div>
              </div>
            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();
  </script>
@endsection