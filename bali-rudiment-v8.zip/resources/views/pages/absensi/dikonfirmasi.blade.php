@extends('layouts.main')

@section('title','Data Absensi Dikonfirmasi')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              {{--<div class="page-title-right mt-2 pt-1">--}}
                {{--<a href="{{ url('absensi/add') }}" class="btn btn-primary">--}}
                  {{--<i class="mdi mdi-plus mr-2"></i>Input Data Absensi--}}
                {{--</a>--}}
              {{--</div>--}}
              <h4 class="page-title">Data Absensi Dikonfirmasi</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <form class="form-horizontal" method="get">
              <div class="form-group row mb-0">
                <label class="col-lg-3 text-right col-form-label" for="bulan">Bulan</label>
                <div class="col-lg-9">
                  <select name="bulan" id="bulan" class="form-control select2" onchange="this.form.submit()">
                    <option value="">Pilih Bulan</option>
                    @foreach($data_bulan as $bln)
                      <option value="{{ $bln }}" {{ $bln == $bulan ? 'selected' : '' }}>{{ \App\Http\Controllers\HelperController::setNamaBulan($bln) }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <table class="table table-sm table-bordered mb-0">
              <thead>
              <tr>
                <th>Tanggal</th>
                <th class="text-center">Jam</th>
                <th class="text-center">Durasi</th>
                <th>Studio</th>
                <th>Instrumen</th>
                <th>Instruktur</th>
                <th class="text-center">Fee</th>
                <th class="text-center" style="width: 60px">Aksi</th>
              </tr>
              </thead>
              <tbody>
              @php $total_fee = 0; @endphp
              @foreach($data as $index=>$d)
                @php $total_fee += $d->fee; @endphp
                <tr>
                  <td>{{ \App\Http\Controllers\HelperController::setNamaBulan(null, $d->tanggal) }}</td>
                  <td class="text-center">{{ $d->jadwal->jam_mulai .'-'. $d->jadwal->jam_selesai }}</td>
                  <td class="text-center">{{ $d->durasi_mengajar }} Menit</td>
                  <td>{{ $d->jadwal->nama_studio }}</td>
                  <td>{{ $d->jadwal->nama_instrumen }}</td>
                  <td>{{ $d->jadwal->nama_instruktur }}</td>
                  <td class="text-right font-weight-bold">{{ number_format($d->fee, 0, ',', '.') }}</td>
                  <td class="p-1">
                    <div class="btn-group btn-block">
                      <a href="{{ url('absensi/detail/'.$d->id_absensi.'?back_url='.\Illuminate\Support\Facades\Route::current()->uri) }}"
                         class="btn btn-sm btn-outline-primary">Detail</a>
                    </div>
                  </td>
                </tr>
              @endforeach
              <tr>
                <td colspan="6" class="text-right font-weight-bold">Total Fee</td>
                <td class="text-right font-weight-bold border-right-0">{{ number_format($total_fee, 0, ',', '.') }}</td>
                <td class="border-left-0"></td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection
@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();
  </script>
@endsection