<?php $__env->startSection('title','Edit Data Instruktur'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/dropify/css/dropify.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(url('instruktur')); ?>">Instruktur</a></li>
                  <li class="breadcrumb-item active">Edit</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="<?php echo e(url('instruktur')); ?>">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Edit Instruktur
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="<?php echo e(url('instruktur')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
            <input type="hidden" name="id_pengguna" value="<?php echo e($info->id_pengguna); ?>">
            <input type="hidden" name="username_old" value="<?php echo e($info->username); ?>">
            <input type="hidden" name="email_instruktur_old" value="<?php echo e($info->email_instruktur); ?>">
            <input type="hidden" name="foto_profile_old" value="<?php echo e($info->foto_profile); ?>">
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="nama_instruktur">Nama Instruktur</label>
                <div class="col-lg-9">
                  <input type="text" id="nama_instruktur" name="nama_instruktur" value="<?php echo e(old('nama_instruktur') ?: $info->nama_instruktur); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="username">Username Login</label>
                <div class="col-lg-9">
                  <input type="text" id="username" name="username" value="<?php echo e(old('username') ?: $info->username); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="password">Password</label>
                <div class="col-lg-9">
                  <input type="password" id="password" name="password" class="form-control" autocomplete="off" placeholder="Kosongkan bila tidak ingin mengganti password">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_penempatan">Penempatan</label>
                <div class="col-lg-9">
                  <select name="id_penempatan" id="id_penempatan" class="form-control select2">
                    <option value="">Pilih Penempatan</option>
                    <?php $__currentLoopData = $data_penempatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($l->id_penempatan); ?>" <?php echo e((old('id_penempatan') ?: $info->id_penempatan) == $l->id_penempatan ? 'selected' : ''); ?>><?php echo e($l->nama_penempatan); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_instrumen">Instrumen</label>
                <div class="col-lg-9">
                  <?php
                    if(old('id_instrumen')){
                      $arr_id_instrumen = old('id_instrumen');
                    }
                    else $arr_id_instrumen = $info->id_instrumen != null ? (array)json_decode($info->id_instrumen) : [];
                  ?>
                  <?php $__currentLoopData = $data_instrumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input"
                             <?php echo e(in_array($d->id_instrumen, $arr_id_instrumen) ? 'checked' : ''); ?>

                             id="instrumen<?php echo e($d->id_instrumen); ?>"
                             value="<?php echo e($d->id_instrumen); ?>"
                             name="id_instrumen[]">
                      <label class="custom-control-label" style="cursor: pointer" for="instrumen<?php echo e($d->id_instrumen); ?>"><?php echo e($d->nama_instrumen); ?></label>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_studio">Studio</label>
                <div class="col-lg-9">
                  <?php
                    if(old('id_studio')){
                      $arr_id_studio = old('id_studio');
                    }
                    else $arr_id_studio = $info->id_studio != null ? (array)json_decode($info->id_studio) : [];
                  ?>
                  <?php $__currentLoopData = $data_studio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input"
                             <?php echo e(in_array($d->id_studio, $arr_id_studio) ? 'checked' : ''); ?>

                             id="studio<?php echo e($d->id_studio); ?>"
                             value="<?php echo e($d->id_studio); ?>"
                             name="id_studio[]">
                      <label class="custom-control-label" style="cursor: pointer" for="studio<?php echo e($d->id_studio); ?>"><?php echo e($d->nama_studio); ?></label>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="jenis_kelamin">Jenis Kelamin</label>
                <div class="col-lg-9">
                  <select name="jenis_kelamin" id="jenis_kelamin" class="form-control select2">
                    <option value="">Pilih Jenis Kelamin</option>
                    <?php $__currentLoopData = \App\Instruktur::$jenis_kelamin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($l); ?>" <?php echo e((old('jenis_kelamin') ?: $info->jenis_kelamin) == $l ? 'selected' : ''); ?>><?php echo e($l); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="jenis_instruktur">Jenis Instruktur</label>
                <div class="col-lg-9">
                  <select name="jenis_instruktur" id="jenis_instruktur" class="form-control select2">
                    <option value="">Pilih Jenis Instruktur</option>
                    <?php $__currentLoopData = \App\Instruktur::$jenis_instruktur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($l); ?>" <?php echo e((old('jenis_instruktur') ?: $info->jenis_instruktur) == $l ? 'selected' : ''); ?>><?php echo e($l); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="email_instruktur">Email</label>
                <div class="col-lg-9">
                  <input type="text" id="email_instruktur" name="email_instruktur" value="<?php echo e(old('email_instruktur') ?: $info->email_instruktur); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="no_hp">No HP</label>
                <div class="col-lg-9">
                  <input type="text" id="no_hp" name="no_hp" value="<?php echo e(old('no_hp') ?: $info->no_hp); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="foto_profile">Foto Profil</label>
                <div class="col-lg-9">
                  <input type="file"
                         name="foto_profile"
                         class="dropify dropify-photo"
                         data-height="150"
                         data-show-remove="false"
                         data-allowed-file-extensions="jpg jpeg png"
                         data-max-file-size="1M"
                         <?php echo e($info['foto_profile'] ? 'data-default-file='.url($info['foto_profile']) : ''); ?>

                         accept=".jpg, .jpeg, .png" />
                </div>
              </div>
            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/dropify/js/dropify.min.js')); ?>"></script>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(document).ready(function(){
          $(".select2").select2();
          $('.dropify-photo').dropify({
              messages: {
                  'default': 'Drag & drop foto di sini atau klik',
                  'replace': 'Drag & drop atau klik untuk mengganti foto',
                  'error': 'Hanya format png/jpeg/jpg yang di izinkan'
              },
              error: {
                  'fileSize': 'Ukuran foto melebihi maksimal (1M max).',
              }
          });
      });
      function disableAutoComplete() {
          $("#password").val('');
      }

      setTimeout(disableAutoComplete, 500);
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>