@extends('layouts.main')

@section('title','Data Instruktur')

@php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_instruktur);
  $nonaktif_input = in_array(\App\SettingMenu::CREATE_INSTRUKTUR, $arr_nonaktif);
  $nonaktif_edit = in_array(\App\SettingMenu::UPDATE_INSTRUKTUR, $arr_nonaktif);
  $nonaktif_status = in_array(\App\SettingMenu::NONAKTIFKAN_INSTRUKTUR, $arr_nonaktif);
@endphp

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right mt-2 pt-1">
                @if($nonaktif_input == false)
                  <a href="{{ url('instruktur/add') }}" class="btn btn-primary">
                    <i class="mdi mdi-plus mr-2"></i>Input Data Instruktur
                  </a>
                @endif
              </div>
              <h4 class="page-title">Data Instruktur</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <div class="table-responsive">
              <table id="datatable" class="table mb-0 table-sm table-bordered">
                <thead>
                <tr>
                  <th class="text-center" style="width: 40px">No</th>
                  <th class="">Nama Instruktur</th>
                  <th class="">Penempatan</th>
                  <th class="">Studio</th>
                  <th class="">Instrumen</th>
                  <th class="">Username</th>
                  <th class="">No HP</th>
                  <th class="">L/P</th>
                  @if(!($nonaktif_edit && $nonaktif_status))
                    <th style="width: 80px" class="text">Aksi</th>
                  @endif
                </tr>
                </thead>
                <tbody>
                @foreach($data as $no=>$d)
                  <tr>
                    <td class="text-center">{{ $no+1 }}</td>
                    <td class="p-0" style="vertical-align: top !important;">
                      <table>
                        <tr>
                          <td style="width: 41px" class="border-0 p-0">
                            @if($d['foto_profile'] != null)
                              <div style="background: url('{{ url($d['foto_profile']) }}'); height: 41px;
                                padding-top: 50%;
                                padding-bottom: 50%;
                                background-position: 50% !important;
                                background-size: cover !important;"></div>
                            @endif
                          </td>
                          <td class="border-0 pl-2">{{ $d['nama_instruktur'] }}</td>
                        </tr>
                      </table>
                    </td>
                    <td class="">{{ $d['nama_penempatan'] }}</td>
                    <td class="">{{ $d['nama_studio'] }}</td>
                    <td class="">{{ $d['nama_instrumen'] }}</td>
                    <td class="">{{ $d['username'] }}</td>
                    <td class="">{{ $d['no_hp'] }}</td>
                    <td class="text-center">
                      <span style="padding-top: 5px" class="badge badge-{{ \App\Instruktur::$color[$d['jenis_kelamin']] }}">{{ $d['jenis_kelamin'] }}</span>
                    </td>
                    @if(!($nonaktif_edit && $nonaktif_status))
                      <td>
                        <div class="btn-group btn-block">
                          @if(!$nonaktif_edit)
                            <a href="{{ url('instruktur/edit/'.$d['id_pengguna']) }}" class="btn btn-outline-primary btn-sm px-1">Edit</a>
                          @endif
                          @if(!$nonaktif_status)
                            @if($d['status'] == \App\User::S_AKTIF)
                              <button id="aktif-{{ $d['id_pengguna'] }}" type="button"
                                      style="width: 82px"
                                      class="btn btn-block btn-sm btn-outline-danger px-1">Nonaktifkan</button>
                            @else
                              <button onclick="document.getElementById('form-aktif{{ $d['id_pengguna'] }}').submit()"
                                      style="width: 82px"
                                      type="button" class="btn btn-block btn-sm btn-outline-primary px-1">Aktifkan</button>
                            @endif
                          @endif
                        </div>

                        <form action="{{ url('instruktur/status') }}" id="form-aktif{{ $d['id_pengguna'] }}" method="post">
                          @csrf @method('put')
                          <input type="hidden" name="id" value="{{ $d['id_pengguna'] }}">
                          @if($d['status'] == \App\User::S_AKTIF)
                            <input type="hidden" name="status" value="{{ \App\User::S_NONAKTIF }}">
                          @else
                            <input type="hidden" name="status" value="{{ \App\User::S_AKTIF }}">
                          @endif
                        </form>

                      </td>
                    @endif
                  </tr>
                @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection
@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script>
      @foreach($data as $d)
          @if($d['status'] == \App\User::S_AKTIF)
              $('#aktif-{{ $d['id_pengguna'] }}').click(function(){
                  swal({
                      title: "Anda yakin?",
                      text: "Data instruktur {{ $d['nama_instruktur'] }} yang akan dinonaktifkan, tidak bisa login!",
                      type: "warning",
                      showCancelButton: true,
                      confirmButtonColor: "#F5707A",
                      confirmButtonText: "Ya, nonaktifkan!",
                      cancelButtonText: "Batalkan",
                      closeOnConfirm: false
                  }, function(){
                      $("#form-aktif{{ $d['id_pengguna'] }}").submit();
                  });
              });
          @endif
      @endforeach
  </script>
@endsection