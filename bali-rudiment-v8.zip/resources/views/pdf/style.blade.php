<style>
  *{
    font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";
    font-size: .9rem;
    font-weight: 400;
    /*line-height: 1.5;*/
    color: #495057;
    text-align: left;
  }
  table {
    border-collapse: collapse;
  }

  .table{width:100%;margin-bottom:1rem;color:#495057}.table td,.table th{padding:.75rem;vertical-align:top;border-top:1px solid #C0C6CD;}.table thead th{vertical-align:bottom;border-bottom:2px solid #C0C6CD;font-weight: bold;}.table tbody+tbody{border-top:2px solid #C0C6CD}
  .table-bordered{border:1px solid #C0C6CD}.table-bordered td,.table-bordered th{border:1px solid #C0C6CD}.table-bordered thead td,.table-bordered thead th{border-bottom-width:2px}
  .table-borderless tbody+tbody,.table-borderless td,.table-borderless th,.table-borderless thead th{border:0}
  .table-striped tbody tr:nth-of-type(odd){background-color:rgba(0,0,0,.05)}.table-sm td,.table-sm th{padding:.3rem}
  .table-xs td,.table-xs th{padding:.17rem; font-size: .7rem}

  .w-100 {
    width: 100%!important;
  }
  .bg-light{background-color: #f8f9fa !important;}.bg-secondary{background-color: #D6DCE4 !important;}.bg-warning{background-color:#FFFF00!important}
  .bg-soft-primary{background-color:rgba(100,176,242,.25)!important}.bg-soft-secondary{background-color:rgba(108,117,125,.25)!important}.bg-soft-success{background-color:rgba(27,185,154,.25)!important}
  .bg-soft-info{background-color:rgba(61,185,220,.25)!important}.bg-soft-warning{background-color:rgba(241,181,61,.25)!important}.bg-soft-danger{background-color:rgba(255,93,72,.25)!important}
  .bg-soft-light{background-color:rgba(248,249,250,.25)!important}.bg-soft-dark{background-color:rgba(52,58,64,.25)!important}.bg-soft-purple{background-color:rgba(146,97,198,.25)!important}
  .bg-soft-pink{background-color:rgba(255,122,163,.25)!important}

  .float-left{float:left!important}.float-right{float:right!important}.float-none{float:none!important}
  .font-weight-light{font-weight:300!important}.font-weight-lighter{font-weight:lighter!important}.font-weight-normal{font-weight:400!important}.font-weight-bold{font-weight:700!important}.font-weight-bolder{font-weight:bolder!important}.font-italic{font-style:italic!important}

  .border{border:1px solid #C0C6CD!important}.border-top{border-top:1px solid #C0C6CD!important}.border-right{border-right:1px solid #C0C6CD!important}.border-bottom{border-bottom:1px solid #C0C6CD!important}.border-left{border-left:1px solid #C0C6CD!important}
  .border-0{border:0!important}.border-top-0{border-top:0!important}.border-right-0{border-right:0!important}.border-bottom-0{border-bottom:0!important}.border-left-0{border-left:0!important}

  .text-left{text-align:left!important}.text-right{text-align:right!important}.text-center{text-align:center!important}

  .m-0{margin:0!important}.mt-0,.my-0{margin-top:0!important}.mr-0,.mx-0{margin-right:0!important}.mb-0,.my-0{margin-bottom:0!important}.ml-0,.mx-0{margin-left:0!important}
  .m-1{margin:.25rem!important}.mt-1,.my-1{margin-top:.25rem!important}.mr-1,.mx-1{margin-right:.25rem!important}.mb-1,.my-1{margin-bottom:.25rem!important}.ml-1,.mx-1{margin-left:.25rem!important}
  .m-2{margin:.5rem!important}.mt-2,.my-2{margin-top:.5rem!important}.mr-2,.mx-2{margin-right:.5rem!important}.mb-2,.my-2{margin-bottom:.5rem!important}.ml-2,.mx-2{margin-left:.5rem!important}
  .m-3{margin:1rem!important}.mt-3,.my-3{margin-top:1rem!important}.mr-3,.mx-3{margin-right:1rem!important}.mb-3,.my-3{margin-bottom:1rem!important}.ml-3,.mx-3{margin-left:1rem!important}
  .m-4{margin:1.5rem!important}.mt-4,.my-4{margin-top:1.5rem!important}.mr-4,.mx-4{margin-right:1.5rem!important}.mb-4,.my-4{margin-bottom:1.5rem!important}.ml-4,.mx-4{margin-left:1.5rem!important}
  .m-5{margin:3rem!important}.mt-5,.my-5{margin-top:3rem!important}.mr-5,.mx-5{margin-right:3rem!important}.mb-5,.my-5{margin-bottom:3rem!important}.ml-5,.mx-5{margin-left:3rem!important}

  .p-0{padding:0!important}.pt-0,.py-0{padding-top:0!important}.pr-0,.px-0{padding-right:0!important}.pb-0,.py-0{padding-bottom:0!important}.pl-0,.px-0{padding-left:0!important}
  .p-1{padding:.25rem!important}.pt-1,.py-1{padding-top:.25rem!important}.pr-1,.px-1{padding-right:.25rem!important}.pb-1,.py-1{padding-bottom:.25rem!important}.pl-1,.px-1{padding-left:.25rem!important}
  .p-2{padding:.5rem!important}.pt-2,.py-2{padding-top:.5rem!important}.pr-2,.px-2{padding-right:.5rem!important}.pb-2,.py-2{padding-bottom:.5rem!important}.pl-2,.px-2{padding-left:.5rem!important}
  .p-3{padding:1rem!important}.pt-3,.py-3{padding-top:1rem!important}.pr-3,.px-3{padding-right:1rem!important}.pb-3,.py-3{padding-bottom:1rem!important}.pl-3,.px-3{padding-left:1rem!important}
  .p-4{padding:1.5rem!important}.pt-4,.py-4{padding-top:1.5rem!important}.pr-4,.px-4{padding-right:1.5rem!important}.pb-4,.py-4{padding-bottom:1.5rem!important}.pl-4,.px-4{padding-left:1.5rem!important}
  .p-5{padding:3rem!important}.pt-5,.py-5{padding-top:3rem!important}.pr-5,.px-5{padding-right:3rem!important}.pb-5,.py-5{padding-bottom:3rem!important}.pl-5,.px-5{padding-left:3rem!important}

  .m-n1{margin:-.25rem!important}.mt-n1,.my-n1{margin-top:-.25rem!important}.mr-n1,.mx-n1{margin-right:-.25rem!important}.mb-n1,.my-n1{margin-bottom:-.25rem!important}.ml-n1,.mx-n1{margin-left:-.25rem!important}
  .m-n2{margin:-.5rem!important}.mt-n2,.my-n2{margin-top:-.5rem!important}.mr-n2,.mx-n2{margin-right:-.5rem!important}.mb-n2,.my-n2{margin-bottom:-.5rem!important}.ml-n2,.mx-n2{margin-left:-.5rem!important}
  .m-n3{margin:-1rem!important}.mt-n3,.my-n3{margin-top:-1rem!important}.mr-n3,.mx-n3{margin-right:-1rem!important}.mb-n3,.my-n3{margin-bottom:-1rem!important}.ml-n3,.mx-n3{margin-left:-1rem!important}
  .m-n4{margin:-1.5rem!important}.mt-n4,.my-n4{margin-top:-1.5rem!important}.mr-n4,.mx-n4{margin-right:-1.5rem!important}.mb-n4,.my-n4{margin-bottom:-1.5rem!important}.ml-n4,.mx-n4{margin-left:-1.5rem!important}
  .m-n5{margin:-3rem!important}.mt-n5,.my-n5{margin-top:-3rem!important}.mr-n5,.mx-n5{margin-right:-3rem!important}.mb-n5,.my-n5{margin-bottom:-3rem!important}.ml-n5,.mx-n5{margin-left:-3rem!important}

  .m-auto{margin:auto!important}.mt-auto,.my-auto{margin-top:auto!important}.mr-auto,.mx-auto{margin-right:auto!important}.mb-auto,.my-auto{margin-bottom:auto!important}.ml-auto,.mx-auto{margin-left:auto!important}

  h1, h2, h3, h4, h5, h6 { margin-top: 0; margin-bottom: 0.5rem; }
  .h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6{margin:10px 0;font-weight:bold;font-family:sans-serif;color:#343a40}
  .h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6{margin-bottom:.5rem;font-weight:bold;line-height:1.2}.h1,h1{font-size:2.25rem}.h2,h2{font-size:1.8rem}.h3,h3{font-size:1.575rem}.h4,h4{font-size:1.35rem}.h5,h5{font-size:1.125rem}.h6,h6{font-size:.9rem}
</style>