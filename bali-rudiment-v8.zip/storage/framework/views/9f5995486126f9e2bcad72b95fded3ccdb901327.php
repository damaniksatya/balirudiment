<?php $__env->startSection('title','Data Accounting'); ?>

<?php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_accounting);
  $nonaktif_input = in_array(\App\SettingMenu::CREATE_ACCOUNTING, $arr_nonaktif);
  $nonaktif_edit = in_array(\App\SettingMenu::UPDATE_ACCOUNTING, $arr_nonaktif);
  $nonaktif_status = in_array(\App\SettingMenu::NONAKTIFKAN_ACCOUNTING, $arr_nonaktif);
?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="page-title-right mt-2 pt-1">
            <?php if($nonaktif_input == false): ?>
              <a href="<?php echo e(url('accounting/add')); ?>" class="btn btn-primary">
                <i class="mdi mdi-plus mr-2"></i>Input Data Accounting
              </a>
            <?php endif; ?>
          </div>
          <h4 class="page-title">Data Accounting</h4>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <div class="table-responsive">
              <table id="datatable" class="table mb-0 table-sm table-bordered">
                <thead>
                <tr>
                  <th class="text-center" style="width: 40px">No</th>
                  <th class="">Nama</th>
                  <th>Username</th>
                  <th>No HP</th>
                  <th>Email</th>
                  <th class="text-center">P/L</th>
                  <th class="text-center">Status</th>
                  <?php if(!($nonaktif_edit && $nonaktif_status)): ?>
                    <th style="width: 100px" class="text">Aksi</th>
                  <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-center"><?php echo e($no+1); ?></td>
                    <td class="p-0" style="vertical-align: top !important;">
                      <table>
                        <tr>
                          <td style="width: 41px" class="border-0 p-0">
                            <?php if($d['foto_profile'] != null): ?>
                              <div style="background: url('<?php echo e(url($d['foto_profile'])); ?>'); height: 41px;
                                padding-top: 50%;
                                padding-bottom: 50%;
                                background-position: 50% !important;
                                background-size: cover !important;"></div>
                            <?php endif; ?>
                          </td>
                          <td class="border-0 pl-2"><?php echo e($d['nama_accounting']); ?></td>
                        </tr>
                      </table>
                    </td>
                    <td class=""><?php echo e($d['username']); ?></td>
                    <td class=""><?php echo e($d['no_hp']); ?></td>
                    <td class=""><?php echo e($d['email_accounting']); ?></td>
                    <td class="text-center">
                      <span style="padding-top: 5px" class="badge badge-<?php echo e(\App\Accounting::$color[$d['jenis_kelamin']]); ?>"><?php echo e($d['jenis_kelamin']); ?></span>
                    </td>
                    <td class="text-center">
                      <span style="padding-top: 5px" class="badge badge-<?php echo e(\App\User::$color[$d['status']]); ?>"><?php echo e($d['status']); ?></span>
                    </td>
                    <?php if(!($nonaktif_edit && $nonaktif_status)): ?>
                      <td>
                        <div class="btn-group btn-block">
                          <?php if(!$nonaktif_edit): ?>
                            <a href="<?php echo e(url('accounting/edit/'.$d['id_pengguna'])); ?>" class="btn btn-outline-primary btn-sm">Edit</a>
                          <?php endif; ?>

                          <?php if(!$nonaktif_status): ?>
                            <?php if(Auth::user()->id != $d['id_pengguna']): ?>
                              <?php if($d['status'] == \App\User::S_AKTIF): ?>
                                <button id="aktif-<?php echo e($d['id_pengguna']); ?>" type="button"
                                        style="width: 87px"
                                        class="btn btn-block btn-sm btn-outline-danger">Nonaktifkan</button>
                              <?php else: ?>
                                <button onclick="document.getElementById('form-aktif<?php echo e($d['id_pengguna']); ?>').submit()"
                                        style="width: 87px"
                                        type="button" class="btn btn-block btn-sm btn-outline-primary">Aktifkan</button>
                              <?php endif; ?>
                            <?php endif; ?>
                          <?php endif; ?>
                        </div>

                        <form action="<?php echo e(url('accounting/status')); ?>" id="form-aktif<?php echo e($d['id_pengguna']); ?>" method="post">
                          <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
                          <input type="hidden" name="id" value="<?php echo e($d['id_pengguna']); ?>">
                          <?php if($d['status'] == \App\User::S_AKTIF): ?>
                            <input type="hidden" name="status" value="<?php echo e(\App\User::S_NONAKTIF); ?>">
                          <?php else: ?>
                            <input type="hidden" name="status" value="<?php echo e(\App\User::S_AKTIF); ?>">
                          <?php endif; ?>
                        </form>

                        <form id="form-delete<?php echo e($d['id_pengguna']); ?>" action="<?php echo e(url('accounting')); ?>" method="post">
                          <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                          <input type="hidden" name="id" value="<?php echo e($d['id_pengguna']); ?>">
                        </form>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($d['status'] == \App\User::S_AKTIF): ?>
    $('#aktif-<?php echo e($d['id_pengguna']); ?>').click(function(){
        swal({
            title: "Anda yakin?",
            text: "Data Accounting <?php echo e($d['nama_accounting']); ?> yang akan dinonaktifkan, tidak bisa login!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#F5707A",
            confirmButtonText: "Ya, nonaktifkan!",
            cancelButtonText: "Batalkan",
            closeOnConfirm: false
        }, function(){
            $("#form-aktif<?php echo e($d['id_pengguna']); ?>").submit();
        });
    });
    <?php endif; ?>
    $('#delete-<?php echo e($d['id_pengguna']); ?>').click(function(){
        swal({
            title: "Anda yakin?",
            text: "Data Accounting <?php echo e($d['nama_accounting']); ?> yang akan dihapus, tidak bisa dikembalikan!",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#F5707A",
            confirmButtonText: "Ya, hapus!",
            cancelButtonText: "Batalkan",
            closeOnConfirm: false
        }, function(){
            $("#form-delete<?php echo e($d['id_pengguna']); ?>").submit();
        });
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>