<?php

namespace App\Http\Controllers;

use App\Instrumen;
use Illuminate\Http\Request;

class InstrumenController extends Controller
{
  public function index()
  {
    $data = Instrumen::getData();

    return view('pages.instrumen.index')
      ->with('data', $data);
  }

  public function viewAdd()
  {
    return view('pages.instrumen.add');
  }

  public function viewEdit($id)
  {
    $info = Instrumen::getInfo($id);

    return view('pages.instrumen.edit')
      ->with('info', $info);
  }

  public function store(Request $req)
  {
    $this->validateData();

    Instrumen::insertData([
      'nama_instrumen' => $req->nama_instrumen
    ]);

    return back()->with('success','Berhasil menyimpan data');
  }

  public function update(Request $req)
  {
    $new_nama = $req->nama_instrumen != $req->nama_instrumen_old;
    $this->validateData($new_nama);

    Instrumen::updateData([
      'id_instrumen' => $req->id_instrumen,
      'nama_instrumen' => $req->nama_instrumen
    ]);

    return redirect('instrumen')->with('success','Berhasil menyimpan data');
  }

  public function delete(Request $req)
  {
    Instrumen::deleteData($req->id);

    return back()->with('success','Berhasil menghapus data');
  }

  private function validateData($new_nama = true)
  {
    return request()->validate([
      'nama_instrumen' => 'required|max:40'.($new_nama ? '|unique:instrumen' : '')
    ],[
      'nama_instrumen.required' => 'Nama Instrumen harus diisi!',
      'nama_instrumen.max' => 'Nama Instrumen maksimal :max karakter!',
      'nama_instrumen.unique' => 'Nama Instrumen sudah digunakan!'
    ]);
  }

  public static function implodeNamaInstrumen($id_instrumen)
  {
    $arr_id_instrumen = $id_instrumen != null ? json_decode($id_instrumen) : [];
    $nama_instrumen = [];

    foreach($arr_id_instrumen as $i){
      $temp = Instrumen::getNamaInstrumen($i);
      if($temp != null){
        $nama_instrumen[] = $temp;
      }
    }

    return implode(', ', $nama_instrumen);
  }
}
