<?php $__env->startSection('title','Input Data Jadwal'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(url('jadwal')); ?>">Jadwal</a></li>
                  <li class="breadcrumb-item active">Input</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="<?php echo e(url('jadwal')); ?>">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input Jadwal
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="<?php echo e(url('jadwal')); ?>">
            <?php echo csrf_field(); ?>
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_instruktur">Nama Instruktur</label>
                <div class="col-lg-9">
                  <select name="id_instruktur" id="id_instruktur" class="form-control select2" onchange="getItemInstrumen()">
                    <option value="">Pilih Instruktur</option>
                    <?php $__currentLoopData = $data_instruktur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($l->id_instruktur); ?>" <?php echo e(old('id_instruktur') == $l->id_instruktur ? 'selected' : ''); ?>><?php echo e($l->nama_instruktur); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_instrumen">Instrumen</label>
                <div class="col-lg-9" id="col-instrumen">
                  <?php echo $__env->make('components.jadwal.select_instrumen', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_studio">Studio</label>
                <div class="col-lg-9" id="col-studio">
                  <?php echo $__env->make('components.jadwal.select_studio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="bulan">Bulan</label>
                <div class="col-lg-9">
                  <input type="month" class="form-control" id="bulan" name="bulan" value="<?php echo e(old('bulan')); ?>">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="hari">Hari</label>
                <div class="col-lg-9">
                  <select name="hari" id="hari" class="form-control select2">
                    <option value="">Pilih Hari</option>
                    <?php $__currentLoopData = \App\Jadwal::$hari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($hari); ?>" <?php echo e(old('hari') == $hari ? 'selected' : ''); ?>><?php echo e($hari); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="jam_mulai">Jam Mulai</label>
                <div class="col-lg-9">
                  <select name="jam_mulai" id="jam_mulai" class="form-control select2">
                    <option value="">Pilih Jam Mulai</option>
                    <?php $__currentLoopData = \App\JadwalHarian::$jam_ke; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($jam); ?>" <?php echo e(old('jam_mulai') == $jam ? 'selected' : ''); ?>><?php echo e($jam); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="jam_selesai">Jam Selesai</label>
                <div class="col-lg-9">
                  <select name="jam_selesai" id="jam_selesai" class="form-control select2">
                    <option value="">Pilih Jam Selesai</option>
                    <?php $__currentLoopData = \App\JadwalHarian::$jam_selesai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($jam); ?>" <?php echo e(old('jam_selesai') == $jam ? 'selected' : ''); ?>><?php echo e($jam); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.timepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();

      setTimeout(getItemInstrumen, 500);

      function getItemInstrumen(){
          let id_instruktur = $("#id_instruktur").val();
          let id_instrumen = $("#id_instrumen").val();
          id_instrumen = id_instrumen ? id_instrumen : '<?php echo e(old('id_instrumen')); ?>';

          $.ajax({
              url: '<?php echo e(url('jadwal/add/component/get-instrumen')); ?>',
              type: 'get',
              data: {
                  id_instruktur: id_instruktur,
                  id_instrumen: id_instrumen
              },
              success: function(data) {
                  $("#col-instrumen").html(data);
                  $(".select2").select2();
                  getItemStudio()
              },
              error: async function(data) {
                  swal('Gagal','Terjadi kesalahan sistem','error');
              },
          });
      }

      function getItemStudio(){
          let id_instruktur = $("#id_instruktur").val();
          let id_studio = $("#id_studio").val();
          let id_instrumen = $("#id_instrumen").val();
          id_instrumen = id_instrumen ? id_instrumen : '<?php echo e(old('id_instrumen')); ?>';
          id_studio = id_studio ? id_studio : '<?php echo e(old('id_studio')); ?>';

          $.ajax({
              url: '<?php echo e(url('jadwal/add/component/get-studio')); ?>',
              type: 'get',
              data: {
                  id_instruktur: id_instruktur,
                  id_instrumen: id_instrumen,
                  id_studio: id_studio
              },
              success: function(data) {
                  $("#col-studio").html(data);
                  $(".select2").select2();
              },
              error: async function(data) {
                  swal('Gagal','Terjadi kesalahan sistem','error');
              },
          });

      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>