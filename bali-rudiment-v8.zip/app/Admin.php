<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Admin extends Model
{
  protected $table = 'admin';
  public $timestamps = false;

  public static function getIdPenempatan()
  {
    if(Auth::user()){
      $get = self::where('id_pengguna', Auth::user()->id)->first();
      return $get ? $get->id_penempatan : null;
    }
    return null;
  }

  public static function getData()
  {
    return self::leftJoin('pengguna as p','p.id','=','admin.id_pengguna')
      ->leftJoin('penempatan as pp','pp.id_penempatan','=','admin.id_penempatan')
      ->get();
  }

  public static function getInfo($id_pengguna)
  {
    return self::leftJoin('pengguna as p','p.id','=','admin.id_pengguna')
      ->leftJoin('penempatan as pp','pp.id_penempatan','=','admin.id_penempatan')
      ->where('admin.id_pengguna', $id_pengguna)
      ->first();
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_pengguna', $data['id_pengguna'])->update($data);
  }
}
