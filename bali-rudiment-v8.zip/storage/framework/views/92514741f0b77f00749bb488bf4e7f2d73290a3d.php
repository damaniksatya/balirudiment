<?php $__env->startSection('title','Pengubahan Jadwal'); ?>

<?php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_pengubahan_jadwal);
  $nonaktif_add = in_array(\App\SettingMenu::ADD_PENGUBAHAN_JADWAL, $arr_nonaktif);
?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              
                
                  
                  
                
              
              <h4 class="page-title">
                
                  
                
                Pengubahan Jadwal
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <?php if(!$nonaktif_add): ?>
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <form class="form-horizontal" method="post" action="<?php echo e(url('pengubahan-jadwal/siswa')); ?>">
              <?php echo csrf_field(); ?>
              <div class="card-body pb-0">
                <div class="form-group row">
                  <label class="col-lg-3 text-right col-form-label" for="id_jadwal_sebelum">Jadwal yang ingin diubah</label>
                  <div class="col-lg-9">
                    <select name="id_jadwal_sebelum" id="id_jadwal_sebelum" class="form-control select2" onchange="getPengubahanJadwal()">
                      <?php if(count($data_jadwal)): ?>
                        <option value="">Pilih Jadwal</option>
                        <?php $__currentLoopData = $data_jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php
                            $waktu = $l->jam_mulai .'-'. $l->jam_selesai;
                            $hari_tgl = $l->hari .', '. date('d-m-Y', strtotime($l->tanggal));
                            $value = "$l->id_jadwal--$l->tanggal--$l->jam_mulai-$l->jam_selesai";
                          ?>
                          <option value="<?php echo e($value); ?>" <?php echo e(old('id_jadwal_sebelum') == $value ? 'selected' : ''); ?>>
                            <?php echo e($hari_tgl); ?>&nbsp; | &nbsp;<?php echo e($waktu); ?>&nbsp; | &nbsp;<?php echo e($l->nama_studio); ?>&nbsp; | &nbsp;<?php echo e($l->nama_instrumen); ?>&nbsp; | &nbsp;<?php echo e($l->nama_instruktur); ?>

                          </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <option value="">Jadwal tidak tersedia!</option>
                      <?php endif; ?>
                    </select>
                  </div>
                </div>
                <div class="form-group row mt-3 mb-0" id="row-pengubahan-jadwal">

                </div>
                <div id="col-siswa"></div>

              </div>
              <div class="card-body pt-3 text-right" id="container-button" style="display: none">
                <button type="submit" class="btn btn-primary">Simpan</button>
              </div>
            </form>
          </div>

        </div>
      </div>
    <?php endif; ?>

    <?php if(count($data)): ?>
      <h6 class="mb-3">Data Pengajuan Pengubahan Jadwal</h6>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
          <div class="col-lg-12">
            <div class="card">
              <div class="card-body">
                <table class="table table-sm table-borderless">
                  <tr>
                    <td class="border-top-0" style="width: 150px">Status Pengajuan</td>
                    <td class="px-0" style="width: 5px">:</td>
                    <td class="border-top-0">
                      <span class="badge badge-<?php echo e(\App\JadwalPengubahan::$color[$d->status]); ?>" style="padding-top: 5px"><?php echo e($d->status); ?></span>
                    </td>
                  </tr>
                  <tr>
                    <td>Waktu Pengajuan</td>
                    <td class="px-0">:</td>
                    <td><?php echo e(\App\Http\Controllers\HelperController::setNamaWaktu($d->waktu_pengajuan)); ?></td>
                  </tr>
                </table>

                <div class="row">
                  <div class="col-lg-6">
                    <strong>Jadwal sebelum diubah</strong>
                    <div class="card shadow-none mt-2 mb-0" style="background-color: rgba(0, 0, 0, 0.07)">
                      <div class="card-body">
                        <table class="table table-sm table-borderless mb-0">
                          <tr>
                            <td style="width: 100px">Hari</td>
                            <td class="px-0" style="width: 5px">:</td>
                            <td><?php echo e($d->jadwal_sebelum->hari); ?></td>
                          </tr>
                          <tr>
                            <td>Tanggal</td>
                            <td class="px-0">:</td>
                            <td><?php echo e(date('d-m-Y', strtotime($d->tanggal_sebelum))); ?></td>
                          </tr>
                          <tr>
                            <td>Jam</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jam_sebelum); ?></td>
                          </tr>
                          <tr>
                            <td>Studio</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_sebelum->nama_studio); ?></td>
                          </tr>
                          <tr>
                            <td>Instrumen</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_sebelum->nama_instrumen); ?></td>
                          </tr>
                          <tr>
                            <td>Instruktur</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_sebelum->nama_instruktur); ?></td>
                          </tr>
                        </table>
                      </div>
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <strong>Jadwal setelah diubah</strong>
                    <div class="card shadow-none mt-2 mb-0" style="background-color: rgba(0, 0, 0, 0.07)">
                      <div class="card-body">
                        <table class="table table-sm table-borderless mb-0">
                          <tr>
                            <td style="width: 100px">Hari</td>
                            <td class="px-0" style="width: 5px">:</td>
                            <td><?php echo e($d->jadwal_setelah->hari); ?></td>
                          </tr>
                          <tr>
                            <td>Tanggal</td>
                            <td class="px-0">:</td>
                            <td><?php echo e(date('d-m-Y', strtotime($d->tanggal_setelah))); ?></td>
                          </tr>
                          <tr>
                            <td>Jam</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jam_setelah); ?></td>
                          </tr>
                          <tr>
                            <td>Studio</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_setelah->nama_studio); ?></td>
                          </tr>
                          <tr>
                            <td>Instrumen</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_setelah->nama_instrumen); ?></td>
                          </tr>
                          <tr>
                            <td>Instruktur</td>
                            <td class="px-0">:</td>
                            <td><?php echo e($d->jadwal_setelah->nama_instruktur); ?></td>
                          </tr>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(document).ready(function(){
          $(".select2").select2();
      });

      function getPengubahanJadwal() {
          $.ajax({
              url: '<?php echo e(url('pengubahan-jadwal/component/select-pengubahan')); ?>',
              type: 'get',
              data: {
                  id_jadwal_sebelum: $("#id_jadwal_sebelum").val(),
              },
              success: function(data) {
                  $("#container-button").show();
                  $("#row-pengubahan-jadwal").html(data);
                  $(".select2").select2();
              },
              error: async function(data) {
                  swal('Gagal','Terjadi kesalahan sistem','error');
              },
          });
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>