@extends('layouts.main')

@section('title','Edit Data Penempatan')

@section('css')
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="{{ url('penempatan') }}">Penempatan</a></li>
                  <li class="breadcrumb-item active">Edit</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="{{ url('penempatan') }}">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Edit Penempatan
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="{{ url('penempatan') }}">
            @csrf @method('put')
            <input type="hidden" name="id_penempatan" value="{{ $info->id_penempatan }}">
            <input type="hidden" name="nama_penempatan_old" value="{{ $info->nama_penempatan }}">
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="nama_penempatan">Nama Penempatan</label>
                <div class="col-lg-9">
                  <input type="text" id="nama_penempatan" name="nama_penempatan" value="{{ old('nama_penempatan') ?: $info->nama_penempatan }}"
                         class="form-control" required>
                </div>
              </div>
            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script>
  </script>
@endsection