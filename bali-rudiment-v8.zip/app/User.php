<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Auth;

class User extends Authenticatable
{
  use Notifiable;

  protected $table = 'pengguna';
  public $timestamps = false;

  public const S_AKTIF = 'AKTIF';
  public const S_NONAKTIF = 'NONAKTIF';

  public const L_ADMIN = 'ADMIN';
  public const L_GENERAL_ADMIN = 'GENERAL ADMIN';
  public const L_ACCOUNTING = 'ACCOUNTING';
  public const L_INSTRUKTUR = 'INSTRUKTUR';
  public const L_SISWA = 'SISWA';

  public static $status = [
    self::S_AKTIF, self::S_NONAKTIF
  ];

  public static $level_user = [
    self::L_GENERAL_ADMIN, self::L_ADMIN, self::L_ACCOUNTING, self::L_INSTRUKTUR, self::L_SISWA
  ];

  public static $level_user_add = [
    self::L_ADMIN, self::L_GENERAL_ADMIN
  ];

  public static $color = [
    self::S_AKTIF => 'primary',
    self::S_NONAKTIF => 'danger',
    self::L_ADMIN => 'primary',
    self::L_GENERAL_ADMIN => 'success',
    self::L_ACCOUNTING => 'purple',
    self::L_INSTRUKTUR => 'warning',
    self::L_SISWA => 'danger',
    '' => ''
  ];

  public function setAttribute($key, $value)
  {
    $isRememberTokenAttribute = $key == $this->getRememberTokenName();
    if (!$isRememberTokenAttribute)
    {
      parent::setAttribute($key, $value);
    }
  }

  public static function getData()
  {
    return self::all();
  }

  public static function getDataAktifByLevelUser($level_user)
  {
    return self::where('level_user', $level_user)
      ->where('status', self::S_AKTIF)
      ->get();
  }

  public static function getInfo($id)
  {
    return self::where('id', $id)->first();
  }

  public static function getProfileInfo()
  {
    $id = Auth::user()->id;
    $level_user = Auth::user()->level_user;
    if($level_user == self::L_ADMIN || $level_user == self::L_GENERAL_ADMIN){
      return self::leftJoin('admin as a','a.id_pengguna','=','pengguna.id')
        ->where('pengguna.id', $id)
        ->first();
    }
    elseif($level_user == self::L_INSTRUKTUR){
      return self::leftJoin('instruktur as i','i.id_pengguna','=','pengguna.id')
        ->where('pengguna.id', $id)
        ->first();
    }
    elseif($level_user == self::L_ACCOUNTING){
      return self::leftJoin('accounting as a','a.id_pengguna','=','pengguna.id')
        ->where('pengguna.id', $id)
        ->first();
    }
    elseif($level_user == self::L_SISWA){
      return self::leftJoin('siswa as s','s.id_pengguna','=','pengguna.id')
        ->where('pengguna.id', $id)
        ->first();
    }
  }

  public static function getInfoByUsername($username)
  {
    return self::where('username', $username)->first();
  }

  public static function insertData($data)
  {
    $keys = array_keys($data);
    $new = new self();
    foreach($keys as $key){
      $new->$key = $data[$key];
    }
    $new->save();

    return $new->id;
  }

  public static function updateData($id, $data)
  {
    self::where('id', $id)->update($data);
  }

  public static function deleteData($id)
  {
    self::where('id', $id)->delete();
  }
}
