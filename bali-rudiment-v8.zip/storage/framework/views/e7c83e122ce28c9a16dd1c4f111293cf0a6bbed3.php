<?php $__env->startSection('title','Input/Edit Data Absensi'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(url('slip-gaji/freelance')); ?>">Absensi</a></li>
                  <li class="breadcrumb-item active">Input/Edit</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="<?php echo e(url('slip-gaji/freelance')); ?>">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input/Edit Absensi
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <form class="row" method="post" action="<?php echo e(url('slip-gaji/freelance/absensi')); ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="id_gaji_freelance" value="<?php echo e($info->id_gaji); ?>">
      <input type="hidden" name="arr_tgl" value="<?php echo e(json_encode($arr_tgl)); ?>">
      <input type="hidden" name="bulan" value="<?php echo e($info->bulan); ?>">
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body pb-0">
            <table class="mb-3">
              <tr>
                <td>Nama</td>
                <td class="text-center" style="width: 15px">:</td>
                <td><?php echo e($info->instruktur->nama_instruktur); ?></td>
              </tr>
              <tr>
                <td>Bulan</td>
                <td class="text-center">:</td>
                <td><?php echo e(\App\Http\Controllers\HelperController::setNamaBulan($info->bulan)); ?></td>
              </tr>
            </table>
            <table class="table table-sm table-bordered mb-0">
              <thead>
              <tr>
                <th class="text-center">Tanggal</th>
                <th class="text-center">Kehadiran</th>
                <th class="text-center">Note</th>
                <th class="text-center">Off</th>
                <th class="text-center">Event</th>
              </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgl=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="text-center"><?php echo e($tgl); ?></td>
                  <?php
                    $is_off = $t['kehadiran'] == 'OFF' && $t['note'] == 'OFF';
                    $is_event = $t['kehadiran'] == 'EVENT';
                  ?>
                  <td colspan="2" id="td-off-<?php echo e($tgl); ?>" class="text-center bg-soft-danger" style="display: <?php echo e($is_off ? 'table-cell' : 'none'); ?>;">
                    <div style="padding: 3px">OFF</div>
                  </td>
                  <td class="p-1" id="td-kehadiran-<?php echo e($tgl); ?>" style="display: <?php echo e(!$is_off ? 'table-cell' : 'none'); ?>">
                    <input type="text" class="form-control form-control-sm"
                           value="<?php echo e($t['kehadiran'] ?: 'HADIR'); ?>"
                           
                           title="Kehadiran Tanggal <?php echo e($tgl); ?>" name="kehadiran-<?php echo e($tgl); ?>">
                  </td>
                  <td class="p-1" id="td-note-<?php echo e($tgl); ?>" style="display: <?php echo e(!$is_off ? 'table-cell' : 'none'); ?>">
                    <input type="text" class="form-control form-control-sm"
                           value="<?php echo e($t['note']); ?>"
                           
                           title="Keluar Note <?php echo e($tgl); ?>" name="note-<?php echo e($tgl); ?>">
                  </td>
                  <td class="text-center">
                    <div class="custom-control custom-checkbox" style="margin-left: 7px; cursor: pointer">
                      <input type="checkbox" class="custom-control-input" id="off-<?php echo e($tgl); ?>"
                             onchange="changeOff('<?php echo e($tgl); ?>', this.checked)" <?php echo e($is_off ? 'checked' : ''); ?>>
                      <label class="custom-control-label" style="cursor: pointer" for="off-<?php echo e($tgl); ?>"></label>
                    </div>
                  </td>
                  <td class="text-center">
                    <div class="custom-control custom-checkbox" style="margin-left: 7px; cursor: pointer">
                      <input type="checkbox" class="custom-control-input" id="event-<?php echo e($tgl); ?>"
                             onchange="changeEvent('<?php echo e($tgl); ?>', this.checked)" <?php echo e($is_event ? 'checked' : ''); ?>>
                      <label class="custom-control-label" style="cursor: pointer" for="event-<?php echo e($tgl); ?>"></label>
                    </div>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            
              
              
            
          </div>
          <div class="card-body text-right">
            <button type="submit" class="btn btn-primary">Simpan</button>
          </div>
        </div>
      </div>
    </form>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();

      function changeOff(tgl, is_checked) {
          // console.log(tgl, is_checked)
          $(`[name=kehadiran-${tgl}]`).val(is_checked ? 'OFF' : null);
          $(`[name=note-${tgl}]`).val(is_checked ? 'OFF' : null);

          if(is_checked){
              $(`#event-${tgl}`).prop('checked', false);
              $(`#td-off-${tgl}`).show();
              $(`#td-kehadiran-${tgl}`).hide();
              $(`#td-note-${tgl}`).hide();
          }
          else{
              $(`#td-off-${tgl}`).hide();
              $(`#td-kehadiran-${tgl}`).show();
              $(`#td-note-${tgl}`).show();
          }
      }

      function changeEvent(tgl, is_checked) {
          if(is_checked){
              $(`#off-${tgl}`).prop('checked', false);
              changeOff(tgl, false);
          }
          $(`[name=kehadiran-${tgl}]`).val(is_checked ? 'EVENT' : null);
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>