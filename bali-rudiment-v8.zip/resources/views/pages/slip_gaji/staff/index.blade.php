@extends('layouts.main')

@section('title','Data Slip Gaji Staff')

@php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_slip_gaji_staff);
  $nonaktif_cetak = in_array(\App\SettingMenu::CETAK_SLIP_GAJI_STAFF, $arr_nonaktif);
  $nonaktif_input = in_array(\App\SettingMenu::INPUT_SLIP_GAJI_STAFF, $arr_nonaktif);
  $nonaktif_edit = in_array(\App\SettingMenu::EDIT_SLIP_GAJI_STAFF, $arr_nonaktif);
  $nonaktif_delete = in_array(\App\SettingMenu::HAPUS_SLIP_GAJI_STAFF, $arr_nonaktif);
@endphp

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right mt-2 pt-1">
                @if($nonaktif_input == false)
                  <a href="{{ url('slip-gaji/staff/add') }}" class="btn btn-primary">
                    <i class="mdi mdi-plus mr-2"></i>Input Data Slip Gaji Staff
                  </a>
                @endif
              </div>
              <h4 class="page-title">Data Slip Gaji Staff</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <form method="get" class="card-body border-bottom">
            <div class="form-group row mb-0">
              <label class="col-lg-3 text-right col-form-label" for="bulan">Bulan</label>
              <div class="col-lg-9">
                <select name="bulan" id="bulan" class="form-control select2" onchange="this.form.submit()">
                  <option value="">Semua Bulan</option>
                  @foreach($data_bulan as $bln)
                    <option value="{{ $bln }}" {{ $bln == $bulan ? 'selected' : '' }}>{{ \App\Http\Controllers\HelperController::setNamaBulan($bln) }}</option>
                  @endforeach
                </select>
              </div>
            </div>
          </form>
          <div class="card-body">
            <div class="table-responsive">
              <table id="datatable" class="table mb-0 table-sm table-bordered">
                <thead>
                <tr>
                  <th class="text-center" style="width: 40px">No</th>
                  <th class="">Nama Staff</th>
                  <th class="">Jabatan</th>
                  <th class="">Bulan</th>
                  <th class="">Total Penerimaan</th>
                  @if(!($nonaktif_edit && $nonaktif_delete && $nonaktif_cetak))
                    <th style="width: 220px" class="text">Aksi</th>
                  @endif
                </tr>
                </thead>
                <tbody>
                @foreach($data as $no=>$d)
                  <tr>
                    <td class="text-center">{{ $no+1 }}</td>
                    <td class="">{{ $d['nama_staff'] }}</td>
                    <td class="">{{ $d['jabatan'] }}</td>
                    @if($d['dari_bulan'] == $d['sampai_bulan'])
                      <td class="">{{ \App\Http\Controllers\HelperController::setNamaBulan($d['dari_bulan']) }}</td>
                    @else
                      <td class="">
                        {{ \App\Http\Controllers\HelperController::setNamaBulan($d['dari_bulan']) .' - '.
                      \App\Http\Controllers\HelperController::setNamaBulan($d['sampai_bulan']) }}
                      </td>
                    @endif
                    <td class="text-right">{{ number_format($d['total_penerimaan'], 0, ',', '.') }}</td>
                    @if(!($nonaktif_edit && $nonaktif_delete && $nonaktif_cetak))
                      <td>
                        <div class="btn-group btn-block">
                          @if(!$nonaktif_cetak)
                            <a href="{{ url('slip-gaji/staff/print/'.$d['id_gaji']) }}" class="btn btn-sm btn-outline-primary" target="_blank">
                              <i class="mdi mdi-printer pr-2"></i>Cetak Slip Gaji
                            </a>
                          @endif

                          @if(!$nonaktif_edit)
                            <button type="button" class="btn btn-outline-primary btn-sm dropdown-toggle pr-1"
                                    data-toggle="dropdown" aria-expanded="false" style="border-top-right-radius: 0; border-bottom-right-radius: 0">
                              Edit <i class="mdi mdi-chevron-down"></i>
                            </button>
                            <div class="dropdown-menu">
                              @php
                                $back_url = '?back_url='.\Illuminate\Support\Facades\Route::current()->uri;
                              @endphp
                              <a class="dropdown-item" href="{{ url('slip-gaji/staff/edit/'.$d['id_gaji'].$back_url) }}">Edit Gaji</a>
                              <a class="dropdown-item" href="{{ url('slip-gaji/staff/absensi/'.$d['id_gaji'].$back_url) }}">Edit Absensi</a>
                            </div>
                          @endif

                          @if(!$nonaktif_delete)
                            <button id="delete-{{ $d['id_gaji'] }}" type="button" class="btn btn-sm btn-outline-danger">Hapus</button>
                          @endif
                        </div>

                        <form id="form-delete{{ $d['id_gaji'] }}" action="{{ url('slip-gaji/staff') }}" method="post">
                          @csrf @method('delete')
                          <input type="hidden" name="id_gaji" value="{{ $d['id_gaji'] }}">
                        </form>
                      </td>
                    @endif
                  </tr>
                @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection
@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();
      @foreach($data as $d)
          $('#delete-{{ $d['id_gaji'] }}').click(function(){
              swal({
                  title: "Anda yakin?",
                  text: "Data Slip Gaji {{ $d['nama_staff'] }} yang akan dihapus, tidak bisa dikembalikan!",
                  type: "warning",
                  showCancelButton: true,
                  confirmButtonColor: "#E62129",
                  confirmButtonText: "Ya, hapus!",
                  cancelButtonText: "Batalkan",
                  closeOnConfirm: false
              }, function(){
                  $("#form-delete{{ $d['id_gaji'] }}").submit();
              });
          });
      @endforeach
  </script>
@endsection