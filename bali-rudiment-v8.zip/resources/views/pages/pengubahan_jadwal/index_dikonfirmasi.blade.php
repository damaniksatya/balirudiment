@extends('layouts.main')

@section('title','Data Pengubahan Jadwal')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              {{--<div class="page-title-right">--}}
                {{--<ol class="breadcrumb m-0">--}}
                  {{--<li class="breadcrumb-item"><a href="{{ url('instruktur') }}">Instruktur</a></li>--}}
                  {{--<li class="breadcrumb-item active">Input</li>--}}
                {{--</ol>--}}
              {{--</div>--}}
              <h4 class="page-title">
                {{--<a href="{{ url('instruktur') }}">--}}
                  {{--<i class="mdi mdi-arrow-left mr-1 text-primary"></i>--}}
                {{--</a>--}}
                Data Pengubahan Jadwal
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      @if(count($data))
        @foreach($data as $d)
          <div class="col-lg-12">
            <div class="card">
              <div class="card-body">
                <table>
                  <tr>
                    @if($d->siswa->foto_profile != null)
                      <td style="width: 55px; padding-right: 10px" class="border-0 py-0 pl-0">
                        <div style="background: url('{{ url($d->siswa->foto_profile) }}'); height: 45px;
                          padding-top: 50%;
                          padding-bottom: 50%;
                          background-position: 50% !important;
                          background-size: cover !important;
                          border-radius: 50%"></div>
                      </td>
                    @endif
                    <td class="border-0 pl-0 font-weight-bold">{{ $d->siswa->nama_siswa }}</td>
                  </tr>
                </table>
                <table class="table table-sm table-borderless mt-2">
                  <tr>
                    <td class="border-top-0" style="width: 150px">Email Siswa</td>
                    <td class="px-0" style="width: 5px">:</td>
                    <td>{{ $d->siswa->email_siswa }}</td>
                  </tr>
                  <tr>
                    <td>No HP Orang Tua</td>
                    <td class="px-0">:</td>
                    <td>{{ $d->siswa->no_hp_orangtua }}</td>
                  </tr>
                  <tr>
                    <td>Status Pengajuan</td>
                    <td class="px-0">:</td>
                    <td>
                      <span class="badge badge-{{ \App\JadwalPengubahan::$color[$d->status] }}" style="padding-top: 5px">{{ $d->status }}</span>
                    </td>
                  </tr>
                  <tr>
                    <td>Waktu Pengajuan</td>
                    <td class="px-0">:</td>
                    <td>{{ \App\Http\Controllers\HelperController::setNamaWaktu($d->waktu_pengajuan) }}</td>
                  </tr>
                </table>

                <div class="row">
                  <div class="col-lg-6">
                    <strong>Jadwal sebelum diubah</strong>
                    <div class="card shadow-none mt-2 mb-0" style="background-color: rgba(0, 0, 0, 0.07)">
                      <div class="card-body">
                        <table class="table table-sm table-borderless mb-0">
                          <tr>
                            <td style="width: 100px">Hari</td>
                            <td class="px-0" style="width: 5px">:</td>
                            <td>{{ $d->jadwal_sebelum->hari }}</td>
                          </tr>
                          <tr>
                            <td>Tanggal</td>
                            <td class="px-0">:</td>
                            <td>{{ date('d-m-Y', strtotime($d->tanggal_sebelum)) }}</td>
                          </tr>
                          <tr>
                            <td>Jam</td>
                            <td class="px-0">:</td>
                            <td>{{ $d->jam_sebelum }}</td>
                          </tr>
                          <tr>
                            <td>Studio</td>
                            <td class="px-0">:</td>
                            <td>{{ $d->jadwal_sebelum->nama_studio }}</td>
                          </tr>
                          <tr>
                            <td>Instrumen</td>
                            <td class="px-0">:</td>
                            <td>{{ $d->jadwal_sebelum->nama_instrumen }}</td>
                          </tr>
                          <tr>
                            <td>Instruktur</td>
                            <td class="px-0">:</td>
                            <td>{{ $d->jadwal_sebelum->nama_instruktur }}</td>
                          </tr>
                        </table>
                      </div>
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <strong>Jadwal setelah diubah</strong>
                    <div class="card shadow-none mt-2 mb-0" style="background-color: rgba(0, 0, 0, 0.07)">
                      <div class="card-body">
                        <table class="table table-sm table-borderless mb-0">
                          <tr>
                            <td style="width: 100px">Hari</td>
                            <td class="px-0" style="width: 5px">:</td>
                            <td>{{ $d->jadwal_setelah->hari }}</td>
                          </tr>
                          <tr>
                            <td>Tanggal</td>
                            <td class="px-0">:</td>
                            <td>{{ date('d-m-Y', strtotime($d->tanggal_setelah)) }}</td>
                          </tr>
                          <tr>
                            <td>Jam</td>
                            <td class="px-0">:</td>
                            <td>{{ $d->jam_setelah }}</td>
                          </tr>
                          <tr>
                            <td>Studio</td>
                            <td class="px-0">:</td>
                            <td>{{ $d->jadwal_setelah->nama_studio }}</td>
                          </tr>
                          <tr>
                            <td>Instrumen</td>
                            <td class="px-0">:</td>
                            <td>{{ $d->jadwal_setelah->nama_instrumen }}</td>
                          </tr>
                          <tr>
                            <td>Instruktur</td>
                            <td class="px-0">:</td>
                            <td>{{ $d->jadwal_setelah->nama_instruktur }}</td>
                          </tr>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        @endforeach
      @else
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <p class="text-center mb-0">Semua pengajuan pengubahan telah dikonfirmasi</p>
            </div>
          </div>
        </div>
      @endif
    </div>

  </div>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(document).ready(function(){
          $(".select2").select2();
      });
  </script>
@endsection