<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SettingMenu extends Model
{
  protected $table = 'setting_menu';
  public $timestamps = false;

  public const S_AKTIF = 'AKTIF';
  public const S_NONAKTIF = 'NONAKTIF';

  public static $status = [
    self::S_AKTIF, self::S_NONAKTIF
  ];

  public static $color = [
    self::S_AKTIF => 'primary',
    self::S_NONAKTIF => 'danger',
    '' => ''
  ];

  const MENU_ADMIN = 'MENU ADMIN';
  const CREATE_ADMIN = 'CREATE ADMIN';
  const UPDATE_ADMIN = 'UPDATE ADMIN';
  const NONAKTIFKAN_ADMIN = 'NONAKTIFKAN ADMIN';

  public static $menu_admin = [
    self::MENU_ADMIN,
    self::CREATE_ADMIN,
    self::UPDATE_ADMIN,
    self::NONAKTIFKAN_ADMIN,
  ];

  const MENU_ACCOUNTING = 'MENU ACCOUNTING';
  const CREATE_ACCOUNTING = 'CREATE ACCOUNTING';
  const UPDATE_ACCOUNTING = 'UPDATE ACCOUNTING';
  const NONAKTIFKAN_ACCOUNTING = 'NONAKTIFKAN ACCOUNTING';

  public static $menu_accounting = [
    self::MENU_ACCOUNTING,
    self::CREATE_ACCOUNTING,
    self::UPDATE_ACCOUNTING,
    self::NONAKTIFKAN_ACCOUNTING,
  ];

  const MENU_INSTRUKTUR = 'MENU INSTRUKTUR';
  const CREATE_INSTRUKTUR = 'CREATE INSTRUKTUR';
  const UPDATE_INSTRUKTUR = 'UPDATE INSTRUKTUR';
  const NONAKTIFKAN_INSTRUKTUR = 'NONAKTIFKAN INSTRUKTUR';

  public static $menu_instruktur = [
    self::MENU_INSTRUKTUR,
    self::CREATE_INSTRUKTUR,
    self::UPDATE_INSTRUKTUR,
    self::NONAKTIFKAN_INSTRUKTUR,
  ];

  const MENU_SISWA = 'MENU SISWA';
  const CREATE_SISWA = 'CREATE SISWA';
  const UPDATE_SISWA = 'UPDATE SISWA';
  const NONAKTIFKAN_SISWA = 'NONAKTIFKAN SISWA';

  public static $menu_siswa = [
    self::MENU_SISWA,
    self::CREATE_SISWA,
    self::UPDATE_SISWA,
    self::NONAKTIFKAN_SISWA,
  ];

  const MENU_INSTRUMEN = 'MENU INSTRUMEN';
  const CREATE_INSTRUMEN = 'CREATE INSTRUMEN';
  const UPDATE_INSTRUMEN = 'UPDATE INSTRUMEN';
  const DELETE_INSTRUMEN = 'DELETE INSTRUMEN';

  public static $menu_instrumen = [
    self::MENU_INSTRUMEN,
    self::CREATE_INSTRUMEN,
    self::UPDATE_INSTRUMEN,
    self::DELETE_INSTRUMEN,
  ];

  const MENU_KELAS = 'MENU KELAS';
  const CREATE_KELAS = 'CREATE KELAS';
  const UPDATE_KELAS = 'UPDATE KELAS';
  const DELETE_KELAS = 'DELETE KELAS';

  public static $menu_kelas = [
    self::MENU_KELAS,
    self::CREATE_KELAS,
    self::UPDATE_KELAS,
    self::DELETE_KELAS,
  ];

  const MENU_STUDIO = 'MENU STUDIO';
  const CREATE_STUDIO = 'CREATE STUDIO';
  const UPDATE_STUDIO = 'UPDATE STUDIO';
  const DELETE_STUDIO = 'DELETE STUDIO';

  public static $menu_studio = [
    self::MENU_STUDIO,
    self::CREATE_STUDIO,
    self::UPDATE_STUDIO,
    self::DELETE_STUDIO,
  ];

  const MENU_PENEMPATAN = 'MENU PENEMPATAN';
  const CREATE_PENEMPATAN = 'CREATE PENEMPATAN';
  const UPDATE_PENEMPATAN = 'UPDATE PENEMPATAN';
  const DELETE_PENEMPATAN = 'DELETE PENEMPATAN';

  public static $menu_penempatan = [
    self::MENU_PENEMPATAN,
    self::CREATE_PENEMPATAN,
    self::UPDATE_PENEMPATAN,
    self::DELETE_PENEMPATAN,
  ];

  const MENU_JADWAL_MENGAJAR = 'MENU JADWAL MENGAJAR';
  const CREATE_JADWAL_MENGAJAR = 'CREATE JADWAL MENGAJAR';
  const UPDATE_JADWAL_MENGAJAR = 'UPDATE JADWAL MENGAJAR';
  const CREATE_UPDATE_SISWA_JADWAL_MENGAJAR = 'CREATE & UPDATE SISWA JADWAL MENGAJAR';
  const DELETE_JADWAL_MENGAJAR = 'DELETE JADWAL MENGAJAR';

  public static $menu_jadwal_mengajar = [
    self::MENU_JADWAL_MENGAJAR,
    self::CREATE_JADWAL_MENGAJAR,
    self::UPDATE_JADWAL_MENGAJAR,
    self::CREATE_UPDATE_SISWA_JADWAL_MENGAJAR,
    self::DELETE_JADWAL_MENGAJAR,
  ];

  const MENU_JADWAL_HARIAN = 'MENU JADWAL HARIAN';
  const UPDATE_JADWAL_HARIAN = 'UPDATE JADWAL HARIAN';
  const RESET_JADWAL_HARIAN = 'RESET JADWAL HARIAN';
  const PRINT_JADWAL_HARIAN = 'PRINT JADWAL HARIAN';

  public static $menu_jadwal_harian = [
    self::MENU_JADWAL_HARIAN,
    self::UPDATE_JADWAL_HARIAN,
    self::RESET_JADWAL_HARIAN,
    self::PRINT_JADWAL_HARIAN,
  ];

  const MENU_PENGUBAHAN_JADWAL = 'MENU PENGUBAHAN JADWAL';
  const ADD_PENGUBAHAN_JADWAL = 'ADD PENGUBAHAN JADWAL';
  const KONFIRMASI_PENGUBAHAN_JADWAL = 'KONFIRMASI PENGUBAHAN JADWAL';

  public static $menu_pengubahan_jadwal = [
    self::MENU_PENGUBAHAN_JADWAL,
    self::ADD_PENGUBAHAN_JADWAL,
    self::KONFIRMASI_PENGUBAHAN_JADWAL,
  ];

  const MENU_SLIP_GAJI_STAFF = 'MENU SLIP GAJI STAFF';
  const CETAK_SLIP_GAJI_STAFF = 'CETAK SLIP GAJI STAFF';
  const EDIT_SLIP_GAJI_STAFF = 'EDIT SLIP GAJI STAFF';
  const INPUT_SLIP_GAJI_STAFF = 'INPUT SLIP GAJI STAFF';
  const HAPUS_SLIP_GAJI_STAFF = 'HAPUS SLIP GAJI STAFF';

  public static $menu_slip_gaji_staff = [
    self::MENU_SLIP_GAJI_STAFF,
    self::INPUT_SLIP_GAJI_STAFF,
    self::EDIT_SLIP_GAJI_STAFF,
    self::HAPUS_SLIP_GAJI_STAFF,
    self::CETAK_SLIP_GAJI_STAFF,
  ];

  const MENU_SLIP_GAJI_INSTRUKTUR_FULLTIME = 'MENU SLIP GAJI INSTRUKTUR FULLTIME';
  const CETAK_SLIP_GAJI_INSTRUKTUR_FULLTIME = 'CETAK SLIP GAJI INSTRUKTUR FULLTIME';
  const EDIT_SLIP_GAJI_INSTRUKTUR_FULLTIME = 'EDIT SLIP GAJI INSTRUKTUR FULLTIME';
  const INPUT_SLIP_GAJI_INSTRUKTUR_FULLTIME = 'INPUT SLIP GAJI INSTRUKTUR FULLTIME';
  const HAPUS_SLIP_GAJI_INSTRUKTUR_FULLTIME = 'HAPUS SLIP GAJI INSTRUKTUR FULLTIME';

  public static $menu_slip_gaji_instruktur_fulltime = [
    self::MENU_SLIP_GAJI_INSTRUKTUR_FULLTIME,
    self::INPUT_SLIP_GAJI_INSTRUKTUR_FULLTIME,
    self::EDIT_SLIP_GAJI_INSTRUKTUR_FULLTIME,
    self::HAPUS_SLIP_GAJI_INSTRUKTUR_FULLTIME,
    self::CETAK_SLIP_GAJI_INSTRUKTUR_FULLTIME,
  ];

  const MENU_SLIP_GAJI_INSTRUKTUR_FREELANCE = 'MENU SLIP GAJI INSTRUKTUR FREELANCE';
  const CETAK_SLIP_GAJI_INSTRUKTUR_FREELANCE = 'CETAK SLIP GAJI INSTRUKTUR FREELANCE';
  const EDIT_SLIP_GAJI_INSTRUKTUR_FREELANCE = 'EDIT SLIP GAJI INSTRUKTUR FREELANCE';
  const INPUT_SLIP_GAJI_INSTRUKTUR_FREELANCE = 'INPUT SLIP GAJI INSTRUKTUR FREELANCE';
  const HAPUS_SLIP_GAJI_INSTRUKTUR_FREELANCE = 'HAPUS SLIP GAJI INSTRUKTUR FREELANCE';

  public static $menu_slip_gaji_instruktur_freelance = [
    self::MENU_SLIP_GAJI_INSTRUKTUR_FREELANCE,
    self::INPUT_SLIP_GAJI_INSTRUKTUR_FREELANCE,
    self::EDIT_SLIP_GAJI_INSTRUKTUR_FREELANCE,
    self::HAPUS_SLIP_GAJI_INSTRUKTUR_FREELANCE,
    self::CETAK_SLIP_GAJI_INSTRUKTUR_FREELANCE,
  ];

  const MENU_ABSENSI_SISWA = 'MENU ABSENSI SISWA';
  const INPUT_ABSENSI_SISWA = 'INPUT ABSENSI SISWA';
  const EDIT_ABSENSI_SISWA = 'EDIT ABSENSI SISWA';
  const KONFIRMASI_ABSENSI_SISWA = 'KONFIRMASI ABSENSI SISWA';

  public static $menu_absensi_siswa = [
    self::MENU_ABSENSI_SISWA,
    self::INPUT_ABSENSI_SISWA,
    self::EDIT_ABSENSI_SISWA,
    self::KONFIRMASI_ABSENSI_SISWA,
  ];

  const MENU_UBAH_PROFIL = 'MENU UBAH PROFIL';
  const MENU_UBAH_KATA_SANDI = 'MENU UBAH KATA SANDI';

  public static $menu_profil = [
    self::MENU_UBAH_PROFIL,
    self::MENU_UBAH_KATA_SANDI,
  ];

  public static function getAksi($level_user)
  {
    $data = [];
    if($level_user == User::L_GENERAL_ADMIN){
      $menu_pengubahan_jadwal = [self::MENU_PENGUBAHAN_JADWAL, self::KONFIRMASI_PENGUBAHAN_JADWAL];
      $menu_absensi = [self::MENU_ABSENSI_SISWA, self::KONFIRMASI_ABSENSI_SISWA];
      $data = array_merge($data, self::$menu_admin, self::$menu_accounting, self::$menu_instruktur, self::$menu_siswa);
      $data = array_merge($data, self::$menu_instrumen, self::$menu_kelas, self::$menu_studio, self::$menu_penempatan);
      $data = array_merge($data, self::$menu_jadwal_mengajar, self::$menu_jadwal_harian, $menu_pengubahan_jadwal, $menu_absensi);
      $data = array_merge($data, self::$menu_slip_gaji_staff, self::$menu_slip_gaji_instruktur_fulltime);
      $data = array_merge($data, self::$menu_slip_gaji_instruktur_freelance, self::$menu_profil);
    }
    elseif($level_user == User::L_ADMIN){
      $menu_pengubahan_jadwal = [self::MENU_PENGUBAHAN_JADWAL, self::KONFIRMASI_PENGUBAHAN_JADWAL];
      $menu_absensi = [self::MENU_ABSENSI_SISWA, self::KONFIRMASI_ABSENSI_SISWA];
      $data = array_merge($data, self::$menu_admin, self::$menu_accounting, self::$menu_instruktur, self::$menu_siswa);
      $data = array_merge($data, self::$menu_instrumen, self::$menu_kelas, self::$menu_studio, self::$menu_penempatan);
      $data = array_merge($data, self::$menu_jadwal_mengajar, self::$menu_jadwal_harian, $menu_pengubahan_jadwal, $menu_absensi);
      $data = array_merge($data, self::$menu_slip_gaji_staff, self::$menu_slip_gaji_instruktur_fulltime);
      $data = array_merge($data, self::$menu_slip_gaji_instruktur_freelance, self::$menu_profil);
    }
    elseif($level_user == User::L_INSTRUKTUR){
      $menu_absensi = [self::MENU_ABSENSI_SISWA, self::INPUT_ABSENSI_SISWA, self::EDIT_ABSENSI_SISWA];
      $menu_gaji_staff = [self::MENU_SLIP_GAJI_STAFF, self::CETAK_SLIP_GAJI_STAFF];
      $menu_gaji_fulltime = [self::MENU_SLIP_GAJI_INSTRUKTUR_FULLTIME, self::CETAK_SLIP_GAJI_INSTRUKTUR_FULLTIME];
      $menu_gaji_freelance = [self::MENU_SLIP_GAJI_INSTRUKTUR_FREELANCE, self::CETAK_SLIP_GAJI_INSTRUKTUR_FREELANCE];
      $data = array_merge($data, self::$menu_jadwal_mengajar, self::$menu_jadwal_harian, $menu_absensi);
      $data = array_merge($data, $menu_gaji_staff, $menu_gaji_fulltime, $menu_gaji_freelance, self::$menu_profil);
    }
    elseif($level_user == User::L_ACCOUNTING){
      $menu_absensi = [self::MENU_ABSENSI_SISWA, self::KONFIRMASI_ABSENSI_SISWA];
      $data = array_merge($data, $menu_absensi, self::$menu_profil);
    }
    elseif($level_user == User::L_SISWA){
      $menu_pengubahan_jadwal = [self::MENU_PENGUBAHAN_JADWAL, self::ADD_PENGUBAHAN_JADWAL];
      $menu_jadwal = [self::MENU_JADWAL_MENGAJAR];
      $menu_absensi = [self::MENU_ABSENSI_SISWA];
      $data = array_merge($data, $menu_pengubahan_jadwal, $menu_jadwal, $menu_absensi, self::$menu_profil);
    }

    foreach ($data as $index=>$aksi){
      $temp = [
        'aksi' => $aksi,
        'status' => self::getStatus($level_user, $aksi)
      ];
      $data[$index] = $temp;
    }

    return $data;
  }

  public static function getListMenu($level_user)
  {
    if($level_user == User::L_GENERAL_ADMIN){
      return [
        self::MENU_ADMIN, self::MENU_ACCOUNTING, self::MENU_INSTRUKTUR, self::MENU_SISWA,
        self::MENU_INSTRUMEN, self::MENU_KELAS, self::MENU_STUDIO, self::MENU_PENEMPATAN,
        self::MENU_JADWAL_MENGAJAR, self::MENU_JADWAL_HARIAN, self::MENU_PENGUBAHAN_JADWAL, self::MENU_ABSENSI_SISWA,
        self::MENU_SLIP_GAJI_STAFF, self::MENU_SLIP_GAJI_INSTRUKTUR_FREELANCE, self::MENU_SLIP_GAJI_INSTRUKTUR_FULLTIME,
        self::MENU_UBAH_PROFIL, self::MENU_UBAH_KATA_SANDI
      ];
    }
    elseif ($level_user == User::L_ADMIN){
      return [
        self::MENU_ADMIN, self::MENU_ACCOUNTING, self::MENU_INSTRUKTUR, self::MENU_SISWA,
        self::MENU_INSTRUMEN, self::MENU_KELAS, self::MENU_STUDIO, self::MENU_PENEMPATAN,
        self::MENU_JADWAL_MENGAJAR, self::MENU_JADWAL_HARIAN, self::MENU_PENGUBAHAN_JADWAL, self::MENU_ABSENSI_SISWA,
        self::MENU_SLIP_GAJI_STAFF, self::MENU_SLIP_GAJI_INSTRUKTUR_FREELANCE, self::MENU_SLIP_GAJI_INSTRUKTUR_FULLTIME,
        self::MENU_UBAH_PROFIL, self::MENU_UBAH_KATA_SANDI
      ];
    }
    elseif($level_user == User::L_INSTRUKTUR){
      return [
        self::MENU_JADWAL_MENGAJAR, self::MENU_JADWAL_HARIAN, self::MENU_ABSENSI_SISWA,
        self::MENU_SLIP_GAJI_INSTRUKTUR_FULLTIME, self::MENU_SLIP_GAJI_INSTRUKTUR_FREELANCE,
        self::MENU_UBAH_PROFIL, self::MENU_UBAH_KATA_SANDI
      ];
    }
    elseif ($level_user == User::L_ACCOUNTING){
      return [
        self::MENU_ABSENSI_SISWA, self::MENU_UBAH_PROFIL, self::MENU_UBAH_KATA_SANDI
      ];
    }
    elseif ($level_user == User::L_SISWA){
      return [
        self::MENU_PENGUBAHAN_JADWAL, self::MENU_JADWAL_MENGAJAR, self::MENU_ABSENSI_SISWA,
        self::MENU_UBAH_PROFIL, self::MENU_UBAH_KATA_SANDI
      ];
    }
    else return [];
  }

  public static function getStatus($level_user, $aksi)
  {
    $get = self::where('level_user', $level_user)->where('aksi', $aksi)->first();
    return $get ? $get->status : self::S_AKTIF;
  }

  public static function getAksiNonaktif($level_user, $arr_aksi)
  {
    return self::where('level_user', $level_user)
      ->whereIn('aksi', $arr_aksi)
      ->where('status', self::S_NONAKTIF)
      ->pluck('aksi')
      ->toArray();
  }

  public static function insertOrUpdate($data)
  {
    $exists = self::where('level_user', $data['level_user'])
      ->where('aksi', $data['aksi'])
      ->exists();

    if($exists){
      self::where('level_user', $data['level_user'])
        ->where('aksi', $data['aksi'])
        ->update($data);
    }
    else{
      self::insert($data);
    }
  }
}
