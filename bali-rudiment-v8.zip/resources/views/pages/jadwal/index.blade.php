@extends('layouts.main')

@section('title','Data Jadwal')

@php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_jadwal_mengajar);
  $nonaktif_input = in_array(\App\SettingMenu::CREATE_JADWAL_MENGAJAR, $arr_nonaktif);
  $nonaktif_edit = in_array(\App\SettingMenu::UPDATE_JADWAL_MENGAJAR, $arr_nonaktif);
  $nonaktif_delete = in_array(\App\SettingMenu::DELETE_JADWAL_MENGAJAR, $arr_nonaktif);
  $nonaktif_edit_siswa = in_array(\App\SettingMenu::CREATE_UPDATE_SISWA_JADWAL_MENGAJAR, $arr_nonaktif);
@endphp

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right mt-2 pt-1">
                @if($nonaktif_input == false)
                  <a href="{{ url('jadwal/add') }}" class="btn btn-primary">
                    <i class="mdi mdi-plus mr-2"></i>Input Data Jadwal
                  </a>
                @endif
              </div>
              <h4 class="page-title">Data Jadwal</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <form class="form-horizontal" method="get">
              <div class="form-group row mb-0">
                <label class="col-lg-3 text-right col-form-label" for="bulan">Bulan</label>
                <div class="col-lg-9">
                  <select name="bulan" id="bulan" class="form-control select2" onchange="this.form.submit()">
                    <option value="">Pilih Bulan</option>
                    @foreach($data_bulan as $bln)
                      <option value="{{ $bln }}" {{ $bln == $bulan ? 'selected' : '' }}>{{ \App\Http\Controllers\HelperController::setNamaBulan($bln) }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      @foreach($data as $instruktur)
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body pb-0">
              <h6 class="my-0">{{ $instruktur['nama_instruktur'] }}</h6>
            </div>
            <div class="card-body">
              <table class="table table-sm table-bordered mb-0">
                <thead>
                <tr>
                  <th style="width: 70px">Hari</th>
                  <th style="width: 100px" class="text-center">Jam</th>
                  <th style="width: 170px">Nama Studio</th>
                  @if(!($nonaktif_edit && $nonaktif_delete))
                    <th colspan="2">Nama Instrumen</th>
                  @else
                    <th>Nama Instrumen</th>
                  @endif
                  <th>Siswa</th>
                </tr>
                </thead>
                <tbody>
                {{--@php $history = []; @endphp--}}
                @foreach($instruktur['hari'] as $index_hari=>$hari)
                  @foreach($hari['jadwal'] as $index_jadwal=>$jadwal)
                    @for($index_siswa=0; $index_siswa<count($jadwal['siswa'])+1; $index_siswa++)

                      @php
                        $first_index_jadwal = $index_jadwal == 0;
                        $first_index_siswa = $index_siswa == 0;

                        $with_hari = $first_index_jadwal && $first_index_siswa;
                        $with_jadwal = $first_index_siswa;
                      @endphp

                      @include('components.jadwal.table_row_admin', ['with_hari' => $with_hari, 'with_jadwal' => $with_jadwal])

                      {{--@if($index_jadwal == 0)--}}
                        {{--@if($index_siswa == 0)--}}
                          {{--@php $history[] = 1; @endphp--}}
                          {{--@include('components.jadwal.table_row', ['with_hari' => true, 'with_jadwal' => true])--}}
                        {{--@else--}}
                          {{--@php $history[] = 2; @endphp--}}
                          {{--@include('components.jadwal.table_row', ['with_hari' => false, 'with_jadwal' => false])--}}
                        {{--@endif--}}
                      {{--@else--}}
                        {{--@if($index_siswa == 0)--}}
                          {{--@php $history[] = 3; @endphp--}}
                          {{--@include('components.jadwal.table_row', ['with_hari' => false, 'with_jadwal' => true])--}}
                        {{--@else--}}
                          {{--@php $history[] = 4; @endphp--}}
                          {{--@include('components.jadwal.table_row', ['with_hari' => false, 'with_jadwal' => false])--}}
                        {{--@endif--}}
                      {{--@endif--}}

                    @endfor
                  @endforeach
                @endforeach
                </tbody>
              </table>
              {{--<input type="hidden" value="{{ json_encode($history) }}">--}}
            </div>
          </div>
        </div>
      @endforeach
    </div>
  </div>

  <form action="{{ url('jadwal') }}" method="post" id="delete-form">
    @csrf @method('delete')
    <input type="hidden" name="id_jadwal" id="delete-id">
  </form>

  <div class="modal fade" id="modal-siswa" tabindex="-1" role="dialog" aria-labelledby="label">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="label">Pilih Siswa</h5>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body" id="modal-body-siswa">

        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="modal-jam" tabindex="-1" role="dialog" aria-labelledby="label">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="label">Edit Jam Mengajar Per Tanggal</h5>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body" id="modal-body-jam">

        </div>
      </div>
    </div>
  </div>

  <style>
    .table tr td{
      vertical-align: top !important;
    }
  </style>
@endsection
@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();

      function deleteData(id_jadwal) {
          swal({
              title: "Anda yakin?",
              text: "Data Jadwal yang akan dihapus, tidak bisa dikembalikan!",
              type: "warning",
              showCancelButton: true,
              confirmButtonColor: "#E62129",
              confirmButtonText: "Ya, hapus!",
              cancelButtonText: "Batalkan",
              closeOnConfirm: false
          }, function(){
              $("#delete-id").val(id_jadwal);
              $("#delete-form").submit();
          });
      }

      function openModalAddSiswa(id_jadwal) {
          $.ajax({
              url: '{{ url('jadwal/add-siswa/component/table-add') }}',
              type: 'get',
              data: {
                  id_jadwal: id_jadwal,
              },
              success: function(data) {
                  $("#modal-body-siswa").html(data);
                  $("#modal-siswa").modal('show');
              },
              error: async function(data) {
                  swal('Gagal','Terjadi kesalahan sistem','error');
              },
          });
      }

      function openModalEditJam(id_jadwal, id_siswa) {
          $.ajax({
              url: '{{ url('jadwal/add-siswa/component/edit-jam') }}',
              type: 'get',
              data: {
                  id_jadwal: id_jadwal,
                  id_siswa: id_siswa,
              },
              success: function(data) {
                  $("#modal-body-jam").html(data);
                  $("#modal-jam").modal('show');
              },
              error: async function(data) {
                  swal('Gagal','Terjadi kesalahan sistem','error');
              },
          });
      }

      function showJam(id_siswa) {
          let is_checked = $(`#id_siswa${id_siswa}`).is(":checked");
          if(is_checked){
              $(`#jam_siswa${id_siswa}`).show();
          }
          else{
              $(`#jam_siswa${id_siswa}`).hide();
          }
      }
  </script>
@endsection