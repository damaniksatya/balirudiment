<form action="<?php echo e(url('absensi/konfirmasi')); ?>" method="post">
  <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
  <input type="hidden" name="id_absensi" value="<?php echo e($id_absensi); ?>">
  <table class="table table-sm table-bordered">
    <thead>
    <tr>
      <th>Nama Siswa</th>
      <th>Fee</th>
    </tr>
    </thead>
    <tbody>
    <?php $arr_id_siswa = []; ?>
    <?php $__currentLoopData = $data_absensi_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $arr_id_siswa[] = $d['id_siswa']; ?>
      <tr>
        <td><?php echo e($d['siswa']['nama']); ?></td>
        <td>
          <input type="number" name="fee<?php echo e($d['id_siswa']); ?>" title="Fee <?php echo e($d['siswa']['nama']); ?>" class="form-control form-control-sm" value="<?php echo e(random_int(35, 65) * 1000); ?>">
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <input type="hidden" name="arr_id_siswa" value="<?php echo e(json_encode($arr_id_siswa)); ?>">
  <div class="form-group row mb-0">
    <div class="col-lg-12">
      <button class="btn btn-primary float-right">Konfirmasi</button>
    </div>
  </div>
</form>