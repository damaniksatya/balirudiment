@php
  $list_menu = \App\SettingMenu::getListMenu(\App\User::L_INSTRUKTUR);
  $arr_disable_menu = \App\SettingMenu::getAksiNonaktif(\App\User::L_INSTRUKTUR, $list_menu);
@endphp

@if(in_array(\App\SettingMenu::MENU_UBAH_PROFIL, $arr_disable_menu))
  <script>
      document.getElementById('btn-ubah-profil').style.display = 'none';
  </script>
@endif

@if(in_array(\App\SettingMenu::MENU_UBAH_KATA_SANDI, $arr_disable_menu))
  <script>
      document.getElementById('btn-ubah-kata-sandi').style.display = 'none';
  </script>
@endif

<ul class="metismenu" id="side-menu">
  <li class="text-center">
    <img src="{{ url('images/logo.jpg') }}" alt="Logo" width="60px" class="mt-2">
    <p class="menu-title">Bali Rudiment</p>
  </li>
  <li class="dropdown-divider"></li>
  <li>
    <a href="{{ url('home') }}">
      <i class="mdi mdi-home"></i>
      <span> Beranda </span>
    </a>
  </li>
  <li style="display: {{ in_array(\App\SettingMenu::MENU_JADWAL_MENGAJAR, $arr_disable_menu) ? 'none' : 'list-item' }}">
    <a href="{{ url('jadwal/instruktur') }}">
      <i class="mdi mdi-timer-sand"></i>
      <span> Jadwal Mengajar </span>
    </a>
  </li>
  <li style="display: {{ in_array(\App\SettingMenu::MENU_JADWAL_HARIAN, $arr_disable_menu) ? 'none' : 'list-item' }}">
    <a href="{{ url('jadwal-harian/instruktur') }}">
      <i class="mdi mdi-timer-sand"></i>
      <span> Jadwal Harian </span>
    </a>
  </li>
  <li style="display: {{ in_array(\App\SettingMenu::MENU_ABSENSI_SISWA, $arr_disable_menu) ? 'none' : 'list-item' }}">
    <a href="{{ url('absensi/instruktur') }}">
      <i class="mdi mdi-fingerprint"></i>
      <span> Absensi </span>
    </a>
  </li>
  @if(\App\Instruktur::isFreelance())
    <li style="display: {{ in_array(\App\SettingMenu::MENU_SLIP_GAJI_INSTRUKTUR_FREELANCE, $arr_disable_menu) ? 'none' : 'list-item' }}">
      <a href="{{ url('slip-gaji/freelance') }}">
        <i class="mdi mdi-file"></i>
        <span> Slip Gaji </span>
      </a>
    </li>
  @else
    <li style="display: {{ in_array(\App\SettingMenu::MENU_SLIP_GAJI_INSTRUKTUR_FULLTIME, $arr_disable_menu) ? 'none' : 'list-item' }}">
      <a href="{{ url('slip-gaji/fulltime') }}">
        <i class="mdi mdi-file"></i>
        <span> Slip Gaji </span>
      </a>
    </li>
  @endif
</ul>