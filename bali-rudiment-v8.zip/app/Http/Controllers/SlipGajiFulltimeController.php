<?php

namespace App\Http\Controllers;

use App\GajiFulltime;
use App\GajiFulltimeAbsenKerja;
use App\GajiFulltimeMengajar;
use App\Instruktur;
use App\JadwalSiswa;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class SlipGajiFulltimeController extends Controller
{
  public function index()
  {
    if(Auth::user()->level_user == User::L_GENERAL_ADMIN) {
      $data_bulan = GajiFulltime::getArrBulan();
      $bulan = HelperController::getValue('gaji_fulltime', ['bulan'])['bulan'];
      $data = GajiFulltime::getData($bulan);
//    dd($data);

      return view('pages.slip_gaji.fulltime.index')
        ->with('bulan', $bulan)
        ->with('data_bulan', $data_bulan)
        ->with('data', $data);
    }
    else{
      $id_instruktur = Instruktur::getIdInstruktur();
      $data = GajiFulltime::getDataByIdInstruktur($id_instruktur);

      return view('pages.slip_gaji.fulltime.index_instruktur')
        ->with('data', $data);
    }
  }

  public function viewAdd()
  {
    $data_instruktur = Instruktur::getData(Instruktur::JI_FULL_TIME);

    return view('pages.slip_gaji.fulltime.add')
      ->with('data_instruktur', $data_instruktur);
  }

  public function viewEdit($id_gaji)
  {
    $info = GajiFulltime::getInfo($id_gaji);
    $data_instruktur = Instruktur::getData(Instruktur::JI_FULL_TIME);

    return view('pages.slip_gaji.fulltime.edit')
      ->with('data_instruktur', $data_instruktur)
      ->with('info', $info);
  }

  public function store(Request $req)
  {
    $id_gaji = GajiFulltime::insertData([
      'id_instruktur' => $req->id_instruktur,
      'jabatan' => $req->jabatan,
      'bulan' => $req->bulan,
      'gaji_pokok_jml_hari' => $req->gaji_pokok_jml_hari ?: 0,
      'gaji_pokok_per_hari' => $req->gaji_pokok_per_hari ?: 0,
      'gaji_pokok' => $req->gaji_pokok ?: 0,
      'kehadiran_harian_jml_hari' => $req->kehadiran_harian_jml_hari ?: 0,
      'kehadiran_harian_per_hari' => $req->kehadiran_harian_per_hari ?: 0,
      'kehadiran_harian' => $req->kehadiran_harian ?: 0,
      'tunj_tambahan_jml_hari' => $req->tunj_tambahan_jml_hari ?: 0,
      'tunj_tambahan_per_hari' => $req->tunj_tambahan_per_hari ?: 0,
      'tunj_tambahan' => $req->tunj_tambahan ?: 0,
      'bonus_jml_hari' => $req->bonus_jml_hari ?: 0,
      'bonus_per_hari' => $req->bonus_per_hari ?: 0,
      'bonus' => $req->bonus ?: 0,
      'event_konser_jml_hari' => $req->event_konser_jml_hari ?: 0,
      'event_konser_per_hari' => $req->event_konser_per_hari ?: 0,
      'event_konser' => $req->event_konser ?: 0,
      'set_up_konser_jml_hari' => $req->set_up_konser_jml_hari ?: 0,
      'set_up_konser_per_hari' => $req->set_up_konser_per_hari ?: 0,
      'set_up_konser' => $req->set_up_konser ?: 0,
      'set_down_konser_jml_hari' => $req->set_down_konser_jml_hari ?: 0,
      'set_down_konser_per_hari' => $req->set_down_konser_per_hari ?: 0,
      'set_down_konser' => $req->set_down_konser ?: 0,
      'support_jml_hari' => $req->support_jml_hari ?: 0,
      'support_per_hari' => $req->support_per_hari ?: 0,
      'support' => $req->support ?: 0,
      'total_1' => $req->total_1 ?: 0,
      'libur_jml_hari' => $req->libur_jml_hari ?: 0,
      'libur_per_hari' => $req->libur_per_hari ?: 0,
      'libur' => $req->libur ?: 0,
      'sakit_jml_hari' => $req->sakit_jml_hari ?: 0,
      'sakit_per_hari' => $req->sakit_per_hari ?: 0,
      'sakit' => $req->sakit ?: 0,
      'kasbon' => $req->kasbon ?: 0,
      'total_2' => $req->total_2 ?: 0,
      'lembur_jam_jml_jam' => $req->lembur_jam_jml_jam ?: 0,
      'lembur_jam_per_jam' => $req->lembur_jam_per_jam ?: 0,
      'lembur_jam' => $req->lembur_jam ?: 0,
      'lembur_hari_jml_hari' => $req->lembur_hari_jml_hari ?: 0,
      'lembur_hari_per_hari' => $req->lembur_hari_per_hari ?: 0,
      'lembur_hari' => $req->lembur_hari ?: 0,
      'sub_total' => $req->sub_total ?: 0,
      'total_penerimaan' => $req->total_penerimaan ?: 0,
      'notes' => $req->notes,
    ]);

    return redirect("slip-gaji/fulltime/mengajar/$id_gaji");
  }

  public function update(Request $req)
  {
    GajiFulltime::updateData([
      'id_gaji' => $req->id_gaji,
      'id_instruktur' => $req->id_instruktur,
      'jabatan' => $req->jabatan,
      'bulan' => $req->bulan,
      'gaji_pokok_jml_hari' => $req->gaji_pokok_jml_hari ?: 0,
      'gaji_pokok_per_hari' => $req->gaji_pokok_per_hari ?: 0,
      'gaji_pokok' => $req->gaji_pokok ?: 0,
      'kehadiran_harian_jml_hari' => $req->kehadiran_harian_jml_hari ?: 0,
      'kehadiran_harian_per_hari' => $req->kehadiran_harian_per_hari ?: 0,
      'kehadiran_harian' => $req->kehadiran_harian ?: 0,
      'tunj_tambahan_jml_hari' => $req->tunj_tambahan_jml_hari ?: 0,
      'tunj_tambahan_per_hari' => $req->tunj_tambahan_per_hari ?: 0,
      'tunj_tambahan' => $req->tunj_tambahan ?: 0,
      'bonus_jml_hari' => $req->bonus_jml_hari ?: 0,
      'bonus_per_hari' => $req->bonus_per_hari ?: 0,
      'bonus' => $req->bonus ?: 0,
      'event_konser_jml_hari' => $req->event_konser_jml_hari ?: 0,
      'event_konser_per_hari' => $req->event_konser_per_hari ?: 0,
      'event_konser' => $req->event_konser ?: 0,
      'set_up_konser_jml_hari' => $req->set_up_konser_jml_hari ?: 0,
      'set_up_konser_per_hari' => $req->set_up_konser_per_hari ?: 0,
      'set_up_konser' => $req->set_up_konser ?: 0,
      'set_down_konser_jml_hari' => $req->set_down_konser_jml_hari ?: 0,
      'set_down_konser_per_hari' => $req->set_down_konser_per_hari ?: 0,
      'set_down_konser' => $req->set_down_konser ?: 0,
      'support_jml_hari' => $req->support_jml_hari ?: 0,
      'support_per_hari' => $req->support_per_hari ?: 0,
      'support' => $req->support ?: 0,
      'total_1' => $req->total_1 ?: 0,
      'libur_jml_hari' => $req->libur_jml_hari ?: 0,
      'libur_per_hari' => $req->libur_per_hari ?: 0,
      'libur' => $req->libur ?: 0,
      'sakit_jml_hari' => $req->sakit_jml_hari ?: 0,
      'sakit_per_hari' => $req->sakit_per_hari ?: 0,
      'sakit' => $req->sakit ?: 0,
      'kasbon' => $req->kasbon ?: 0,
      'total_2' => $req->total_2 ?: 0,
      'lembur_jam_jml_jam' => $req->lembur_jam_jml_jam ?: 0,
      'lembur_jam_per_jam' => $req->lembur_jam_per_jam ?: 0,
      'lembur_jam' => $req->lembur_jam ?: 0,
      'lembur_hari_jml_hari' => $req->lembur_hari_jml_hari ?: 0,
      'lembur_hari_per_hari' => $req->lembur_hari_per_hari ?: 0,
      'lembur_hari' => $req->lembur_hari ?: 0,
      'sub_total' => $req->sub_total ?: 0,
      'total_penerimaan' => $req->total_penerimaan ?: 0,
      'notes' => $req->notes,
    ]);

    return redirect('slip-gaji/fulltime')->with('success','Berhasil menyimpan data');
  }

  public function viewEditMengajar($id_gaji)
  {
    $info = GajiFulltime::getInfo($id_gaji);
    $exists_mengajar = GajiFulltimeMengajar::isExists($id_gaji);
    if($exists_mengajar){
      $data = GajiFulltimeMengajar::getData($id_gaji);
    }
    else $data = JadwalSiswa::getJadwalUntukSlipGaji($info->id_instruktur, $info->bulan);
//    dd($info, $exists_mengajar, $data);

    return view('pages.slip_gaji.fulltime.mengajar')
      ->with('info', $info)
      ->with('data', $data);
  }

  public function viewEditAbsensi($id_gaji)
  {
    $info = GajiFulltime::getInfo($id_gaji);
    $arr_tgl = $this->getArrTgl($info->bulan);
    $data = $this->getDataAbsensi($id_gaji, $arr_tgl);
//    dd($info, $data, $arr_tgl);

    return view('pages.slip_gaji.fulltime.absensi')
      ->with('data', $data)
      ->with('arr_tgl', $arr_tgl)
      ->with('info', $info);
  }

  public function storeMengajar(Request $req)
  {
    DB::transaction(function () use ($req){
      for($i=0; $i<$req->jumlah_data; $i++){
        $temp = [
          'id' => $req["id$i"],
          'id_gaji_fulltime' => $req["id_gaji_fulltime"],
          'nama_siswa' => $req["nama_siswa$i"],
          'durasi' => $req["durasi$i"],
          'jumlah_pertemuan' => $req["jumlah_pertemuan$i"],
          'debut' => $req["debut$i"],
          'regular' => $req["regular$i"],
          'notes' => $req["notes$i"],
        ];

        if($req["nama_siswa$i"] || $req["durasi$i"] || $req["jumlah_pertemuan$i"] || $req["debut$i"] || $req["regular$i"] || $req["notes$i"]){
          if($req["id$i"]){
            GajiFulltimeMengajar::updateData($temp);
          }
          else{
            GajiFulltimeMengajar::insertData($temp);
          }
        }
        elseif($req["id$i"] != null){
          GajiFulltimeMengajar::deleteData($temp);
        }
      }
    });

    if($req->back_url){
      return redirect($req->back_url)->with('success','Berhasil menyimpan data');
    }
    else{
      return redirect("slip-gaji/fulltime/absensi/$req->id_gaji_fulltime");
    }
  }

  public function storeAbsensi(Request $req)
  {
    $arr_tgl = (array)json_decode($req->arr_tgl);
    $arr_kehadiran = [];
    $arr_note = [];

    foreach($arr_tgl as $tgl){
      $arr_kehadiran[] = $req["kehadiran-$tgl"];
      $arr_note[] = $req["note-$tgl"];
    }

    GajiFulltimeAbsenKerja::insertOrUpdate([
      'id_gaji_fulltime' => $req->id_gaji_fulltime,
      'bulan' => $req->bulan,
      'tanggal' => json_encode($arr_tgl),
      'kehadiran' => json_encode($arr_kehadiran),
      'note' => json_encode($arr_note),
    ]);

//    dd($req, $arr_tgl);
    return redirect('slip-gaji/fulltime')->with('success','Berhasil menyimpan data');
  }

  public function printSlipGaji($id_gaji)
  {
    $info = GajiFulltime::getInfo($id_gaji);
    $exists_mengajar = GajiFulltimeMengajar::isExists($id_gaji);
    if($exists_mengajar){
      $mengajar = GajiFulltimeMengajar::getData($id_gaji);
    }
    else{
      $mengajar = $data = JadwalSiswa::getJadwalUntukSlipGaji($info->id_instruktur, $info->bulan);
    }
    $arr_tgl = $this->getArrTgl($info->bulan);
    $absensi = $this->getDataAbsensi($id_gaji, $arr_tgl);
    $data = [
      'gaji' => $info,
      'mengajar' => $mengajar,
      'absensi' => $absensi,
      'nama_bulan' => HelperController::setNamaBulan($info->bulan)
    ];
//    dd($data);
    $pdf = \App::make('dompdf.wrapper');
    $pdf->setPaper('a4', 'portrait');
    $pdf->loadView('pdf.slip_gaji_fulltime', $data);
    return $pdf->stream("Slip Gaji Instruktur Fulltime.pdf");
  }

  public function delete(Request $req)
  {
    DB::transaction(function () use ($req){
      GajiFulltime::deleteData($req->id_gaji);
      GajiFulltimeMengajar::deleteByIdGaji($req->id_gaji);
      GajiFulltimeAbsenKerja::deleteData($req->id_gaji);
    });

    return back()->with('success','Berhasil menghapus data');
  }

  private function getArrTgl($bln)
  {
    $arr_tgl = [];

    for($i=1; $i<=31; $i++){
      $tgl = sprintf("%02d", $i);
      $tgl = date('Y-m-d', ((int)strtotime($bln.'-'.$tgl)));
      if(date('Y-m', strtotime($tgl)) == $bln){
        $arr_tgl[] = date('d', strtotime($tgl));
      }
    }

    return $arr_tgl;
  }

  private function getDataAbsensi($id_gaji, $arr_tgl)
  {
    $get = GajiFulltimeAbsenKerja::getInfo($id_gaji);
    $arr_kehadiran = $get ? (array)json_decode($get->kehadiran) : [];
    $arr_note = $get ? (array)json_decode($get->note) : [];
    $temp = [];

    foreach($arr_tgl as $index=>$tgl){
      $temp[$tgl] = [
        'kehadiran' => array_key_exists($index, $arr_kehadiran) ? $arr_kehadiran[$index] : null,
        'note' => array_key_exists($index, $arr_note) ? $arr_note[$index] : null,
      ];
    }

    $data = [
      'data' => $temp,
      'note' => $get ? $get->note : null
    ];

    return $data;
  }
}
