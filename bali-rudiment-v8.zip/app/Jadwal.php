<?php

namespace App;

use App\Http\Controllers\HelperController;
use App\Http\Controllers\JadwalController;
use Illuminate\Database\Eloquent\Model;

class Jadwal extends Model
{
  protected $table = 'jadwal';
  public $timestamps = false;

  const H_SENIN = 'SENIN';
  const H_SELASA = 'SELASA';
  const H_RABU = 'RABU';
  const H_KAMIS = 'KAMIS';
  const H_JUMAT = 'JUMAT';
  const H_SABTU = 'SABTU';
  const H_MINGGU = 'MINGGU';

  const MAX_DURASI_MENGAJAR = 2 * 3600; //2 Jam

  public static $hari = [
    1 => self::H_SENIN,
    2 => self::H_SELASA,
    3 => self::H_RABU,
    4 => self::H_KAMIS,
    5 => self::H_JUMAT,
    6 => self::H_SABTU,
    0 => self::H_MINGGU,
  ];

  public static $no_hari = [
    self::H_MINGGU => 0,
    self::H_SENIN => 1,
    self::H_SELASA => 2,
    self::H_RABU => 3,
    self::H_KAMIS => 4,
    self::H_JUMAT => 5,
    self::H_SABTU => 6,
  ];

  public static function getInfo($id_jadwal)
  {
    return self::leftJoin('instruktur','instruktur.id_instruktur','=','jadwal.id_instruktur')
      ->leftJoin('studio','studio.id_studio','=','jadwal.id_studio')
      ->leftJoin('instrumen','instrumen.id_instrumen','=','jadwal.id_instrumen')
      ->leftJoin('penempatan','penempatan.id_penempatan','=','instruktur.id_penempatan')
      ->select('jadwal.*','instruktur.nama_instruktur','studio.nama_studio','instrumen.nama_instrumen','penempatan.id_penempatan','penempatan.nama_penempatan')
      ->where('jadwal.id_jadwal', $id_jadwal)
      ->first();
  }

  public static function getData($bulan)
  {
    $data_instruktur = self::leftJoin('instruktur as i','i.id_instruktur','=','jadwal.id_instruktur')
      ->select('jadwal.id_instruktur','i.nama_instruktur')
      ->where('jadwal.bulan', $bulan)
      ->groupBy('jadwal.id_instruktur','i.nama_instruktur')
      ->orderBy('jadwal.id_instruktur')
      ->get()->toArray();

    foreach($data_instruktur as $ii=>$di){
      $data_hari = self::where('id_instruktur', $di['id_instruktur'])
        ->where('bulan', $bulan)
        ->select('hari')
        ->groupBy('hari')
        ->orderBy('hari')
        ->get()->toArray();

      $total_jadwal1 = 0;
      $total_siswa1 = 0;
      foreach($data_hari as $ih=>$dh){
        $data_jadwal = self::leftJoin('studio as s','s.id_studio','=','jadwal.id_studio')
          ->leftJoin('instrumen as i','i.id_instrumen','=','jadwal.id_instrumen')
          ->where('jadwal.bulan', $bulan)
          ->where('jadwal.id_instruktur', $di['id_instruktur'])
          ->where('jadwal.hari', $dh['hari'])
          ->select('s.nama_studio','i.nama_instrumen','jadwal.*')
          ->orderBy('jadwal.jam_mulai','ASC')
          ->get()->toArray();

        $total_siswa2 = 0;
        foreach($data_jadwal as $ij=>$dj){
          $data_siswa = JadwalSiswa::getSiswaByIdJadwal($dj['id_jadwal']);

          $data_jadwal[$ij]['siswa'] = $data_siswa;
          $data_jadwal[$ij]['siswa_total'] = count($data_siswa);
          $total_siswa1 += count($data_siswa);
          $total_siswa2 += (count($data_siswa) + 1);
        }

        $data_hari[$ih]['jadwal'] = $data_jadwal;
        $data_hari[$ih]['jadwal_total'] = count($data_jadwal);
        $data_hari[$ih]['siswa_total'] = $total_siswa2;
        $total_jadwal1 += count($data_jadwal);
      }

      $data_instruktur[$ii]['hari'] = $data_hari;
      $data_instruktur[$ii]['hari_total'] = count($data_hari);
      $data_instruktur[$ii]['jadwal_total'] = $total_jadwal1;
      $data_instruktur[$ii]['siswa_total'] = $total_siswa1;
    }

    return $data_instruktur;
  }

  public static function getDataByInstruktur($bulan)
  {
    $id_instruktur = Instruktur::getIdInstruktur();
    $data_tanggal = self::leftJoin('jadwal_siswa as js','js.id_jadwal','=','jadwal.id_jadwal')
      ->where('jadwal.id_instruktur', $id_instruktur)
      ->where('jadwal.bulan', $bulan)
      ->where('js.tanggal','!=', null)
      ->select('js.tanggal','jadwal.hari')
      ->groupBy('js.tanggal','jadwal.hari')
      ->orderBy('js.tanggal')
      ->get()->toArray();

    foreach($data_tanggal as $it=>$tgl){
      $total_siswa = 0;
      $data_jadwal = self::leftJoin('studio as s','s.id_studio','=','jadwal.id_studio')
        ->leftJoin('instrumen as i','i.id_instrumen','=','jadwal.id_instrumen')
        ->leftJoin('jadwal_siswa as js','js.id_jadwal','=','jadwal.id_jadwal')
        ->where('jadwal.bulan', $bulan)
        ->where('jadwal.id_instruktur', $id_instruktur)
        ->where('js.tanggal', $tgl)
        ->select('s.nama_studio','i.nama_instrumen','jadwal.id_jadwal', 'jadwal.id_instruktur', 'jadwal.id_studio', 'jadwal.id_instrumen', 'jadwal.bulan', 'jadwal.hari', 'jadwal.jam_mulai', 'jadwal.jam_selesai')
        ->groupBy('s.nama_studio','i.nama_instrumen','jadwal.id_jadwal', 'jadwal.id_instruktur', 'jadwal.id_studio', 'jadwal.id_instrumen', 'jadwal.bulan', 'jadwal.hari', 'jadwal.jam_mulai', 'jadwal.jam_selesai')
        ->orderBy('jadwal.jam_mulai','ASC')
        ->get()->toArray();

      foreach($data_jadwal as $ij=>$jadwal){
        $data_siswa = JadwalSiswa::getSiswaByIdJadwal($jadwal['id_jadwal'], $tgl);

        $data_jadwal[$ij]['siswa'] = $data_siswa;
        $data_jadwal[$ij]['total_siswa'] = count($data_siswa);
        $total_siswa += $data_jadwal[$ij]['total_siswa'];
      }

      $data_tanggal[$it]['jadwal'] = $data_jadwal;
      $data_tanggal[$it]['total_siswa'] = $total_siswa;
    }

    return $data_tanggal;
  }

  public static function getDataBySiswaOld($bulan)
  {
    $id_siswa = Siswa::getIdSiswa();
    $data_tanggal = self::leftJoin('jadwal_siswa as js','js.id_jadwal','=','jadwal.id_jadwal')
      ->where('js.id_siswa', $id_siswa)
      ->where('jadwal.bulan', $bulan)
      ->where('js.tanggal','!=', null)
      ->select('js.tanggal','jadwal.hari')
      ->groupBy('js.tanggal','jadwal.hari')
      ->orderBy('js.tanggal')
      ->get()->toArray();

    foreach($data_tanggal as $it=>$tgl) {
      $total_siswa = 0;
      $data_jadwal = self::leftJoin('studio as s','s.id_studio','=','jadwal.id_studio')
        ->leftJoin('instrumen as i','i.id_instrumen','=','jadwal.id_instrumen')
        ->leftJoin('jadwal_siswa as js','js.id_jadwal','=','jadwal.id_jadwal')
        ->leftJoin('instruktur','instruktur.id_instruktur','=','jadwal.id_instruktur')
        ->where('jadwal.bulan', $bulan)
        ->where('js.id_siswa', $id_siswa)
        ->where('js.tanggal', $tgl)
        ->select('s.nama_studio','i.nama_instrumen','instruktur.nama_instruktur','jadwal.id_jadwal', 'jadwal.id_instruktur', 'jadwal.id_studio', 'jadwal.id_instrumen', 'jadwal.bulan', 'jadwal.hari', 'jadwal.jam_mulai', 'jadwal.jam_selesai')
        ->groupBy('s.nama_studio','i.nama_instrumen','instruktur.nama_instruktur','jadwal.id_jadwal', 'jadwal.id_instruktur', 'jadwal.id_studio', 'jadwal.id_instrumen', 'jadwal.bulan', 'jadwal.hari', 'jadwal.jam_mulai', 'jadwal.jam_selesai')
        ->orderBy('jadwal.jam_mulai','ASC')
        ->get()->toArray();


      foreach($data_jadwal as $ij=>$jadwal){
        $data_siswa = JadwalSiswa::getSiswaByIdJadwal($jadwal['id_jadwal'], $tgl);

        $data_jadwal[$ij]['siswa'] = $data_siswa;
        $data_jadwal[$ij]['total_siswa'] = count($data_siswa);
        $total_siswa += $data_jadwal[$ij]['total_siswa'];
      }

      $data_tanggal[$it]['jadwal'] = $data_jadwal;
      $data_tanggal[$it]['total_siswa'] = $total_siswa;
    }

    return $data_tanggal;
  }

  public static function getDataBySiswa($bulan)
  {
    $id_siswa = Siswa::getIdSiswa();
    $get = self::leftJoin('jadwal_siswa as js','js.id_jadwal','=','jadwal.id_jadwal')
      ->where('js.id_siswa', $id_siswa)
      ->where('jadwal.bulan', $bulan)
      ->where('js.tanggal','!=', null)
      ->select('js.jam_mulai','js.jam_selesai','js.tanggal','jadwal.id_jadwal','jadwal.id_instruktur','jadwal.id_studio','jadwal.id_instrumen','jadwal.bulan','jadwal.hari')
      ->get();

    foreach($get as &$g){
      $g->instruktur = Instruktur::getInfoByIdInstruktur($g->id_instruktur);
      $g->studio = Studio::getInfo($g->id_studio);
      $g->instrumen = Instrumen::getInfo($g->id_instrumen);
    }

    return $get;
  }

  public static function getArrBulan()
  {
    return self::select("bulan")
      ->groupBy('bulan')
      ->orderBy('bulan','DESC')
      ->pluck('bulan')
      ->toArray();
  }

  public static function getArrBulanByInstruktur()
  {
    $id_instruktur = Instruktur::getIdInstruktur();
    return self::select("bulan")
      ->where('id_instruktur', $id_instruktur)
      ->groupBy('bulan')
      ->orderBy('bulan','DESC')
      ->pluck('bulan')
      ->toArray();
  }

  public static function getDurasiMengajar($id_jadwal)
  {
    $info = self::getInfo($id_jadwal);
    $start = strtotime(date('Y-m-d'.' '.$info->jam_mulai.':00'));
    $end = strtotime(date('Y-m-d'.' '.$info->jam_selesai.':00'));

    return ($end - $start) / 60;
  }

  public static function getPilihanPengubahanJadwal($durasi_menit)
  {
    $info_siswa = Siswa::getInfoSiswaLogin();
    $month_now = date('Y-m');
    $date_now = date('Y-m-d');
//    $arr_id_jadwal = JadwalSiswa::getArrIdJadwalBySiswa($info_siswa->id_siswa);
    $arr_id_jadwal = [];

    $get = self::leftJoin('studio','studio.id_studio','=','jadwal.id_studio')
      ->leftJoin('instrumen','instrumen.id_instrumen','=','jadwal.id_instrumen')
      ->leftJoin('instruktur','instruktur.id_instruktur','=','jadwal.id_instruktur')
      ->select('jadwal.*','studio.nama_studio','instrumen.nama_instrumen','instruktur.nama_instruktur')
      ->where('studio.id_penempatan', $info_siswa->id_penempatan)
      ->where('jadwal.id_instrumen', $info_siswa->id_instrumen)
      ->where('jadwal.bulan','>=', $month_now)
      ->whereNotIn('jadwal.id_jadwal', $arr_id_jadwal)
      ->get();

    $durasi_detik = $durasi_menit*60;
    foreach($get as $index=>$g){
      $batas_jam_selesai = strtotime(date("Y-m-d $g->jam_selesai")) - $durasi_detik;
      $batas_jam_selesai = date('H:i', $batas_jam_selesai);
      $arr_waktu_mulai = HelperController::getArrJam($g->jam_mulai, $batas_jam_selesai);
      $arr_waktu = [];
      foreach ($arr_waktu_mulai as $i=>$waktu_mulai){
        $waktu_selesai = HelperController::getNextJam($waktu_mulai, $durasi_menit);
        $arr_waktu[] = $waktu_mulai.'-'.$waktu_selesai;
      }
      $get[$index]['arr_waktu'] = $arr_waktu;
      $get[$index]['arr_tgl'] = JadwalController::getArrTglDariHari($g->bulan, $g->hari, $date_now);
    }

    return $get;
  }

  public static function getPilihanAbsensi()
  {
    $id_instruktur = Instruktur::getIdInstruktur();
    $date_now = date('Y-m-d');

    $absensi = Absensi::getDataByInstruktur($id_instruktur);
    $data = [];

    $jadwal = self::leftJoin('studio as s','s.id_studio','=','jadwal.id_studio')
      ->leftJoin('instrumen as i','i.id_instrumen','=','jadwal.id_instrumen')
      ->leftJoin('jadwal_siswa as js','js.id_jadwal','=','jadwal.id_jadwal')
      ->where('jadwal.id_instruktur', $id_instruktur)
      ->where('js.tanggal','<=', $date_now)
      ->select('s.nama_studio','i.nama_instrumen','jadwal.id_jadwal', 'jadwal.id_instruktur', 'jadwal.id_studio', 'jadwal.id_instrumen', 'jadwal.bulan', 'jadwal.hari', 'jadwal.jam_mulai', 'jadwal.jam_selesai','js.tanggal')
      ->groupBy('s.nama_studio','i.nama_instrumen','jadwal.id_jadwal', 'jadwal.id_instruktur', 'jadwal.id_studio', 'jadwal.id_instrumen', 'jadwal.bulan', 'jadwal.hari', 'jadwal.jam_mulai', 'jadwal.jam_selesai','js.tanggal')
      ->orderBy('js.tanggal','DESC')
      ->get();

    if(count($absensi)){
      foreach($jadwal as $j){
        foreach($absensi as $a){
          if(!($j->id_jadwal == $a->id_jadwal && $j->tanggal == $a->tanggal)){
            $data[] = $j;
          }
        }
      }

      return $data;
    }
    else return $jadwal;
  }

  public static function getJumlahByBulan($bulan)
  {
    return self::where('bulan', $bulan)->count();
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function isJadwalBertabrakanByInstruktur($data, $except_id = null)
  {
    $jam_mulai = self::where('id_instruktur', $data['id_instruktur'])
      ->where('id_jadwal','!=', $except_id)
      ->where('bulan', $data['bulan'])
      ->where('hari', $data['hari'])
      ->where('jam_selesai','>', $data['jam_mulai'])
      ->where('jam_mulai','<', $data['jam_mulai'])
      ->first();

    $jam_selesai = self::where('id_instruktur', $data['id_instruktur'])
      ->where('id_jadwal','!=', $except_id)
      ->where('bulan', $data['bulan'])
      ->where('hari', $data['hari'])
      ->where('jam_mulai','<', $data['jam_selesai'])
      ->where('jam_selesai','>', $data['jam_selesai'])
      ->first();

    $jam_mulai_selesai = self::where('id_instruktur', $data['id_instruktur'])
      ->where('id_jadwal','!=', $except_id)
      ->where('bulan', $data['bulan'])
      ->where('hari', $data['hari'])
      ->where('jam_mulai','>=', $data['jam_mulai'])
      ->where('jam_selesai','<=', $data['jam_selesai'])
      ->first();

    return [
      'status' => $jam_mulai || $jam_selesai || $jam_mulai_selesai,
      'info' => $jam_mulai ?: ($jam_selesai ?: $jam_mulai_selesai)
    ];
  }

  public static function isJadwalBertabrakanByStudio($data, $except_id = null)
  {
    $jam_mulai = self::where('id_studio', $data['id_studio'])
      ->where('id_jadwal','!=', $except_id)
      ->where('bulan', $data['bulan'])
      ->where('hari', $data['hari'])
      ->where('jam_selesai','>', $data['jam_mulai'])
      ->where('jam_mulai','<', $data['jam_mulai'])
      ->first();

    $jam_selesai = self::where('id_studio', $data['id_studio'])
      ->where('id_jadwal','!=', $except_id)
      ->where('bulan', $data['bulan'])
      ->where('hari', $data['hari'])
      ->where('jam_mulai','<', $data['jam_selesai'])
      ->where('jam_selesai','>', $data['jam_selesai'])
      ->first();

    $jam_mulai_selesai = self::where('id_studio', $data['id_studio'])
      ->where('id_jadwal','!=', $except_id)
      ->where('bulan', $data['bulan'])
      ->where('hari', $data['hari'])
      ->where('jam_mulai','>=', $data['jam_mulai'])
      ->where('jam_selesai','<=', $data['jam_selesai'])
      ->first();

    return [
      'status' => $jam_mulai || $jam_selesai || $jam_mulai_selesai,
      'info' => $jam_mulai ?: ($jam_selesai ?: $jam_mulai_selesai)
    ];
  }

  public static function updateData($data)
  {
    self::where('id_jadwal', $data['id_jadwal'])->update($data);
  }

  public static function deleteData($id_jadwal)
  {
    self::where('id_jadwal', $id_jadwal)->delete();
  }
}
