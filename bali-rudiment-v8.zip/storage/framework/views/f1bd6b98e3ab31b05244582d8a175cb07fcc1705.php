<?php
  $list_menu = \App\SettingMenu::getListMenu(\App\User::L_ACCOUNTING);
  $arr_disable_menu = \App\SettingMenu::getAksiNonaktif(\App\User::L_ACCOUNTING, $list_menu);
?>

<ul class="metismenu" id="side-menu">
  <li class="text-center">
    <img src="<?php echo e(url('images/logo.jpg')); ?>" alt="Logo" width="60px" class="mt-2">
    <p class="menu-title">Bali Rudiment</p>
  </li>
  <li class="dropdown-divider"></li>
  <li>
    <a href="<?php echo e(url('home')); ?>">
      <i class="mdi mdi-home"></i>
      <span> Beranda </span>
    </a>
  </li>

  <?php
    $jumlah_menunggu_konfirmasi = \App\Absensi::getJumlahMenungguKonfirmasi();
  ?>

  <li style="display: <?php echo e(in_array(\App\SettingMenu::MENU_ABSENSI_SISWA, $arr_disable_menu) ? 'none' : 'list-item'); ?>">
    <a href="javascript: void(0);">
      <i class="mdi mdi-fingerprint"></i>
      <span> Absensi </span>
      <?php if($jumlah_menunggu_konfirmasi >= 1): ?>
        <span class="badge badge-danger" style="padding-top: 5px; padding-left: 4px"><?php echo e($jumlah_menunggu_konfirmasi); ?></span>
      <?php endif; ?>
      <span class="menu-arrow"></span>
    </a>
    <ul class="nav-second-level mm-collapse" aria-expanded="false">
      <li>
        <a href="<?php echo e(url('absensi/menunggu-konfirmasi')); ?>">
          Menunggu Konfirmasi
          <?php if($jumlah_menunggu_konfirmasi >= 1): ?>
            <span class="badge badge-danger" style="padding-top: 5px"><?php echo e($jumlah_menunggu_konfirmasi); ?></span>
          <?php endif; ?>
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('absensi/dikonfirmasi')); ?>">
          Dikonfirmasi
        </a>
      </li>
    </ul>
  </li>

</ul>