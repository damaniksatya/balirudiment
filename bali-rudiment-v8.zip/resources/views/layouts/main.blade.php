<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>@yield('title')</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta content="Bali Rudiment" name="description" />
  {{--<meta content="Bali Rudiment. Created with ♥ by " name="description" />--}}
  <meta content="LaraDev" name="author" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <link rel="icon" type="image/jpg" sizes="16x16" href="{{ url('images/logo.jpg') }}">
  @yield('css')
  <link href="{{ url('css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" id="bootstrap-stylesheet" />
  <link href="{{ url('css/icons.min.css') }}" rel="stylesheet" type="text/css" />
  <link href="{{ url('css/app.min.css') }}" rel="stylesheet" type="text/css"  id="app-stylesheet" />
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/@mdi/font@6.9.96/css/materialdesignicons.min.css">
</head>
<body>
<div id="wrapper">
  <div class="navbar-custom">
    @include('components.top_navbar')
  </div>
  <div class="left-side-menu" style="width: 260px">
    @include('components.sidebar')
  </div>
  <div class="content-page" style="margin-left: 260px">
    @yield('content')
    @include('components.footer')
  </div>
</div>
<script src="{{ url('js/vendor.min.js') }}"></script>
<script src="{{ url('js/app.min.js') }}"></script>
@yield('script')
</body>
</html>