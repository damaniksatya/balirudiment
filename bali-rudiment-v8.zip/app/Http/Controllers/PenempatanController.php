<?php

namespace App\Http\Controllers;

use App\Penempatan;
use Illuminate\Http\Request;

class PenempatanController extends Controller
{
  public function index()
  {
    $data = Penempatan::getData();

    return view('pages.penempatan.index')
      ->with('data', $data);
  }

  public function viewAdd()
  {
    return view('pages.penempatan.add');
  }

  public function viewEdit($id)
  {
    $info = Penempatan::getInfo($id);

    return view('pages.penempatan.edit')
      ->with('info', $info);
  }

  public function store(Request $req)
  {
    $this->validateData();

    Penempatan::insertData([
      'nama_penempatan' => $req->nama_penempatan
    ]);

    return back()->with('success','Berhasil menyimpan data');
  }

  public function update(Request $req)
  {
    $new_nama = $req->nama_penempatan != $req->nama_penempatan_old;
    $this->validateData($new_nama);

    Penempatan::updateData([
      'id_penempatan' => $req->id_penempatan,
      'nama_penempatan' => $req->nama_penempatan
    ]);

    return redirect('penempatan')->with('success','Berhasil menyimpan data');
  }

  public function delete(Request $req)
  {
    Penempatan::deleteData($req->id);

    return back()->with('success','Berhasil menghapus data');
  }

  private function validateData($new_nama = true)
  {
    return request()->validate([
      'nama_penempatan' => 'required|max:40'.($new_nama ? '|unique:penempatan' : '')
    ],[
      'nama_penempatan.required' => 'Nama Penempatan harus diisi!',
      'nama_penempatan.max' => 'Nama Penempatan maksimal :max karakter!',
      'nama_penempatan.unique' => 'Nama Penempatan sudah digunakan!'
    ]);
  }
}
