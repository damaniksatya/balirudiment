<?php if(count($data_siswa)): ?>
  <form action="<?php echo e(url('jadwal/add-siswa')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="siswa_in_jadwal" value="<?php echo e(json_encode($siswa_in_jadwal)); ?>">
    <input type="hidden" name="siswa_not_in_jadwal" value="<?php echo e(json_encode($siswa_not_in_jadwal)); ?>">
    <input type="hidden" name="id_jadwal" value="<?php echo e($info->id_jadwal); ?>">
    <input type="hidden" name="bulan" value="<?php echo e($info->bulan); ?>">
    <input type="hidden" name="hari" value="<?php echo e($info->hari); ?>">
    <table class="table table-sm table-bordered">
      <tbody>
      <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $jam_siswa = \App\JadwalSiswa::getJamMulaiSelesai($info->id_jadwal, $d->id_siswa);
        ?>
        <tr>
          <td>
            <div class="custom-control custom-checkbox">
              <input type="checkbox" name="id_siswa[]" value="<?php echo e($d->id_siswa); ?>" class="custom-control-input"
                     onchange="showJam('<?php echo e($d->id_siswa); ?>')"
                     id="id_siswa<?php echo e($d->id_siswa); ?>" <?php echo e(in_array($d->id_siswa, $siswa_in_jadwal) ? 'checked' : ''); ?>>
              <label class="custom-control-label" for="id_siswa<?php echo e($d->id_siswa); ?>" style="cursor: pointer"><?php echo e($d->nama_siswa); ?></label>
            </div>
            <table class="table-borderless" id="jam_siswa<?php echo e($d->id_siswa); ?>" style="display: <?php echo e(in_array($d->id_siswa, $siswa_in_jadwal) ? 'block' : 'none'); ?>">
              <tr>
                <td style="width: 20px"></td>
                <td>
                  <input type="hidden" name="jam_mulai_old<?php echo e($d->id_siswa); ?>" value="<?php echo e($jam_siswa['jam_mulai']); ?>">
                  <select name="jam_mulai<?php echo e($d->id_siswa); ?>" id="jam_mulai<?php echo e($d->id_siswa); ?>" class="form-control form-control-sm" title="Jam Mulai">
                    <option value="">Pilih Jam Mulai</option>
                    <?php $__currentLoopData = $data_jam['arr_jam_mulai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($jam); ?>" <?php echo e($jam_siswa['jam_mulai'] == $jam ? 'selected' : ''); ?>><?php echo e($jam); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </td>
                <td class="font-12" style="vertical-align: middle !important;">Sampai</td>
                <td>
                  <input type="hidden" name="jam_selesai_old<?php echo e($d->id_siswa); ?>" value="<?php echo e($jam_siswa['jam_selesai']); ?>">
                  <select name="jam_selesai<?php echo e($d->id_siswa); ?>" id="jam_selesai<?php echo e($d->id_siswa); ?>" class="form-control form-control-sm" title="Jam Selesai">
                    <option value="">Pilih Jam Selesai</option>
                    <?php $__currentLoopData = $data_jam['arr_jam_selesai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($jam); ?>" <?php echo e($jam_siswa['jam_selesai'] == $jam ? 'selected' : ''); ?>><?php echo e($jam); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <button class="btn btn-primary float-right">Simpan</button>
  </form>
<?php else: ?>
  <div class="text-center alert alert-info mb-0">
    <i class="mdi mdi-information-outline" style="font-size: 42px"></i>
    <p class="mb-2 font-weight-bold">Data siswa tidak tersedia!</p>
    <p class="border-bottom mb-2" style="border-color: rgba(0, 0, 0, 0.15) !important;"></p>
    <p class="mb-0">Data siswa aktif yang bertempat di <b><?php echo e($info->nama_penempatan); ?></b> dengan instrumen <b><?php echo e($info->nama_instrumen); ?></b> tidak tersedia!</p>
  </div>
<?php endif; ?>