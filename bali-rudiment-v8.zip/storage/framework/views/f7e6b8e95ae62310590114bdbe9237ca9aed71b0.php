<link href="<?php echo e(url('libs/bootstrap-timepicker/bootstrap-timepicker.min.css')); ?>" rel="stylesheet">
<script src="<?php echo e(url('libs/bootstrap-timepicker/bootstrap-timepicker.min.js')); ?>"></script>
<script>
    $('.timepicker').timepicker({
        showMeridian: false,
        minuteStep: 30,
        defaultTime: '10:00',
        icons: {
            up: "mdi mdi-chevron-up",
            down: "mdi mdi-chevron-down"
        }
    });
</script>
<style>
  /*.datepicker-dropdown{*/
    /*z-index: 1001 !important;*/
  /*}*/
</style>