<?php

namespace App\Http\Controllers;

use App\Instrumen;
use App\Penempatan;
use App\Studio;
use Illuminate\Http\Request;

class StudioController extends Controller
{
  public function index()
  {
    $data = Studio::getData();

    return view('pages.studio.index')
      ->with('data', $data);
  }

  public function viewAdd()
  {
    $data_instrumen = Instrumen::getData();
    $data_penempatan = Penempatan::getData();

    return view('pages.studio.add')
      ->with('data_instrumen', $data_instrumen)
      ->with('data_penempatan', $data_penempatan);
  }

  public function viewEdit($id)
  {
    $info = Studio::getInfo($id);
    $data_instrumen = Instrumen::getData();
    $data_penempatan = Penempatan::getData();

    return view('pages.studio.edit')
      ->with('info', $info)
      ->with('data_instrumen', $data_instrumen)
      ->with('data_penempatan', $data_penempatan);
  }

  public function store(Request $req)
  {
    $this->validateData();

    Studio::insertData([
      'nama_studio' => $req->nama_studio,
      'id_penempatan' => $req->id_penempatan,
      'id_instrumen' => json_encode($req->id_instrumen)
    ]);

    return back()->with('success','Berhasil menyimpan data');
  }

  public function update(Request $req)
  {
    $this->validateData();

    Studio::updateData([
      'id_studio' => $req->id_studio,
      'nama_studio' => $req->nama_studio,
      'id_penempatan' => $req->id_penempatan,
      'id_instrumen' => json_encode($req->id_instrumen)
    ]);

    return back()->with('success','Berhasil menyimpan data');
  }

  private function validateData()
  {
    return request()->validate([
      'nama_studio' => 'required|max:40',
      'id_penempatan' => 'required',
      'id_instrumen' => 'required',
    ],[
      'nama_studio.required' => 'Nama Studio harus diisi!',
      'nama_studio.max' => 'Nama Studio maksimal :max karakter!',
      'id_penempatan.required' => 'Penempatan harus dipilih!',
      'id_instrumen.required' => 'Instrumen harus dipilih!',
    ]);
  }

  public function delete(Request $req)
  {
    Studio::deleteData($req->id);

    return back()->with('success','Berhasil menghapus data');
  }

  public static function implodeNamaStudio($id_studio)
  {
    $arr_id_studio = $id_studio != null ? json_decode($id_studio) : [];
    $nama_studio = [];

    foreach($arr_id_studio as $i){
      $temp = Studio::getNamaStudio($i);
      if($temp != null){
        $nama_studio[] = $temp;
      }
    }

    return implode(', ', $nama_studio);
  }
}
