@extends('layouts.main')

@section('title','Beranda')

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row justify-content-center">
            <div class="col-lg-12">
              <h4 class="page-title">Beranda</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row justify-content-center">
      <div class="col-lg-3">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-account-tie float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Instruktur</h6>
          <h3 class="my-3" data-plugin="counterup">{{ $data_jumlah['Jumlah Instruktur'] }}</h3>
          <span class="text-muted">Aktif saat ini</span>
        </div>
      </div>
      <div class="col-lg-3">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-school float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Siswa</h6>
          <h3 class="my-3" data-plugin="counterup">{{ $data_jumlah['Jumlah Siswa'] }}</h3>
          <span class="text-muted">Aktif saat ini</span>
        </div>
      </div>
      <div class="col-lg-3">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-guitar-acoustic float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Instrumen</h6>
          <h3 class="my-3" data-plugin="counterup">{{ $data_jumlah['Jumlah Instrumen'] }}</h3>
          <span class="text-muted">Saat ini</span>
        </div>
      </div>
      <div class="col-lg-3">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-account-music float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Kelas</h6>
          <h3 class="my-3" data-plugin="counterup">{{ $data_jumlah['Jumlah Kelas'] }}</h3>
          <span class="text-muted">Saat ini</span>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-office-building float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Studio</h6>
          <h3 class="my-3" data-plugin="counterup">{{ $data_jumlah['Jumlah Studio'] }}</h3>
          <span class="text-muted">Saat ini</span>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-map-marker float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Penempatan</h6>
          <h3 class="my-3" data-plugin="counterup">{{ $data_jumlah['Jumlah Penempatan'] }}</h3>
          <span class="text-muted">Saat ini</span>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-timer-sand float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Jadwal</h6>
          <h3 class="my-3" data-plugin="counterup">{{ $data_jumlah['Jumlah Jadwal Bulan Ini'] }}</h3>
          <span class="text-muted">Bulan {{ \App\Http\Controllers\HelperController::setNamaBulan($bulan) }}</span>
        </div>
      </div>
    </div>
    <h6>Penggajian Bulan {{ \App\Http\Controllers\HelperController::setNamaBulan($bulan) }}</h6>
    <div class="row">
      <div class="col-lg-4">
        <div class="card-box">
          <div class="row">
            <div class="col-3">
              <div class="avatar-sm bg-light rounded">
                <i class="mdi mdi-account-supervisor avatar-title font-22 text-success"></i>
              </div>
            </div>
            <div class="col-9">
              <div class="text-right">
                <h3 class="text-dark my-1">Rp<span data-plugin="counterup">{{ number_format($data_jumlah['Total Gaji Staff Bulan Ini'], 0,'.', ',') }}</span></h3>
                <h6 class="text-muted mb-1">Total Gaji Staff</h6>
              </div>
            </div>
          </div>
          <div class="mt-3">
            <p class="">Persentase <span class="float-right">{{ $data_jumlah['Persentase Gaji Staff'] }}%</span></p>
            <div class="progress progress-sm m-0">
              <div class="progress-bar bg-success" role="progressbar" aria-valuenow="{{ $data_jumlah['Persentase Gaji Staff'] }}" aria-valuemin="0" aria-valuemax="100" style="width: {{ $data_jumlah['Persentase Gaji Staff'] }}%">
                <span class="sr-only">{{ $data_jumlah['Persentase Gaji Staff'] }}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card-box">
          <div class="row">
            <div class="col-3">
              <div class="avatar-sm bg-light rounded">
                <i class="mdi mdi-account-tie avatar-title font-22 text-success"></i>
              </div>
            </div>
            <div class="col-9">
              <div class="text-right">
                <h3 class="text-dark my-1">Rp<span data-plugin="counterup">{{ number_format($data_jumlah['Total Gaji Instruktur Full Time Bulan Ini'], 0,'.', ',') }}</span></h3>
                <h6 class="text-muted mb-1">Total Gaji Instruktur Full Time</h6>
              </div>
            </div>
          </div>
          <div class="mt-3">
            <p class="">Persentase <span class="float-right">{{ $data_jumlah['Persentase Gaji Instruktur Full Time'] }}%</span></p>
            <div class="progress progress-sm m-0">
              <div class="progress-bar bg-success" role="progressbar" aria-valuenow="{{ $data_jumlah['Persentase Gaji Instruktur Full Time'] }}" aria-valuemin="0" aria-valuemax="100" style="width: {{ $data_jumlah['Persentase Gaji Instruktur Full Time'] }}%">
                <span class="sr-only">{{ $data_jumlah['Persentase Gaji Instruktur Full Time'] }}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card-box">
          <div class="row">
            <div class="col-3">
              <div class="avatar-sm bg-light rounded">
                <i class="mdi mdi-account-multiple avatar-title font-22 text-success"></i>
              </div>
            </div>
            <div class="col-9">
              <div class="text-right">
                <h3 class="text-dark my-1">Rp<span data-plugin="counterup">{{ number_format($data_jumlah['Total Gaji Instruktur Freelance Bulan Ini'], 0,'.', ',') }}</span></h3>
                <h6 class="text-muted mb-1">Total Gaji Instruktur Freelance</h6>
              </div>
            </div>
          </div>
          <div class="mt-3">
            <p class="">Persentase <span class="float-right">{{ $data_jumlah['Persentase Gaji Instruktur Freelance'] }}%</span></p>
            <div class="progress progress-sm m-0">
              <div class="progress-bar bg-success" role="progressbar" aria-valuenow="{{ $data_jumlah['Persentase Gaji Instruktur Freelance'] }}" aria-valuemin="0" aria-valuemax="100" style="width: {{ $data_jumlah['Persentase Gaji Instruktur Freelance'] }}%">
                <span class="sr-only">{{ $data_jumlah['Persentase Gaji Instruktur Freelance'] }}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
@endsection