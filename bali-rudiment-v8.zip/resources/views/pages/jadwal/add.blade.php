@extends('layouts.main')

@section('title','Input Data Jadwal')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="{{ url('jadwal') }}">Jadwal</a></li>
                  <li class="breadcrumb-item active">Input</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="{{ url('jadwal') }}">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input Jadwal
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="{{ url('jadwal') }}">
            @csrf
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_instruktur">Nama Instruktur</label>
                <div class="col-lg-9">
                  <select name="id_instruktur" id="id_instruktur" class="form-control select2" onchange="getItemInstrumen()">
                    <option value="">Pilih Instruktur</option>
                    @foreach($data_instruktur as $l)
                      <option value="{{ $l->id_instruktur }}" {{ old('id_instruktur') == $l->id_instruktur ? 'selected' : '' }}>{{ $l->nama_instruktur }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_instrumen">Instrumen</label>
                <div class="col-lg-9" id="col-instrumen">
                  @include('components.jadwal.select_instrumen')
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_studio">Studio</label>
                <div class="col-lg-9" id="col-studio">
                  @include('components.jadwal.select_studio')
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="bulan">Bulan</label>
                <div class="col-lg-9">
                  <input type="month" class="form-control" id="bulan" name="bulan" value="{{ old('bulan') }}">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="hari">Hari</label>
                <div class="col-lg-9">
                  <select name="hari" id="hari" class="form-control select2">
                    <option value="">Pilih Hari</option>
                    @foreach(\App\Jadwal::$hari as $hari)
                      <option value="{{ $hari }}" {{ old('hari') == $hari ? 'selected' : '' }}>{{ $hari }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="jam_mulai">Jam Mulai</label>
                <div class="col-lg-9">
                  <select name="jam_mulai" id="jam_mulai" class="form-control select2">
                    <option value="">Pilih Jam Mulai</option>
                    @foreach(\App\JadwalHarian::$jam_ke as $jam)
                      <option value="{{ $jam }}" {{ old('jam_mulai') == $jam ? 'selected' : '' }}>{{ $jam }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="jam_selesai">Jam Selesai</label>
                <div class="col-lg-9">
                  <select name="jam_selesai" id="jam_selesai" class="form-control select2">
                    <option value="">Pilih Jam Selesai</option>
                    @foreach(\App\JadwalHarian::$jam_selesai as $jam)
                      <option value="{{ $jam }}" {{ old('jam_selesai') == $jam ? 'selected' : '' }}>{{ $jam }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  @include('components.timepicker')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();

      setTimeout(getItemInstrumen, 500);

      function getItemInstrumen(){
          let id_instruktur = $("#id_instruktur").val();
          let id_instrumen = $("#id_instrumen").val();
          id_instrumen = id_instrumen ? id_instrumen : '{{ old('id_instrumen') }}';

          $.ajax({
              url: '{{ url('jadwal/add/component/get-instrumen') }}',
              type: 'get',
              data: {
                  id_instruktur: id_instruktur,
                  id_instrumen: id_instrumen
              },
              success: function(data) {
                  $("#col-instrumen").html(data);
                  $(".select2").select2();
                  getItemStudio()
              },
              error: async function(data) {
                  swal('Gagal','Terjadi kesalahan sistem','error');
              },
          });
      }

      function getItemStudio(){
          let id_instruktur = $("#id_instruktur").val();
          let id_studio = $("#id_studio").val();
          let id_instrumen = $("#id_instrumen").val();
          id_instrumen = id_instrumen ? id_instrumen : '{{ old('id_instrumen') }}';
          id_studio = id_studio ? id_studio : '{{ old('id_studio') }}';

          $.ajax({
              url: '{{ url('jadwal/add/component/get-studio') }}',
              type: 'get',
              data: {
                  id_instruktur: id_instruktur,
                  id_instrumen: id_instrumen,
                  id_studio: id_studio
              },
              success: function(data) {
                  $("#col-studio").html(data);
                  $(".select2").select2();
              },
              error: async function(data) {
                  swal('Gagal','Terjadi kesalahan sistem','error');
              },
          });

      }
  </script>
@endsection