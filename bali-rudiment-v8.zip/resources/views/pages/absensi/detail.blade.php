@extends('layouts.main')

@section('title','Detail Absensi')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="{{ url(request()->get('back_url') ?: 'absensi/instruktur') }}">Absensi</a></li>
                  <li class="breadcrumb-item active">Detail</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="{{ url(request()->get('back_url') ?: 'absensi/instruktur') }}">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Detail Absensi
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body pb-0">
            <div class="form-group row">
              <div class="col-lg-12">
                <label class="col-form-label" for="id_jadwal">Jadwal</label>
                <div class="card shadow-none mt-2 mb-0" style="background-color: rgba(0, 0, 0, 0.07)">
                  <div class="card-body">
                    <table class="table table-sm table-borderless mb-0">
                      <tr>
                        <td style="width: 100px">Hari</td>
                        <td class="px-0" style="width: 5px">:</td>
                        <td>{{ $info->jadwal->hari }}</td>
                      </tr>
                      <tr>
                        <td>Tanggal</td>
                        <td class="px-0">:</td>
                        <td>{{ \App\Http\Controllers\HelperController::setNamaBulan(null, $info->tanggal) }}</td>
                      </tr>
                      <tr>
                        <td>Jam</td>
                        <td class="px-0">:</td>
                        <td>{{ $info->jadwal->jam_mulai .'-'. $info->jadwal->jam_selesai }}</td>
                      </tr>
                      <tr>
                        <td>Studio</td>
                        <td class="px-0">:</td>
                        <td>{{ $info->jadwal->nama_studio }}</td>
                      </tr>
                      <tr>
                        <td>Instrumen</td>
                        <td class="px-0">:</td>
                        <td>{{ $info->jadwal->nama_instrumen }}</td>
                      </tr>
                      <tr>
                        <td>Instruktur</td>
                        <td class="px-0">:</td>
                        <td>{{ $info->jadwal->nama_instruktur }}</td>
                      </tr>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group row mb-2">
              <div class="col-lg-12">
                <table class="table table-sm table-borderless mb-0">
                  <tr>
                    <td class="pl-0" style="width: 100px">Status</td>
                    <td class="px-0" style="width: 5px">:</td>
                    <td>
                      <span class="badge badge-{{ \App\Absensi::$color[$info->status] }}" style="padding-top: 5px">{{ $info->status }}</span>
                    </td>
                  </tr>
                  <tr>
                    <td class="pl-0">Durasi</td>
                    <td class="px-0" style="width: 5px">:</td>
                    <td>{{ $info->durasi_mengajar }} Menit</td>
                  </tr>
                  @if($info->status == \App\Absensi::S_DIKONFIRMASI)
                    <tr>
                      <td class="pl-0">Fee</td>
                      <td class="px-0" style="width: 5px">:</td>
                      <td>Rp {{ number_format($info->fee, 0, ',', '.') }}</td>
                    </tr>
                  @endif
                </table>
              </div>
            </div>
            <div class="form-group row">
              <div class="col-lg-12">
                <label class="col-form-label" for="id_jadwal">Report</label>
                <p class="mb-0" style="white-space: pre-wrap">{{ $info->report }}</p>
              </div>
            </div>
            <div class="form-group row">
              <div class="col-lg-12">
                <table class="table table-sm table-bordered mb-0">
                  <thead>
                  <tr>
                    <th>Nama Siswa</th>
                    <th class="text-center">Kehadiran</th>
                    <th class="text-center">Fee</th>
                  </tr>
                  </thead>
                  <tbody>
                  @foreach($data_siswa as $d)
                    <tr>
                      <td><label class="form-check-label">{{ $d['siswa']['nama_siswa'] }}</label></td>
                      <td class="text-center">
                        <span class="badge badge-{{ \App\Absensi::$color[$d['kehadiran']] }}" style="padding-top: 5px">{{ $d['kehadiran'] }}</span>
                      </td>
                      <td class="text-center">{{ number_format($d['fee'], 0, ',', '.') }}</td>
                    </tr>
                  @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();
  </script>
@endsection