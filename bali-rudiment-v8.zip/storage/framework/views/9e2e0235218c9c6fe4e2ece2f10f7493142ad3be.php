<footer class="footer" style="left: 260px">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <?php echo e(date('Y')); ?> &copy; <strong>Bali Rudiment</strong>.
        
        
      </div>
    </div>
  </div>
</footer>