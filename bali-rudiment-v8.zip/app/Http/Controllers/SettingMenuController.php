<?php

namespace App\Http\Controllers;

use App\SettingMenu;
use App\User;
use Illuminate\Http\Request;

class SettingMenuController extends Controller
{
  public function index()
  {
    $data = [];
    foreach(User::$level_user as $level_user){
      $data[] = [
        'level_user' => $level_user,
        'aksi' => SettingMenu::getAksi($level_user)
      ];
    }
//    dd($data);

    return view('pages.setting_menu.index')
      ->with('data', $data);
  }

  public function updateStatus(Request $req)
  {
    SettingMenu::insertOrUpdate([
      'level_user' => $req->level_user,
      'aksi' => $req->aksi,
      'status' => $req->status
    ]);

    return response()->json('Berhasil update status', 200);
  }
}
