@extends('layouts.main')

@section('title','Data Absensi')

@php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_absensi_siswa);
  $nonaktif_input = in_array(\App\SettingMenu::INPUT_ABSENSI_SISWA, $arr_nonaktif);
  $nonaktif_edit = in_array(\App\SettingMenu::EDIT_ABSENSI_SISWA, $arr_nonaktif);
@endphp

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right mt-2 pt-1">
                @if(!$nonaktif_input)
                  <a href="{{ url('absensi/add') }}" class="btn btn-primary">
                    <i class="mdi mdi-plus mr-2"></i>Input Data Absensi
                  </a>
                @endif
              </div>
              <h4 class="page-title">Data Absensi</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <form class="form-horizontal" method="get">
              <div class="form-group row mb-0">
                <label class="col-lg-3 text-right col-form-label" for="bulan">Bulan</label>
                <div class="col-lg-9">
                  <select name="bulan" id="bulan" class="form-control select2" onchange="this.form.submit()">
                    <option value="">Pilih Bulan</option>
                    @foreach($data_bulan as $bln)
                      <option value="{{ $bln }}" {{ $bln == $bulan ? 'selected' : '' }}>{{ \App\Http\Controllers\HelperController::setNamaBulan($bln) }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <table class="table table-sm table-bordered mb-0">
                <thead>
                <tr>
                  <th>Hari, Tanggal</th>
                  <th class="text-center">Jam</th>
                  <th class="text-center">Durasi</th>
                  <th>Studio</th>
                  <th>Instrumen</th>
                  <th class="text-center">Fee</th>
                  <th class="text-center">Status</th>
                  <th class="text-center" style="width: 100px">Aksi</th>
                </tr>
                </thead>
                <tbody>
                @foreach($data as $index=>$d)
                  <tr>
                    <td>{{ $d->hari }}, {{ \App\Http\Controllers\HelperController::setNamaBulan(null, $d->tanggal) }}</td>
                    <td class="text-center">{{ $d->jadwal->jam_mulai .'-'. $d->jadwal->jam_selesai }}</td>
                    <td class="text-center">{{ $d->durasi_mengajar }} Menit</td>
                    <td>{{ $d->jadwal->nama_studio }}</td>
                    <td>{{ $d->jadwal->nama_instrumen }}</td>
                    @if($d->status == \App\Absensi::S_DIKONFIRMASI)
                      <td class="text-right">{{ number_format($d->fee, 0, ',', '.') }}</td>
                      <td class="text-center">
                        <span class="badge badge-{{ \App\Absensi::$color[$d->status] }}" style="padding-top: 5px">{{ $d->status }}</span>
                      </td>
                    @else
                      <td class="text-center" colspan="2">
                        <span class="badge badge-{{ \App\Absensi::$color[$d->status] }}" style="padding-top: 5px">{{ $d->status }}</span>
                      </td>
                    @endif
                    <td class="p-1">
                      <div class="btn-group btn-block">
                        <a href="{{ url('absensi/detail/'.$d->id_absensi.'?back_url='.\Illuminate\Support\Facades\Route::current()->uri) }}"
                           class="btn btn-sm btn-outline-primary">Detail</a>
                        @if(!$nonaktif_edit)
                          <a href="{{ url('absensi/edit/'.$d->id_absensi.'?back_url='.\Illuminate\Support\Facades\Route::current()->uri) }}"
                             class="btn btn-sm btn-primary">Edit</a>
                        @endif
                      </div>
                    </td>
                  </tr>
                @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
  </div>
@endsection
@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();
  </script>
@endsection