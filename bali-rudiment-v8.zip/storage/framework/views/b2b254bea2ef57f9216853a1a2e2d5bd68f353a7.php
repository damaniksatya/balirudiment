<?php $__env->startSection('title'); ?>
  Ubah Kata Sandi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="page-title-right">
            <ol class="breadcrumb m-0">
              
              
              
            </ol>
          </div>
          <h4 class="page-title">Ubah Kata Sandi</h4>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <form class="card-box" action="<?php echo e(url('password')); ?>" method="post">
          <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
          <div class="card-body p-0">
            <div class="row">
              <div class="col-lg-12">
                <div class="form-horizontal">
                  <div class="form-group row">
                    <label class="col-4 control-label mt-2 text-right">Kata Sandi Lama</label>
                    <div class="col-8">
                      <div class="input-group">
                        <input name="old_password" value="<?php echo e(old('old_password')); ?>" type="text" class="form-control"
                               placeholder="Masukkan Kata Sandi Lama" aria-label="Masukkan Kata Sandi Lama" required>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-4 control-label mt-2 text-right">Kata Sandi Baru</label>
                    <div class="col-8">
                      <div class="input-group">
                        <input name="new_password" value="<?php echo e(old('new_password')); ?>" type="text" class="form-control"
                               placeholder="Masukkan Kata Sandi Baru" aria-label="Masukkan Kata Sandi Baru" required>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label class="col-4 control-label mt-2 text-right">Kata Sandi Konfirmasi</label>
                    <div class="col-8">
                      <div class="input-group">
                        <input name="confirm_password" value="<?php echo e(old('confirm_password')); ?>" type="text" class="form-control"
                               placeholder="Masukkan Kembali Kata Sandi Baru" aria-label="Masukkan Kembali Kata Sandi Baru" required>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card-body p-0 text-right">
            <button type="submit" class="btn btn-primary">Simpan</button>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>