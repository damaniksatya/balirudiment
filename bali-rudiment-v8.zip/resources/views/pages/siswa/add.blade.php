@extends('layouts.main')

@section('title','Input Data Siswa')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/dropify/css/dropify.css') }}">
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="{{ url('siswa') }}">Siswa</a></li>
                  <li class="breadcrumb-item active">Input</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="{{ url('siswa') }}">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input Siswa
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="{{ url('siswa') }}" enctype="multipart/form-data">
            @csrf
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="nama_siswa">Nama</label>
                <div class="col-lg-9">
                  <input type="text" id="nama_siswa" name="nama_siswa" value="{{ old('nama_siswa') }}" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_penempatan">Penempatan</label>
                <div class="col-lg-9">
                  <select name="id_penempatan" id="id_penempatan" class="form-control select2">
                    <option value="">Pilih Penempatan</option>
                    @foreach($data_penempatan as $d)
                      <option value="{{ $d->id_penempatan }}" {{ old('id_penempatan') == $d->id_penempatan ? 'selected' : '' }}>{{ $d->nama_penempatan }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_kelas">Kelas</label>
                <div class="col-lg-9">
                  <select name="id_kelas" id="id_kelas" class="form-control select2">
                    <option value="">Pilih Kelas</option>
                    @foreach($data_kelas as $d)
                      <option value="{{ $d->id_kelas }}" {{ old('id_kelas') == $d->id_kelas ? 'selected' : '' }}>{{ $d->nama_kelas }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_instrumen">Instrumen</label>
                <div class="col-lg-9">
                  <select name="id_instrumen" id="id_instrumen" class="form-control select2">
                    <option value="">Pilih Instrumen</option>
                    @foreach($data_instrumen as $d)
                      <option value="{{ $d->id_instrumen }}" {{ old('id_instrumen') == $d->id_instrumen ? 'selected' : '' }}>{{ $d->nama_instrumen }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="email_siswa">Email Siswa</label>
                <div class="col-lg-9">
                  <input type="text" id="email_siswa" name="email_siswa" value="{{ old('email_siswa') }}" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="tanggal_lahir">Tanggal Lahir</label>
                <div class="col-lg-9">
                  <input type="text" id="tanggal_lahir" name="tanggal_lahir" value="{{ old('tanggal_lahir') }}" class="form-control datepicker" autocomplete="off" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="sekolah">Sekolah</label>
                <div class="col-lg-9">
                  <input type="text" id="sekolah" name="sekolah" value="{{ old('sekolah') }}" class="form-control">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="jenis_kelamin">Jenis Kelamin</label>
                <div class="col-lg-9">
                  <select name="jenis_kelamin" id="jenis_kelamin" class="form-control select2">
                    <option value="">Pilih Jenis Kelamin</option>
                    @foreach(\App\Siswa::$jenis_kelamin as $l)
                      <option value="{{ $l }}" {{ old('jenis_kelamin') == $l ? 'selected' : '' }}>{{ $l }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="alamat">Alamat</label>
                <div class="col-lg-9">
                  <textarea name="alamat" id="alamat" class="form-control" required rows="5">{{ old('alamat') }}</textarea>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="email_orangtua">Email Orang Tua</label>
                <div class="col-lg-9">
                  <input type="text" id="email_orangtua" name="email_orangtua" value="{{ old('email_orangtua') }}" class="form-control">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="no_hp_orangtua">No HP Orang Tua</label>
                <div class="col-lg-9">
                  <input type="text" id="no_hp_orangtua" name="no_hp_orangtua" value="{{ old('no_hp_orangtua') }}" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="tangan_dominan">Tangan Dominan</label>
                <div class="col-lg-9">
                  <select name="tangan_dominan" id="tangan_dominan" class="form-control select2">
                    <option value="">Pilih Tangan Dominan</option>
                    @foreach(\App\Siswa::$tangan_dominan as $l)
                      <option value="{{ $l }}" {{ old('tangan_dominan') == $l ? 'selected' : '' }}>{{ $l }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="username">Username Login</label>
                <div class="col-lg-9">
                  <input type="text" id="username" name="username" value="{{ old('username') }}" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="password">Password</label>
                <div class="col-lg-9">
                  <input type="password" id="password" name="password" class="form-control" autocomplete="off">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="foto_profile">Foto Profil</label>
                <div class="col-lg-9">
                  <input type="file"
                         name="foto_profile"
                         class="dropify dropify-photo"
                         data-height="150"
                         data-show-remove="false"
                         data-allowed-file-extensions="jpg jpeg png"
                         data-max-file-size="1M"
                         accept=".jpg, .jpeg, .png" />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="sosial-media">Sosial Media</label>
                <div class="col-lg-9">
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-20" id="instagram" style="padding: 2px 10px"><i class="mdi mdi-instagram"></i></span>
                    </div>
                    <input type="text" id="instagram" name="instagram" value="{{ old('instagram') }}" class="form-control" title="Instagram">
                  </div>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-20" id="twitter" style="padding: 2px 10px"><i class="mdi mdi-twitter"></i></span>
                    </div>
                    <input type="text" id="twitter" name="twitter" value="{{ old('twitter') }}" class="form-control" title="Twitter">
                  </div>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-20" id="facebook" style="padding: 2px 10px"><i class="mdi mdi-facebook"></i></span>
                    </div>
                    <input type="text" id="facebook" name="facebook" value="{{ old('facebook') }}" class="form-control" title="Facebook">
                  </div>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-20" id="youtube" style="padding: 2px 10px"><i class="mdi mdi-youtube"></i></span>
                    </div>
                    <input type="text" id="youtube" name="youtube" value="{{ old('youtube') }}" class="form-control" title="Youtube">
                  </div>
                </div>
              </div>

            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.datepicker')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/dropify/js/dropify.min.js') }}"></script>
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(document).ready(function(){
          $(".select2").select2();
          $('.dropify-photo').dropify({
              messages: {
                  'default': 'Drag & drop foto di sini atau klik',
                  'replace': 'Drag & drop atau klik untuk mengganti foto',
                  'error': 'Hanya format png/jpeg/jpg yang di izinkan'
              },
              error: {
                  'fileSize': 'Ukuran foto melebihi maksimal (1M max).',
              }
          });
      });
      function disableAutoComplete() {
          $("#username").val('');
          $("#password").val('');
      }

      setTimeout(disableAutoComplete, 500);
  </script>
@endsection