<?php

namespace App\Http\Controllers;

use App\Instruktur;
use App\Instrumen;
use App\Penempatan;
use App\Studio;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;

class InstrukturController extends Controller
{
  public function index()
  {
    $data = Instruktur::getData();

    return view('pages.instruktur.index')
      ->with('data', $data);
  }

  public function viewAdd()
  {
    $data_penempatan = Penempatan::getData();
    $data_studio = Studio::getData();
    $data_instrumen = Instrumen::getData();

    return view('pages.instruktur.add')
      ->with('data_penempatan', $data_penempatan)
      ->with('data_studio', $data_studio)
      ->with('data_instrumen', $data_instrumen);
  }

  public function viewEdit($id_pengguna)
  {
    $info = Instruktur::getInfo($id_pengguna);
    $data_penempatan = Penempatan::getData();
    $data_studio = Studio::getData();
    $data_instrumen = Instrumen::getData();

    return view('pages.instruktur.edit')
      ->with('info', $info)
      ->with('data_penempatan', $data_penempatan)
      ->with('data_studio', $data_studio)
      ->with('data_instrumen', $data_instrumen);
  }

  public function viewEditProfile()
  {
    $id_pengguna = Auth::user()->id;
    $info = Instruktur::getInfo($id_pengguna);

    return view('pages.instruktur.profile')
      ->with('info', $info);
  }

    public function store(Request $req)
  {
    $this->validateData();

    DB::transaction(function () use ($req){
      $id_pengguna = User::insertData([
        'nama' => $req->nama_instruktur,
        'username' => $req->username,
        'password' => bcrypt($req->password),
        'foto_profile' => $this->storeImageFile(),
        'level_user' => User::L_INSTRUKTUR,
        'status' => User::S_AKTIF
      ]);

      Instruktur::insertData([
        'id_pengguna' => $id_pengguna,
        'id_penempatan' => $req->id_penempatan,
        'id_studio' => json_encode($req->id_studio),
        'id_instrumen' => json_encode($req->id_instrumen),
        'nama_instruktur' => $req->nama_instruktur,
        'email_instruktur' => $req->email_instruktur,
        'no_hp' => $req->no_hp,
        'jenis_kelamin' => $req->jenis_kelamin,
        'jenis_instruktur' => $req->jenis_instruktur,
      ]);
    });

    return back()->with('success','Berhasil menyimpan data');
  }

  public function update(Request $req)
  {
    DB::transaction(function () use ($req){
      $new_username = $req->username != $req->username_old;
      $new_email = $req->email_instruktur != $req->email_instruktur_old;
      $new_password = $req->password != null;
      $this->validateData($new_username, $new_email, $new_password);

      $data_pengguna = [
        'id' => $req->id_pengguna,
        'nama' => $req->nama_instruktur,
        'username' => $req->username,
      ];
      if($new_password){
        $data_pengguna['password'] = bcrypt($req->password);
      }
      if(request()->file('foto_profile')){
        $data_pengguna['foto_profile'] = $this->storeImageFile();
        $this->deleteFile($req->foto_profile_old);
      }

      User::updateData($req->id_pengguna, $data_pengguna);

      Instruktur::updateData([
        'id_pengguna' => $req->id_pengguna,
        'id_penempatan' => $req->id_penempatan,
        'id_studio' => json_encode($req->id_studio),
        'id_instrumen' => json_encode($req->id_instrumen),
        'nama_instruktur' => $req->nama_instruktur,
        'email_instruktur' => $req->email_instruktur,
        'no_hp' => $req->no_hp,
        'jenis_kelamin' => $req->jenis_kelamin,
        'jenis_instruktur' => $req->jenis_instruktur,
      ]);
    });

    return redirect('instruktur')->with('success','Berhasil menyimpan data');
  }

  public function updateProfile(Request $req)
  {
    DB::transaction(function () use ($req){
      $new_username = $req->username != $req->username_old;
      $new_email = $req->email_instruktur != $req->email_instruktur_old;
      $this->validateData($new_username, $new_email, false);

      $data_pengguna = [
        'id' => $req->id_pengguna,
        'username' => $req->username,
      ];
      if(request()->file('foto_profile')){
        $data_pengguna['foto_profile'] = $this->storeImageFile();
        $this->deleteFile($req->foto_profile_old);
      }

      User::updateData($req->id_pengguna, $data_pengguna);

      Instruktur::updateData([
        'id_pengguna' => $req->id_pengguna,
        'email_instruktur' => $req->email_instruktur,
        'no_hp' => $req->no_hp,
      ]);
    });

    return back()->with('success','Berhasil menyimpan data');
  }

  public function updateStatus(Request $req)
  {
    User::updateData($req->id, [
      'status' => $req->status
    ]);

    return back()->with('success','Berhasil menyimpan data');
  }

  private function validateData($new_username = true, $new_email = true, $new_password = true)
  {
    return request()->validate([
      'nama_instruktur' => 'required|max:80',
      'email_instruktur' => 'required|email|max:80'.($new_email ? '|unique:instruktur' : ''),
      'no_hp' => 'required|max:20',
      'jenis_kelamin' => 'required',
      'jenis_instruktur' => 'required',
      'username' => 'required|max:30|min:3'.($new_username ? '|unique:pengguna' : ''),
      'password' => $new_password ? 'required|min:6' : '',
      'id_penempatan' => 'required',
      'id_studio' => 'required',
      'id_instrumen' => 'required',
    ],[
      'nama_instruktur.required' => 'Nama harus diisi!',
      'nama_instruktur.max' => 'Nama maksimal :max karakter!',
      'email_instruktur.required' => 'Email harus diisi!',
      'email_instruktur.max' => 'Email maksimal :max karakter!',
      'email_instruktur.unique' => 'Email telah digunakan!',
      'email_instruktur.email' => 'Email tidak valid!',
      'no_hp.required' => 'No HP harus diisi!',
      'no_hp.max' => 'No HP maksimal :max karakter!',
      'jenis_kelamin.required' => 'Jenis Kelamin harus diisi!',
      'jenis_instruktur.required' => 'Jenis Instruktur harus diisi!',
      'username.required' => 'Username harus diisi!',
      'username.max' => 'Username maksimal :max karakter!',
      'username.min' => 'Username minimal :max karakter!',
      'username.unique' => 'Username telah digunakan!',
      'password.required' => 'Kata Sandi harus diisi!',
      'password.min' => 'Kata Sandi minimal :min karakter!',
      'id_penempatan.required' => 'Penempatan harus dipilih!',
      'id_studio.required' => 'Studio harus dipilih!',
      'id_instrumen.required' => 'Instrumen harus dipilih!',
    ]);
  }

  private function storeImageFile($location = 'storage/foto_profile')
  {
    if(request()->file('foto_profile')){
      $file = request()->file('foto_profile');
      $ext = $file->getClientOriginalExtension();
      $name = time() .'.' . $ext;
      $file->move(public_path() . "/$location", $name);
      return $location.'/'.$name;
    }
    else{
      return null;
    }
  }

  private function deleteFile($nama)
  {
    File::delete("public/$nama");
  }
}
