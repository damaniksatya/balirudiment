<?php $__env->startSection('title','Input Data Slip Gaji Instruktur Freelance'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(url('slip-gaji/freelance')); ?>">Slip Gaji Instruktur Freelance</a></li>
                  <li class="breadcrumb-item active">Input</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="<?php echo e(url('slip-gaji/freelance')); ?>">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input Slip Gaji Instruktur Freelance
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <form class="form-horizontal" method="post" action="<?php echo e(url('slip-gaji/freelance')); ?>">
            <?php echo csrf_field(); ?>
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="bulan">Bulan</label>
                <div class="col-lg-9">
                  <input type="month" id="bulan" title="Bulan" name="bulan" oninput="getMengajarTable()"
                         value="<?php echo e(old('bulan') ?: '2022-12'); ?>" class="form-control" required>
                         
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_instruktur">Nama Instruktur</label>
                <div class="col-lg-9">
                  <select name="id_instruktur" id="id_instruktur" class="form-control select2" required onchange="getMengajarTable()">
                    <option value="">Pilih Instruktur</option>
                    <?php $__currentLoopData = $data_instruktur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($d->id_instruktur); ?>" <?php echo e(old('id_instruktur') == $d->id_instruktur ? 'selected' : ''); ?>><?php echo e($d->nama_instruktur); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="card-body py-0" id="card-body-mengajar"></div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <style>
    /* Chrome, Safari, Edge, Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }

    /* Firefox */
    input[type=number] {
      -moz-appearance: textfield;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();

      function getMengajarTable(){
          let bulan = $("[name=bulan]").val();
          let id_instruktur = $("[name=id_instruktur]").val();
          if(bulan && id_instruktur){
              $.ajax({
                  url: '<?php echo e(url('slip-gaji/freelance/add/component/mengajar')); ?>',
                  type: 'get',
                  data: {
                      bulan: bulan,
                      id_instruktur: id_instruktur,
                  },
                  success: function(data) {
                      $("#card-body-mengajar").html(data);
                      calculateTotal();
                  },
                  error: async function(data) {
                      swal('Gagal','Terjadi kesalahan sistem','error');
                  },
              });
          }
          else{
              $("#card-body-mengajar").html('');
          }
      }

      function calculateTotal() {
          let total_row = $("#total_row").val();
          let total_fee = 0;

          for(let i=0; i<total_row; i++){
              let temp_jumlah_pertemuan = getValue(`jumlah_pertemuan${i}`);
              let temp_fee = getValue(`fee${i}`);
              let temp_total_fee = temp_jumlah_pertemuan * temp_fee;

              $(`#total_fee_text${i}`).text(temp_total_fee ? formatNumber(temp_total_fee) : null);
              $(`#total_fee_hidden${i}`).val(temp_total_fee);
              total_fee += temp_total_fee;
          }

          $(`#total_fee_text`).text(total_fee ? formatNumber(total_fee) : null);
          $(`#total_fee_hidden`).val(total_fee);

          let ensemble_jml_hari = getValue('ensemble_jml_hari');
          let ensemble_per_hari = getValue('ensemble_per_hari');
          let trial_jml_hari = getValue('trial_jml_hari');
          let trial_per_hari = getValue('trial_per_hari');
          let extra_lesson_jml_hari = getValue('extra_lesson_jml_hari');
          let extra_lesson_per_hari = getValue('extra_lesson_per_hari');
          let kinerja_jml_hari = getValue('kinerja_jml_hari');
          let kinerja_per_hari = getValue('kinerja_per_hari');
          let week_20_hours_jml_hari = getValue('week_20_hours_jml_hari');
          let week_20_hours_per_hari = getValue('week_20_hours_per_hari');
          let konser_jml_hari = getValue('konser_jml_hari');
          let konser_per_hari = getValue('konser_per_hari');
          let set_up_konser_jml_hari = getValue('set_up_konser_jml_hari');
          let set_up_konser_per_hari = getValue('set_up_konser_per_hari');
          let set_down_konser_jml_hari = getValue('set_down_konser_jml_hari');
          let set_down_konser_per_hari = getValue('set_down_konser_per_hari');
          let set_up_bw_jml_hari = getValue('set_up_bw_jml_hari');
          let set_up_bw_per_hari = getValue('set_up_bw_per_hari');
          let set_down_bw_jml_hari = getValue('set_down_bw_jml_hari');
          let set_down_bw_per_hari = getValue('set_down_bw_per_hari');
          let kasbon = getValue('kasbon');

          let ensemble = ensemble_jml_hari * ensemble_per_hari;
          let trial = trial_jml_hari * trial_per_hari;
          let extra_lesson = extra_lesson_jml_hari * extra_lesson_per_hari;
          let kinerja = kinerja_jml_hari * kinerja_per_hari;
          let week_20_hours = week_20_hours_jml_hari * week_20_hours_per_hari;
          let konser = konser_jml_hari * konser_per_hari;
          let set_up_konser = set_up_konser_jml_hari * set_up_konser_per_hari;
          let set_down_konser = set_down_konser_jml_hari * set_down_konser_per_hari;
          let set_up_bw = set_up_bw_jml_hari * set_up_bw_per_hari;
          let set_down_bw = set_down_bw_jml_hari * set_down_bw_per_hari;

          let sub_total = total_fee + ensemble + trial + extra_lesson + kinerja + week_20_hours + konser + set_up_konser + set_down_konser + set_up_bw + set_down_bw;
          let grand_total = sub_total - kasbon;

          $("#ensemble_text").text(ensemble ? formatNumber(ensemble) : '');
          $("#ensemble_hidden").val(ensemble);
          $("#trial_text").text(trial ? formatNumber(trial) : '');
          $("#trial_hidden").val(trial);
          $("#extra_lesson_text").text(extra_lesson ? formatNumber(extra_lesson) : '');
          $("#extra_lesson_hidden").val(extra_lesson);
          $("#kinerja_text").text(kinerja ? formatNumber(kinerja) : '');
          $("#kinerja_hidden").val(kinerja);
          $("#week_20_hours_text").text(week_20_hours ? formatNumber(week_20_hours) : '');
          $("#week_20_hours_hidden").val(week_20_hours);
          $("#konser_text").text(konser ? formatNumber(konser) : '');
          $("#konser_hidden").val(konser);
          $("#set_up_konser_text").text(set_up_konser ? formatNumber(set_up_konser) : '');
          $("#set_up_konser_hidden").val(set_up_konser);
          $("#set_down_konser_text").text(set_down_konser ? formatNumber(set_down_konser) : '');
          $("#set_down_konser_hidden").val(set_down_konser);
          $("#set_up_bw_text").text(set_up_bw ? formatNumber(set_up_bw) : '');
          $("#set_up_bw_hidden").val(set_up_bw);
          $("#set_down_bw_text").text(set_down_bw ? formatNumber(set_down_bw) : '');
          $("#set_down_bw_hidden").val(set_down_bw);
          $("#sub_total_text").text(sub_total ? formatNumber(sub_total) : '');
          $("#sub_total_hidden").val(sub_total);
          $("#grand_total_text").text(grand_total ? formatNumber(grand_total) : '');
          $("#grand_total_hidden").val(grand_total);
      }
      function getValue(name) {
          let value = $(`[name=${name}]`).val();
          if(value && !isNaN(value*1)){
              return value*1;
          }
          else return 0;
      }
      function formatNumber(number, with_rp = false, fraction_digits = 0) {
          let text = (number).toLocaleString('id-ID', { minimumFractionDigits: fraction_digits });
          return (with_rp ? 'Rp ' : '') + text;
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>