<label class="col-lg-3 text-right col-form-label" for="id_jadwal_setelah">Pengubahan Jadwal</label>
<div class="col-lg-9">
  <select name="id_jadwal_setelah" id="id_jadwal_setelah" class="form-control select2">
    @if(count($pilihan_pengubahan_jadwal))
      <option value="">Pilih Jadwal</option>
      @foreach($pilihan_pengubahan_jadwal as $l)
        @foreach($l['arr_tgl'] as $tgl)
          @php $hari_tgl = $l->hari .', '. date('d-m-Y', strtotime($tgl)); @endphp
          @foreach($l['arr_waktu'] as $waktu)
            @php
              $value = "$l->id_jadwal--$tgl--$waktu";
            @endphp
            <option value="{{ $value }}" {{ old('id_jadwal_setelah') == $value ? 'selected' : '' }}>
              {{ $hari_tgl }}&nbsp; | &nbsp;{{ $waktu }}&nbsp; | &nbsp;{{ $l->nama_studio }}&nbsp; | &nbsp;{{ $l->nama_instrumen }}&nbsp; | &nbsp;{{ $l->nama_instruktur }}
            </option>
          @endforeach
        @endforeach
      @endforeach
    @else
      <option value="">Jadwal tidak tersedia!</option>
    @endif
  </select>
</div>