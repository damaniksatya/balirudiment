<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AbsensiSiswa extends Model
{
  protected $table = 'absensi_siswa';
  public $timestamps = false;

  public static function getData($id_absensi)
  {
    $get = self::where('id_absensi', $id_absensi)->get();
    foreach ($get as $index=>$g){
      $get[$index]['siswa'] = Siswa::getInfoByIdSiswa($g->id_siswa);
    }
    return $get;
  }

  public static function getJumlahTidakHadir($id_jadwal, $id_siswa)
  {
    return self::leftJoin('absensi as a','a.id_absensi','=','absensi_siswa.id_absensi')
      ->where('a.id_jadwal', $id_jadwal)
      ->where('absensi_siswa.id_siswa', $id_siswa)
      ->whereIn('absensi_siswa.kehadiran', Absensi::$arr_tidak_hadir)
      ->count();
  }

  public static function getTotalFee($id_jadwal, $id_siswa)
  {
    return self::leftJoin('absensi as a','a.id_absensi','=','absensi_siswa.id_absensi')
      ->where('a.id_jadwal', $id_jadwal)
      ->where('absensi_siswa.id_siswa', $id_siswa)
      ->where('absensi_siswa.kehadiran', Absensi::K_HADIR)
      ->sum('absensi_siswa.fee');
  }

  public static function isExists($data)
  {
    return self::where('id_absensi', $data['id_absensi'])
      ->where('id_siswa', $data['id_siswa'])
      ->exists();
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_absensi', $data['id_absensi'])
      ->where('id_siswa', $data['id_siswa'])
      ->update($data);
  }
}
