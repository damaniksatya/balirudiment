<?php

namespace App;

use App\Http\Controllers\InstrumenController;
use App\Http\Controllers\StudioController;
use Illuminate\Database\Eloquent\Model;

class Studio extends Model
{
  protected $table = 'studio';
  public $timestamps = false;

  const ST1_PENAMPARAN = 'ST1 PENAMPARAN';
  const ST2_PENAMPARAN = 'ST2 PENAMPARAN';
  const ST3_PENAMPARAN = 'ST3 PENAMPARAN';
  const ST4_PENAMPARAN = 'ST4 PENAMPARAN';
  const ST5_PENAMPARAN = 'ST5 PENAMPARAN';
  const ST6_PENAMPARAN = 'ST6 PENAMPARAN';
  const ST7_PENAMPARAN = 'ST7 PENAMPARAN';
  const ST8_PENAMPARAN = 'ST8 PENAMPARAN';
  const ST1_RENON = 'ST1 RENON';
  const ST2_RENON = 'ST2 RENON';
  const ST3_RENON = 'ST3 RENON';
  const ST4_RENON = 'ST4 RENON';
  const ST5_RENON = 'ST5 RENON';
  const ST1_JIMBARAN = 'ST1 JIMBARAN';
  const ST2_JIMBARAN = 'ST2 JIMBARAN';
  const ST3_JIMBARAN = 'ST3 JIMBARAN';
  const ST1_TABANAN = 'ST1 TABANAN';
  const ST2_TABANAN = 'ST2 TABANAN';
  const ST3_TABANAN = 'ST3 TABANAN';
  const ST4_TABANAN = 'ST4 TABANAN';
  
  public static $studio = [
    self::ST1_PENAMPARAN,
    self::ST2_PENAMPARAN,
    self::ST3_PENAMPARAN,
    self::ST4_PENAMPARAN,
    self::ST5_PENAMPARAN,
    self::ST6_PENAMPARAN,
    self::ST7_PENAMPARAN,
    self::ST8_PENAMPARAN,
    self::ST1_RENON,
    self::ST2_RENON,
    self::ST3_RENON,
    self::ST4_RENON,
    self::ST5_RENON,
    self::ST1_JIMBARAN,
    self::ST2_JIMBARAN,
    self::ST3_JIMBARAN,
    self::ST1_TABANAN,
    self::ST2_TABANAN,
    self::ST3_TABANAN,
    self::ST4_TABANAN,
  ];
  
  public static $studio_instrument = [
    self::ST1_PENAMPARAN => [
      Instrumen::DRUM
    ],
    self::ST2_PENAMPARAN => [
      Instrumen::DRUM
    ],
    self::ST3_PENAMPARAN => [
      Instrumen::PIANO, Instrumen::VOCAL, Instrumen::BIOLA
    ],
    self::ST4_PENAMPARAN => [
      Instrumen::DRUM
    ],
    self::ST5_PENAMPARAN => [
      Instrumen::DANCE, Instrumen::THEATRE, Instrumen::VOCAL, Instrumen::BIOLA
    ],
    self::ST6_PENAMPARAN => [
      Instrumen::GUITAR, Instrumen::BIOLA, Instrumen::VOCAL
    ],
    self::ST7_PENAMPARAN => [
      Instrumen::VLOG, Instrumen::MUSIC_PRODUCTION, Instrumen::BIOLA
    ],
    self::ST8_PENAMPARAN => [
      Instrumen::PIANO, Instrumen::VOCAL, Instrumen::GUITAR, Instrumen::BIOLA
    ],
    self::ST1_RENON => [
      Instrumen::DRUM
    ],
    self::ST2_RENON => [
      Instrumen::GUITAR
    ],
    self::ST3_RENON => [
      Instrumen::PIANO
    ],
    self::ST4_RENON => [
      Instrumen::DRUM
    ],
    self::ST5_RENON => [
      Instrumen::DRUM
    ],
    self::ST1_JIMBARAN => [
      Instrumen::PIANO, Instrumen::VOCAL
    ],
    self::ST2_JIMBARAN => [
      Instrumen::GUITAR
    ],
    self::ST3_JIMBARAN => [
      Instrumen::DRUM
    ],
    self::ST1_TABANAN => [
      Instrumen::PIANO
    ],
    self::ST2_TABANAN => [
      Instrumen::VOCAL
    ],
    self::ST3_TABANAN => [
      Instrumen::GUITAR
    ],
    self::ST4_TABANAN => [
      Instrumen::DRUM
    ],
  ];

  public static function getInfo($id)
  {
    $get = self::leftJoin('penempatan as p','p.id_penempatan','=','studio.id_penempatan')
      ->where('studio.id_studio', $id)
      ->first();

    if($get != null){
      $get->nama_instrumen = InstrumenController::implodeNamaInstrumen($get->id_instrumen);
    }

    return $get;
  }

  public static function getData()
  {
    $get = self::leftJoin('penempatan as p','p.id_penempatan','=','studio.id_penempatan')
      ->get();

    foreach($get as $index=>$g){
      $get[$index]->nama_instrumen = InstrumenController::implodeNamaInstrumen($g->id_instrumen);
    }
    return $get;
  }

  public static function getDataByPenempatanInstrumen($id_penempatan, $id_instrumen)
  {
    return self::where('id_penempatan', $id_penempatan)
      ->where('id_instrumen','like','%"'.$id_instrumen.'"%')
      ->get();
  }

  public static function getDataByArrId($arr_id)
  {
    return self::whereIn('id_studio', $arr_id)->get();
  }

  public static function getNoStudio($id_studio)
  {
    $get = self::where('id_studio', $id_studio)->first();
    if($get){
      $nama = explode('ST', $get->nama_studio);
      $nama = array_key_exists(1, $nama) ? explode(' ', $nama[1]) : [];
      return count($nama) ? $nama[0] : null;
    }
    else return null;
  }

  public static function getNamaStudio($id)
  {
    $get = self::where('id_studio', $id)->first();
    return $get ? $get->nama_studio : null;
  }

  public static function getJumlah()
  {
    return self::count();
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_studio', $data['id_studio'])->update($data);
  }

  public static function deleteData($id)
  {
    self::where('id_studio', $id)->delete();
  }
}
