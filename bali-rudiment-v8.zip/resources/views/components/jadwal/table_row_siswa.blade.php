<tr>
  @if($with_tgl)
    <td rowspan="{{ $tgl['total_siswa'] }}">{{ $tgl['hari'] .', '. \App\Http\Controllers\HelperController::setNamaBulan(null, $tgl['tanggal']) }}</td>
  @endif

  @if($with_jadwal)
    <td rowspan="{{ $jadwal['total_siswa'] }}" class="text-center">{{ $jadwal['jam_mulai'] .' - '. $jadwal['jam_selesai'] }}</td>
    <td rowspan="{{ $jadwal['total_siswa'] }}">{{ $jadwal['nama_studio'] }}</td>
    <td rowspan="{{ $jadwal['total_siswa'] }}" style="width: 150px">{{ $jadwal['nama_instrumen'] }}</td>
    <td rowspan="{{ $jadwal['total_siswa'] }}" style="width: 150px">{{ $jadwal['nama_instruktur'] }}</td>
  @endif

  <td>{{ $siswa['nama_siswa'] }}</td>
</tr>