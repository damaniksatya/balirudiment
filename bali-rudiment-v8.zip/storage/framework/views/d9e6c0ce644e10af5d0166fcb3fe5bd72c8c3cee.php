<?php $__env->startSection('title','Input/Edit Data Absensi'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(url('slip-gaji/staff')); ?>">Absensi</a></li>
                  <li class="breadcrumb-item active">Input/Edit</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="<?php echo e(url('slip-gaji/staff')); ?>">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input/Edit Absensi
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <form class="row" method="post" action="<?php echo e(url('slip-gaji/staff/absensi')); ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="id_gaji_staff" value="<?php echo e($info->id_gaji); ?>">
      <input type="hidden" name="arr_tgl" value="<?php echo e(json_encode($arr_tgl)); ?>">
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-6">
          <div class="card">
            <div class="card-body pb-0">
              <table class="mb-3">
                <tr>
                  <td>Nama</td>
                  <td class="text-center" style="width: 15px">:</td>
                  <td><?php echo e($info->nama_staff); ?></td>
                </tr>
                <tr>
                  <td>Jabatan</td>
                  <td class="text-center">:</td>
                  <td><?php echo e($info->jabatan); ?></td>
                </tr>
                <tr>
                  <td>Bulan</td>
                  <td class="text-center">:</td>
                  <td><?php echo e(\App\Http\Controllers\HelperController::setNamaBulan($bln)); ?></td>
                </tr>
              </table>
              <table class="table table-sm table-bordered">
                <thead>
                <tr>
                  <th class="text-center">Tanggal</th>
                  <th class="text-center">Masuk</th>
                  <th class="text-center">Keluar</th>
                  <th class="text-center">Lembur</th>
                  <th class="text-center">Off</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $d['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgl=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-center"><?php echo e($tgl); ?></td>
                    <?php
                      $is_off = $t['masuk'] == 'OFF' && $t['keluar'] == 'OFF' && $t['lembur'] == 'OFF';
                    ?>
                    <td colspan="3" id="td-off-<?php echo e($bln); ?>-<?php echo e($tgl); ?>" class="text-center bg-soft-danger" style="display: <?php echo e($is_off ? 'table-cell' : 'none'); ?>;">
                      <div style="padding: 3px">OFF</div>
                    </td>
                    <td class="p-1" id="td-masuk-<?php echo e($bln); ?>-<?php echo e($tgl); ?>" style="display: <?php echo e(!$is_off ? 'table-cell' : 'none'); ?>">
                      <input type="text" class="form-control form-control-sm"
                             value="<?php echo e($t['masuk']); ?>"
                             
                             title="Masuk Tanggal <?php echo e($tgl); ?>" name="masuk-<?php echo e($bln); ?>-<?php echo e($tgl); ?>">
                    </td>
                    <td class="p-1" id="td-keluar-<?php echo e($bln); ?>-<?php echo e($tgl); ?>" style="display: <?php echo e(!$is_off ? 'table-cell' : 'none'); ?>">
                      <input type="text" class="form-control form-control-sm"
                             value="<?php echo e($t['keluar']); ?>"
                             
                             title="Keluar Tanggal <?php echo e($tgl); ?>" name="keluar-<?php echo e($bln); ?>-<?php echo e($tgl); ?>">
                    </td>
                    <td class="p-1" id="td-lembur-<?php echo e($bln); ?>-<?php echo e($tgl); ?>" style="display: <?php echo e(!$is_off ? 'table-cell' : 'none'); ?>">
                      <input type="text" class="form-control form-control-sm" value="<?php echo e($t['lembur']); ?>"
                             title="Lembur Tanggal <?php echo e($tgl); ?>" name="lembur-<?php echo e($bln); ?>-<?php echo e($tgl); ?>">
                    </td>
                    <td class="text-center">
                      <div class="custom-control custom-checkbox" style="margin-left: 7px; cursor: pointer">
                        <input type="checkbox" class="custom-control-input" id="off-<?php echo e($bln); ?>-<?php echo e($tgl); ?>"
                               onchange="changeOff('<?php echo e($bln); ?>','<?php echo e($tgl); ?>', this.checked)" <?php echo e($is_off ? 'checked' : ''); ?>>
                        <label class="custom-control-label" style="cursor: pointer" for="off-<?php echo e($bln); ?>-<?php echo e($tgl); ?>"></label>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <div class="form-group">
                <label class="col-form-label" for="note">Note</label>
                <textarea name="note-<?php echo e($bln); ?>" id="note" class="form-control" rows="5"><?php echo e($d['note']); ?></textarea>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="col-lg-12 mb-3 mt-0">
        
          
            <button type="submit" class="btn btn-primary">Simpan</button>
          
        
      </div>
    </form>

  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();

      function changeOff(bln, tgl, is_checked) {
          $(`[name=masuk-${bln}-${tgl}]`).val(is_checked ? 'OFF' : null);
          $(`[name=keluar-${bln}-${tgl}]`).val(is_checked ? 'OFF' : null);
          $(`[name=lembur-${bln}-${tgl}]`).val(is_checked ? 'OFF' : null);

          if(is_checked){
              $(`#td-off-${bln}-${tgl}`).show();
              $(`#td-masuk-${bln}-${tgl}`).hide();
              $(`#td-keluar-${bln}-${tgl}`).hide();
              $(`#td-lembur-${bln}-${tgl}`).hide();
          }
          else{
              $(`#td-off-${bln}-${tgl}`).hide();
              $(`#td-masuk-${bln}-${tgl}`).show();
              $(`#td-keluar-${bln}-${tgl}`).show();
              $(`#td-lembur-${bln}-${tgl}`).show();
          }
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>