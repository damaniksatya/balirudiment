<?php $__env->startSection('title','Data Jadwal'); ?>

<?php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_jadwal_mengajar);
  $nonaktif_input = in_array(\App\SettingMenu::CREATE_JADWAL_MENGAJAR, $arr_nonaktif);
  $nonaktif_edit = in_array(\App\SettingMenu::UPDATE_JADWAL_MENGAJAR, $arr_nonaktif);
  $nonaktif_delete = in_array(\App\SettingMenu::DELETE_JADWAL_MENGAJAR, $arr_nonaktif);
  $nonaktif_edit_siswa = in_array(\App\SettingMenu::CREATE_UPDATE_SISWA_JADWAL_MENGAJAR, $arr_nonaktif);
?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right mt-2 pt-1">
                <?php if($nonaktif_input == false): ?>
                  <a href="<?php echo e(url('jadwal/add')); ?>" class="btn btn-primary">
                    <i class="mdi mdi-plus mr-2"></i>Input Data Jadwal
                  </a>
                <?php endif; ?>
              </div>
              <h4 class="page-title">Data Jadwal</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <form class="form-horizontal" method="get">
              <div class="form-group row mb-0">
                <label class="col-lg-3 text-right col-form-label" for="bulan">Bulan</label>
                <div class="col-lg-9">
                  <select name="bulan" id="bulan" class="form-control select2" onchange="this.form.submit()">
                    <option value="">Pilih Bulan</option>
                    <?php $__currentLoopData = $data_bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($bln); ?>" <?php echo e($bln == $bulan ? 'selected' : ''); ?>><?php echo e(\App\Http\Controllers\HelperController::setNamaBulan($bln)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instruktur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body pb-0">
              <h6 class="my-0"><?php echo e($instruktur['nama_instruktur']); ?></h6>
            </div>
            <div class="card-body">
              <table class="table table-sm table-bordered mb-0">
                <thead>
                <tr>
                  <th style="width: 70px">Hari</th>
                  <th style="width: 100px" class="text-center">Jam</th>
                  <th style="width: 170px">Nama Studio</th>
                  <?php if(!($nonaktif_edit && $nonaktif_delete)): ?>
                    <th colspan="2">Nama Instrumen</th>
                  <?php else: ?>
                    <th>Nama Instrumen</th>
                  <?php endif; ?>
                  <th>Siswa</th>
                </tr>
                </thead>
                <tbody>
                
                <?php $__currentLoopData = $instruktur['hari']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index_hari=>$hari): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $hari['jadwal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index_jadwal=>$jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php for($index_siswa=0; $index_siswa<count($jadwal['siswa'])+1; $index_siswa++): ?>

                      <?php
                        $first_index_jadwal = $index_jadwal == 0;
                        $first_index_siswa = $index_siswa == 0;

                        $with_hari = $first_index_jadwal && $first_index_siswa;
                        $with_jadwal = $first_index_siswa;
                      ?>

                      <?php echo $__env->make('components.jadwal.table_row_admin', ['with_hari' => $with_hari, 'with_jadwal' => $with_jadwal], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                      
                        
                          
                          
                        
                          
                          
                        
                      
                        
                          
                          
                        
                          
                          
                        
                      

                    <?php endfor; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

  <form action="<?php echo e(url('jadwal')); ?>" method="post" id="delete-form">
    <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
    <input type="hidden" name="id_jadwal" id="delete-id">
  </form>

  <div class="modal fade" id="modal-siswa" tabindex="-1" role="dialog" aria-labelledby="label">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="label">Pilih Siswa</h5>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body" id="modal-body-siswa">

        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="modal-jam" tabindex="-1" role="dialog" aria-labelledby="label">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="label">Edit Jam Mengajar Per Tanggal</h5>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body" id="modal-body-jam">

        </div>
      </div>
    </div>
  </div>

  <style>
    .table tr td{
      vertical-align: top !important;
    }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();

      function deleteData(id_jadwal) {
          swal({
              title: "Anda yakin?",
              text: "Data Jadwal yang akan dihapus, tidak bisa dikembalikan!",
              type: "warning",
              showCancelButton: true,
              confirmButtonColor: "#E62129",
              confirmButtonText: "Ya, hapus!",
              cancelButtonText: "Batalkan",
              closeOnConfirm: false
          }, function(){
              $("#delete-id").val(id_jadwal);
              $("#delete-form").submit();
          });
      }

      function openModalAddSiswa(id_jadwal) {
          $.ajax({
              url: '<?php echo e(url('jadwal/add-siswa/component/table-add')); ?>',
              type: 'get',
              data: {
                  id_jadwal: id_jadwal,
              },
              success: function(data) {
                  $("#modal-body-siswa").html(data);
                  $("#modal-siswa").modal('show');
              },
              error: async function(data) {
                  swal('Gagal','Terjadi kesalahan sistem','error');
              },
          });
      }

      function openModalEditJam(id_jadwal, id_siswa) {
          $.ajax({
              url: '<?php echo e(url('jadwal/add-siswa/component/edit-jam')); ?>',
              type: 'get',
              data: {
                  id_jadwal: id_jadwal,
                  id_siswa: id_siswa,
              },
              success: function(data) {
                  $("#modal-body-jam").html(data);
                  $("#modal-jam").modal('show');
              },
              error: async function(data) {
                  swal('Gagal','Terjadi kesalahan sistem','error');
              },
          });
      }

      function showJam(id_siswa) {
          let is_checked = $(`#id_siswa${id_siswa}`).is(":checked");
          if(is_checked){
              $(`#jam_siswa${id_siswa}`).show();
          }
          else{
              $(`#jam_siswa${id_siswa}`).hide();
          }
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>