<?php $__env->startSection('title','Data Jadwal'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              
                
                  
                
              
              <h4 class="page-title">Data Jadwal</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <form class="form-horizontal" method="get">
              <div class="form-group row mb-0">
                <label class="col-lg-3 text-right col-form-label" for="bulan">Bulan</label>
                <div class="col-lg-9">
                  <select name="bulan" id="bulan" class="form-control select2" onchange="this.form.submit()">
                    <option value="">Pilih Bulan</option>
                    <?php $__currentLoopData = $data_bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($bln); ?>" <?php echo e($bln == $bulan ? 'selected' : ''); ?>><?php echo e(\App\Http\Controllers\HelperController::setNamaBulan($bln)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <table class="table table-sm table-bordered mb-0">
                <thead>
                <tr>
                  <th>Hari, Tanggal</th>
                  <th class="text-center">Jam</th>
                  <th>Studio</th>
                  <th>Instrumen</th>
                  <th>Siswa</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$tgl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $tgl['jadwal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index_jadwal=>$jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $jadwal['siswa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index_siswa=>$siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <?php
                        $first_index_jadwal = $index_jadwal == 0;
                        $first_index_siswa = $index_siswa == 0;

                        $with_tgl = $first_index_jadwal && $first_index_siswa;
                        $with_jadwal = $first_index_siswa;
                      ?>

                      <?php echo $__env->make('components.jadwal.table_row_instruktur', ['with_tgl' => $with_tgl, 'with_jadwal' => $with_jadwal], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
  </div>

  <style>
    .table tr td{
      vertical-align: top !important;
    }
  </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>