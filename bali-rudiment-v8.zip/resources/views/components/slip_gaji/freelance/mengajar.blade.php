<table class="table table-sm table-bordered">
  <thead>
  <tr>
    <th class="text-center">No</th>
    <th>Nama Siswa</th>
    <th style="width: 80px" class="text-center">Jumlah Pertemuan</th>
    <th style="width: 100px" class="text-right">Fee</th>
    <th style="width: 100px" class="text-right">Total</th>
    <th>Kelas</th>
    <th>Notes</th>
  </tr>
  </thead>
  <tbody>
  @php
    $total_row = count($data) + \App\GajiFulltimeMengajar::ADDITION_ROW;
  @endphp
  @for($index=0; $index<$total_row; $index++)
    @php
      $exists = array_key_exists($index, $data);
      if($exists){
        $t = $data[$index];
      }
      else{
        $t = [
          'id' => null,
          'nama_siswa' => null,
          'jumlah_pertemuan' => null,
          'fee' => null,
          'total_fee' => null,
          'kelas' => null,
          'notes' => null,
        ];
      };
    @endphp
    <input type="hidden" name="id{{ $index }}" value="{{ $t['id'] }}">
    <tr>
      <td class="text-center">{{ $index+1 }}</td>
      <td class="p-1">
        <input type="text" class="form-control form-control-sm"
               value="{{ $t['nama_siswa'] }}"
               title="Masukkan Nama Siswa" name="nama_siswa{{ $index }}">
      </td>
      <td class="p-1">
        <input type="number" class="form-control form-control-sm text-center"
               value="{{ $t['jumlah_pertemuan'] }}" min="0" oninput="calculateTotal()"
               title="Masukkan Jumlah Pertemuan" name="jumlah_pertemuan{{ $index }}">
      </td>
      <td class="p-1">
        <input type="text" class="form-control form-control-sm text-right" min="0"
               value="{{ $t['fee'] }}" oninput="calculateTotal()"
               title="Masukkan Fee" name="fee{{ $index }}">
      </td>
      <td class="text-right">
        <span id="total_fee_text{{ $index }}">{{ $t['total_fee'] ? number_format($t['total_fee'], 0, ',', '.') : '' }}</span>
        <input type="hidden" value="{{ $t['total_fee'] }}" id="total_fee_hidden{{ $index }}" name="total_fee{{ $index }}">
      </td>
      <td class="p-1">
        <input type="text" class="form-control form-control-sm"
               value="{{ $t['kelas'] }}"
               title="Masukkan Jumlah Regular" name="kelas{{ $index }}">
      </td>
      <td class="p-1">
        <input type="text" class="form-control form-control-sm"
               value="{{ $t['notes'] }}"
               title="Notes" name="notes{{ $index }}">
      </td>
    </tr>
  @endfor
  @php $isset_info = isset($info); @endphp
  <tr>
    <td colspan="4" class="text-right font-weight-bold">TOTAL</td>
    <td class="text-right font-weight-bold border-right-0">
      <span id="total_fee_text"></span>
      <input type="hidden" id="total_fee_hidden" name="total_fee" value="{{ $isset_info ? $info->total_mengajar : null }}">
    </td>
    <td colspan="2" class="border-left-0"></td>
  </tr>
  <tr>
    <td colspan="2" class="text-center font-weight-bold">ENSEMBLE</td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-center"
             value="{{ $isset_info ? $info->ensemble_jml_hari : null }}" min="0" oninput="calculateTotal()"
             title="Masukkan Jumlah Ensemble" name="ensemble_jml_hari">
    </td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-right"
             value="{{ $isset_info ? $info->ensemble_per_hari : 50000 }}" min="0" oninput="calculateTotal()"
             title="Masukkan Fee Ensemble" name="ensemble_per_hari">
    </td>
    <td class="text-right">
      <span id="ensemble_text"></span>
      <input type="hidden" value="{{ $isset_info ? $info->ensemble : null }}" id="ensemble_hidden" name="ensemble">
    </td>
    <td colspan="2" class="p-1">
      <input type="text" class="form-control form-control-sm"
             value="{{ $isset_info ? $info->ensemble_note : null }}"
             title="Masukkan Note Ensemble" name="ensemble_note">
    </td>
  </tr>
  <tr>
    <td colspan="2" class="text-center font-weight-bold">TRIAL</td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-center"
             value="{{ $isset_info ? $info->trial_jml_hari : null }}" min="0" oninput="calculateTotal()"
             title="Masukkan Jumlah Trial" name="trial_jml_hari">
    </td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-right"
             value="{{ $isset_info ? $info->trial_per_hari : 25000 }}" min="0" oninput="calculateTotal()"
             title="Masukkan Fee Trial" name="trial_per_hari">
    </td>
    <td class="text-right">
      <span id="trial_text"></span>
      <input type="hidden" value="{{ $isset_info ? $info->trial : null }}" id="trial_hidden" name="trial">
    </td>
    <td colspan="2" class="p-1">
      <input type="text" class="form-control form-control-sm"
             value="{{ $isset_info ? $info->trial_note : null }}"
             title="Masukkan Note Trial" name="trial_note">
    </td>
  </tr>
  <tr>
    <td colspan="2" class="text-center font-weight-bold">EXTRA LESSON</td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-center"
             value="{{ $isset_info ? $info->extra_lesson_jml_hari : null }}" min="0" oninput="calculateTotal()"
             title="Masukkan Jumlah Extra Lesson" name="extra_lesson_jml_hari">
    </td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-right"
             value="{{ $isset_info ? $info->extra_lesson_per_hari : 25000 }}" min="0" oninput="calculateTotal()"
             title="Masukkan Fee Extra Lesson" name="extra_lesson_per_hari">
    </td>
    <td class="text-right">
      <span id="extra_lesson_text"></span>
      <input type="hidden" value="{{ $isset_info ? $info->extra_lesson : null }}" id="extra_lesson_hidden" name="extra_lesson">
    </td>
    <td colspan="2" class="p-1">
      <input type="text" class="form-control form-control-sm"
             value="{{ $isset_info ? $info->extra_lesson_note : null }}"
             title="Masukkan Note Extra Lesson" name="extra_lesson_note">
    </td>
  </tr>
  <tr>
    <td colspan="2" class="text-center font-weight-bold">BONUS</td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">Kinerja</td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-center"
             value="{{ $isset_info ? $info->kinerja_jml_hari : null }}" min="0" oninput="calculateTotal()"
             title="Masukkan Jumlah Kinerja" name="kinerja_jml_hari">
    </td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-right"
             value="{{ $isset_info ? $info->kinerja_per_hari : 500000 }}" min="0" oninput="calculateTotal()"
             title="Masukkan Fee Kinerja" name="kinerja_per_hari">
    </td>
    <td class="text-right">
      <span id="kinerja_text"></span>
      <input type="hidden" value="{{ $isset_info ? $info->kinerja : null }}" id="kinerja_hidden" name="kinerja">
    </td>
    <td colspan="2" class="p-1">
      <input type="text" class="form-control form-control-sm"
             value="{{ $isset_info ? $info->kinerja_note : null }}"
             title="Masukkan Note Kinerja" name="kinerja_note">
    </td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">20 Hours/week</td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-center"
             value="{{ $isset_info ? $info->week_20_hours_jml_hari : null }}" min="0" oninput="calculateTotal()"
             title="Masukkan Jumlah 20 Hours/week" name="week_20_hours_jml_hari">
    </td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-right"
             value="{{ $isset_info ? $info->week_20_hours_per_hari : null }}" min="0" oninput="calculateTotal()"
             title="Masukkan Fee 20 Hours/week" name="week_20_hours_per_hari">
    </td>
    <td class="text-right">
      <span id="week_20_hours_text"></span>
      <input type="hidden" value="{{ $isset_info ? $info->week_20_hours : null }}" id="week_20_hours_hidden" name="week_20_hours">
    </td>
    <td colspan="2" class="p-1">
      <input type="text" class="form-control form-control-sm"
             value="{{ $isset_info ? $info->week_20_hours_note : null }}"
             title="Masukkan Note 20 Hours/week" name="week_20_hours_note">
    </td>
  </tr>
  <tr>
    <td colspan="2" class="text-center font-weight-bold">EVENT</td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">Konser</td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-center"
             value="{{ $isset_info ? $info->konser_jml_hari : null }}" min="0" oninput="calculateTotal()"
             title="Masukkan Jumlah Konser" name="konser_jml_hari">
    </td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-right"
             value="{{ $isset_info ? $info->konser_per_hari : 100000 }}" min="0" oninput="calculateTotal()"
             title="Masukkan Fee Konser" name="konser_per_hari">
    </td>
    <td class="text-right">
      <span id="konser_text"></span>
      <input type="hidden" value="{{ $isset_info ? $info->konser : null }}" id="konser_hidden" name="konser">
    </td>
    <td colspan="2" class="p-1">
      <input type="text" class="form-control form-control-sm"
             value="{{ $isset_info ? $info->konser_note : null }}"
             title="Masukkan Note Konser" name="konser_note">
    </td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">Set Up Konser</td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-center"
             value="{{ $isset_info ? $info->set_up_konser_jml_hari : null }}" min="0" oninput="calculateTotal()"
             title="Masukkan Jumlah Set Up Konser" name="set_up_konser_jml_hari">
    </td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-right"
             value="{{ $isset_info ? $info->set_up_konser_per_hari : 125000 }}" min="0" oninput="calculateTotal()"
             title="Masukkan Fee Set Up Konser" name="set_up_konser_per_hari">
    </td>
    <td class="text-right">
      <span id="set_up_konser_text"></span>
      <input type="hidden" value="{{ $isset_info ? $info->set_up_konser : null }}" id="set_up_konser_hidden" name="set_up_konser">
    </td>
    <td colspan="2" class="p-1">
      <input type="text" class="form-control form-control-sm"
             value="{{ $isset_info ? $info->set_up_konser_note : null }}"
             title="Masukkan Note Set Up Konser" name="set_up_konser_note">
    </td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">Set Down Konser</td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-center"
             value="{{ $isset_info ? $info->set_down_konser_jml_hari : null }}" min="0" oninput="calculateTotal()"
             title="Masukkan Jumlah Set Down Konser" name="set_down_konser_jml_hari">
    </td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-right"
             value="{{ $isset_info ? $info->set_down_konser_per_hari : 125000 }}" min="0" oninput="calculateTotal()"
             title="Masukkan Fee Set Down Konser" name="set_down_konser_per_hari">
    </td>
    <td class="text-right">
      <span id="set_down_konser_text"></span>
      <input type="hidden" value="{{ $isset_info ? $info->set_down_konser : null }}" id="set_down_konser_hidden" name="set_down_konser">
    </td>
    <td colspan="2" class="p-1">
      <input type="text" class="form-control form-control-sm"
             value="{{ $isset_info ? $info->set_down_konser_note : null }}"
             title="Masukkan Note Set Down Konser" name="set_down_konser_note">
    </td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">Set Up BW / LIPPO</td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-center"
             value="{{ $isset_info ? $info->set_up_bw_jml_hari : null }}" min="0" oninput="calculateTotal()"
             title="Masukkan Jumlah Set Up BW / LIPPO" name="set_up_bw_jml_hari">
    </td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-right"
             value="{{ $isset_info ? $info->set_up_bw_per_hari : 125000 }}" min="0" oninput="calculateTotal()"
             title="Masukkan Fee Set Up BW / LIPPO" name="set_up_bw_per_hari">
    </td>
    <td class="text-right">
      <span id="set_up_bw_text"></span>
      <input type="hidden" value="{{ $isset_info ? $info->set_up_bw : null }}" id="set_up_bw_hidden" name="set_up_bw">
    </td>
    <td colspan="2" class="p-1">
      <input type="text" class="form-control form-control-sm"
             value="{{ $isset_info ? $info->set_up_bw_note : null }}"
             title="Masukkan Note Set Up BW / LIPPO" name="set_up_bw_note">
    </td>
  </tr>
  <tr>
    <td colspan="2" class="text-center">Set Down BW / LIPPO</td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-center"
             value="{{ $isset_info ? $info->set_down_bw_jml_hari : null }}" min="0" oninput="calculateTotal()"
             title="Masukkan Jumlah Set Down BW / LIPPO" name="set_down_bw_jml_hari">
    </td>
    <td class="p-1">
      <input type="number" class="form-control form-control-sm text-right"
             value="{{ $isset_info ? $info->set_down_bw_per_hari : 125000 }}" min="0" oninput="calculateTotal()"
             title="Masukkan Fee Set Down BW / LIPPO" name="set_down_bw_per_hari">
    </td>
    <td class="text-right">
      <span id="set_down_bw_text"></span>
      <input type="hidden" value="{{ $isset_info ? $info->set_down_bw : null }}" id="set_down_bw_hidden" name="set_down_bw">
    </td>
    <td colspan="2" class="p-1">
      <input type="text" class="form-control form-control-sm"
             value="{{ $isset_info ? $info->set_down_bw_note : null }}"
             title="Masukkan Note Set Down BW / LIPPO" name="set_down_bw_note">
    </td>
  </tr>
  <tr>
    <td colspan="4" class="text-right font-weight-bold">TOTAL</td>
    <td class="text-right font-weight-bold border-right-0">
      <span id="sub_total_text"></span>
      <input type="hidden" id="sub_total_hidden" name="sub_total" value="{{ $isset_info ? $info->total : null }}">
    </td>
    <td colspan="2" class="border-left-0"></td>
  </tr>
  <tr>
    <td colspan="4" class="text-right font-weight-bold">KASBON</td>
    <td class="text-right font-weight-bold">
      <input type="number" class="form-control form-control-sm text-right"
             value="{{ $isset_info ? $info->kasbon : null }}" min="0" oninput="calculateTotal()"
             title="Masukkan Kasbon" name="kasbon">
    </td>
    <td colspan="2" class=""></td>
  </tr>
  <tr>
    <td colspan="4" class="text-right font-weight-bold">GRAND TOTAL</td>
    <td class="text-right font-weight-bold border-right-0">
      <span id="grand_total_text"></span>
      <input type="hidden" id="grand_total_hidden" name="grand_total" value="{{ $isset_info ? $info->grand_total : null }}">
    </td>
    <td colspan="2" class="border-left-0"></td>
  </tr>
  </tbody>
</table>
<input type="hidden" id="total_row" name="total_row" value="{{ $total_row }}">
<div class="text-right mb-3">
  <button class="btn btn-primary" type="submit">Simpan</button>
</div>
