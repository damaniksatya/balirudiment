@extends('layouts.main')

@section('title','Data Jadwal')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              {{--<div class="page-title-right mt-2 pt-1">--}}
                {{--<a href="{{ url('jadwal/add') }}" class="btn btn-primary">--}}
                  {{--<i class="mdi mdi-plus mr-2"></i>Input Data Jadwal--}}
                {{--</a>--}}
              {{--</div>--}}
              <h4 class="page-title">Data Jadwal</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <form class="form-horizontal" method="get">
              <div class="form-group row mb-0">
                <label class="col-lg-3 text-right col-form-label" for="bulan">Bulan</label>
                <div class="col-lg-9">
                  <select name="bulan" id="bulan" class="form-control select2" onchange="this.form.submit()">
                    <option value="">Pilih Bulan</option>
                    @foreach($data_bulan as $bln)
                      <option value="{{ $bln }}" {{ $bln == $bulan ? 'selected' : '' }}>{{ \App\Http\Controllers\HelperController::setNamaBulan($bln) }}</option>
                    @endforeach
                  </select>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <table class="table table-sm table-bordered mb-0">
                <thead>
                <tr>
                  <th>Hari, Tanggal</th>
                  <th class="text-center">Jam</th>
                  <th>Studio</th>
                  <th>Instrumen</th>
                  <th>Instruktur</th>
                </tr>
                </thead>
                <tbody>
                @foreach($data as $index=>$d)
                  <tr>
                    <td>{{ $d->hari .', '. \App\Http\Controllers\HelperController::setNamaBulan(null, $d->tanggal) }}</td>
                    <td class="text-center">{{ $d->jam_mulai .'-'. $d->jam_selesai }}</td>
                    <td>{{ $d->studio->nama_studio }}</td>
                    <td>{{ $d->instrumen->nama_instrumen }}</td>
                    <td>{{ $d->instruktur->nama_instruktur }}</td>
                  </tr>
                @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
  </div>

  <style>
    .table tr td{
      vertical-align: top !important;
    }
  </style>
@endsection
@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();
  </script>
@endsection