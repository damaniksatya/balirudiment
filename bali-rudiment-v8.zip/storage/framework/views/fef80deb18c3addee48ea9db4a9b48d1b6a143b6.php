<select name="id_studio" id="id_studio" class="form-control select2" title="Studio">
  <?php if(isset($id_instruktur) && isset($id_instrumen)): ?>
    <option value="">Pilih Studio</option>
  <?php else: ?>
    <option value="">Pilih Instruktur & Instrumen terlebih dahulu</option>
  <?php endif; ?>
  <?php if(isset($data_studio)): ?>
    <?php $__currentLoopData = $data_studio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($l->id_studio); ?>" <?php echo e((isset($id_studio) ? $id_studio : null) == $l->id_studio ? 'selected' : ''); ?>><?php echo e($l->nama_studio); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
</select>