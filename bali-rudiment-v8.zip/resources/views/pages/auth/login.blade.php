@extends('layouts.auth')

@section('title','Bali Rudiment')

@section('content')
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-6 col-xl-5">
        <div class="account-card-box">
          <div class="card mb-0" style="border-color: #263238">
            <div class="card-body p-4">

              <div class="text-center">
                <div class="my-3">
                  <span><img src="{{ url('images/logo.jpg') }}" alt="Logo" width="120px" style="border-radius: 7px"></span>
                </div>
                <h5 class="py-3 font-16">Bali Rudiment</h5>
              </div>

              <form method="POST" action="{{ route('login') }}" class="mt-2">
                @csrf
                <div class="form-group mb-3">
                  <input type="text" id="username" name="username" value="{{ old('username') }}"
                         class="form-control" placeholder="Masukkan Username" required>
                </div>

                <div class="form-group mb-3">
                  <input type="password" id="password" name="password" value="{{ old('password') }}"
                         class="form-control" placeholder="Masukkan kata sandi" required>
                </div>

                <div class="form-group text-center mb-0">
                  <button class="btn btn-outline-primary btn-block waves-effect waves-light" type="submit"> Login </button>
                </div>
              </form>

            </div>
          </div>
        </div>
        <p class="text-center text-white mt-3">{{ date('Y') }} &copy; Bali Rudiment</p>
      </div>
    </div>
  </div>
@endsection
@section('script')
  @include('components.sweet_alert')
  <script>
      function disableAutoComplete() {
          $("#username").val('');
          $("#password").val('');
      }

      setTimeout(disableAutoComplete, 500);
  </script>
@endsection