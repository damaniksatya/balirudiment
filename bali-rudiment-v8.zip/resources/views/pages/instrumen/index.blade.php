@extends('layouts.main')

@section('title','Data Instrumen')

@php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_instrumen);
  $nonaktif_input = in_array(\App\SettingMenu::CREATE_INSTRUMEN, $arr_nonaktif);
  $nonaktif_edit = in_array(\App\SettingMenu::UPDATE_INSTRUMEN, $arr_nonaktif);
  $nonaktif_delete = in_array(\App\SettingMenu::DELETE_INSTRUMEN, $arr_nonaktif);
@endphp

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right mt-2 pt-1">
                @if($nonaktif_input == false)
                  <a href="{{ url('instrumen/add') }}" class="btn btn-primary">
                    <i class="mdi mdi-plus mr-2"></i>Input Data Instrumen
                  </a>
                @endif
              </div>
              <h4 class="page-title">Data Instrumen</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body">
            <div class="table-responsive">
              <table id="datatable" class="table mb-0 table-sm table-bordered">
                <thead>
                <tr>
                  <th class="text-center" style="width: 40px">No</th>
                  <th class="">Nama Instrumen</th>
                  @if(!($nonaktif_edit && $nonaktif_delete))
                    <th style="width: 80px" class="text">Aksi</th>
                  @endif
                </tr>
                </thead>
                <tbody>
                @foreach($data as $no=>$d)
                  <tr>
                    <td class="text-center">{{ $no+1 }}</td>
                    <td class="">{{ $d['nama_instrumen'] }}</td>
                    @if(!($nonaktif_edit && $nonaktif_delete))
                      <td>
                        <div class="btn-group btn-block">
                          @if(!$nonaktif_edit)
                            <a href="{{ url('instrumen/edit/'.$d['id_instrumen']) }}" class="btn btn-outline-primary btn-sm">Edit</a>
                          @endif

                          @if(!$nonaktif_delete)
                            <button id="delete-{{ $d['id_instrumen'] }}" type="button" class="btn btn-block btn-sm btn-outline-danger">Hapus</button>
                          @endif
                        </div>

                        <form id="form-delete{{ $d['id_instrumen'] }}" action="{{ url('instrumen') }}" method="post">
                          @csrf @method('delete')
                          <input type="hidden" name="id" value="{{ $d['id_instrumen'] }}">
                        </form>
                      </td>
                    @endif
                  </tr>
                @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection
@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script>
      @foreach($data as $d)
          $('#delete-{{ $d['id_instrumen'] }}').click(function(){
              swal({
                  title: "Anda yakin?",
                  text: "Data instrumen {{ $d['nama_instrumen'] }} yang akan dihapus, tidak bisa dikembalikan!",
                  type: "warning",
                  showCancelButton: true,
                  confirmButtonColor: "#E62129",
                  confirmButtonText: "Ya, hapus!",
                  cancelButtonText: "Batalkan",
                  closeOnConfirm: false
              }, function(){
                  $("#form-delete{{ $d['id_instrumen'] }}").submit();
              });
          });
      @endforeach
  </script>
@endsection