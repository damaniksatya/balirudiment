<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>@yield('title')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Bali Rudiment" name="description" />
    {{--<meta content="Bali Rudiment. Created with ♥ by " name="description" />--}}
    <meta content="LaraDev" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="icon" type="image/jpg" sizes="16x16" href="{{ url('images/logo.jpg') }}">
    <link href="{{ url('css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" id="bootstrap-stylesheet" />
    <link href="{{ url('css/icons.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ url('css/app.min.css') }}" rel="stylesheet" type="text/css"  id="app-stylesheet" />
</head>
<body class="authentication-bg" style="background-color: #263238">
<div class="account-pages pt-5 my-5">@yield('content')</div>

<script src="{{ url('js/vendor.min.js') }}"></script>
<script src="{{ url('js/app.min.js') }}"></script>
@yield('script')
</body>
</html>