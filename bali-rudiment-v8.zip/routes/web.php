<?php

Route::get('/','Auth\LoginController@showLoginForm')->name('login');
Route::get('login','Auth\LoginController@showLoginForm')->name('login');
Route::post('login','Auth\LoginController@login');
Route::post('logout','Auth\LoginController@logout')->name('logout');

Route::middleware(['auth'])->group(function () {
  Route::get('/home', 'HomeController@index')->name('home');

  Route::get('admin','AdminController@index');
  Route::get('admin/profile','AdminController@viewEditProfile');
  Route::get('admin/add','AdminController@viewAdd');
  Route::get('admin/edit/{id}','AdminController@viewEdit');
  Route::post('admin','AdminController@store');
  Route::put('admin','AdminController@update');
  Route::put('admin/status','AdminController@updateStatus');
  Route::put('admin/profile','AdminController@updateProfile');

  Route::get('accounting','AccountingController@index');
  Route::get('accounting/profile','AccountingController@viewEditProfile');
  Route::get('accounting/add','AccountingController@viewAdd');
  Route::get('accounting/edit/{id}','AccountingController@viewEdit');
  Route::post('accounting','AccountingController@store');
  Route::put('accounting','AccountingController@update');
  Route::put('accounting/status','AccountingController@updateStatus');
  Route::put('accounting/profile','AccountingController@updateProfile');

  Route::get('instruktur','InstrukturController@index');
  Route::get('instruktur/profile','InstrukturController@viewEditProfile');
  Route::get('instruktur/add','InstrukturController@viewAdd');
  Route::get('instruktur/edit/{id}','InstrukturController@viewEdit');
  Route::post('instruktur','InstrukturController@store');
  Route::put('instruktur','InstrukturController@update');
  Route::put('instruktur/status','InstrukturController@updateStatus');
  Route::put('instruktur/profile','InstrukturController@updateProfile');

  Route::get('siswa','SiswaController@index');
  Route::get('siswa/profile','SiswaController@viewEditProfile');
  Route::get('siswa/add','SiswaController@viewAdd');
  Route::get('siswa/edit/{id}','SiswaController@viewEdit');
  Route::post('siswa','SiswaController@store');
  Route::put('siswa','SiswaController@update');
  Route::put('siswa/status','SiswaController@updateStatus');
  Route::put('siswa/profile','SiswaController@updateProfile');

  Route::get('instrumen','InstrumenController@index');
  Route::get('instrumen/add','InstrumenController@viewAdd');
  Route::get('instrumen/edit/{id}','InstrumenController@viewEdit');
  Route::post('instrumen','InstrumenController@store');
  Route::put('instrumen','InstrumenController@update');
  Route::delete('instrumen','InstrumenController@delete');

  Route::get('kelas','KelasController@index');
  Route::get('kelas/add','KelasController@viewAdd');
  Route::get('kelas/edit/{id}','KelasController@viewEdit');
  Route::post('kelas','KelasController@store');
  Route::put('kelas','KelasController@update');
  Route::delete('kelas','KelasController@delete');

  Route::get('penempatan','PenempatanController@index');
  Route::get('penempatan/add','PenempatanController@viewAdd');
  Route::get('penempatan/edit/{id}','PenempatanController@viewEdit');
  Route::post('penempatan','PenempatanController@store');
  Route::put('penempatan','PenempatanController@update');
  Route::delete('penempatan','PenempatanController@delete');

  Route::get('studio','StudioController@index');
  Route::get('studio/add','StudioController@viewAdd');
  Route::get('studio/edit/{id}','StudioController@viewEdit');
  Route::post('studio','StudioController@store');
  Route::put('studio','StudioController@update');
  Route::delete('studio','StudioController@delete');

  Route::get('jadwal','JadwalController@index');
  Route::get('jadwal/instruktur','JadwalController@indexInstruktur');
  Route::get('jadwal/siswa','JadwalController@indexSiswa');
  Route::get('jadwal/add','JadwalController@viewAdd');
  Route::get('jadwal/add/component/get-studio','JadwalController@getComponentSelectStudio');
  Route::get('jadwal/add/component/get-instrumen','JadwalController@getComponentSelectInstrumen');
  Route::get('jadwal/edit/{id_jadwal}','JadwalController@viewEdit');
  Route::get('jadwal/add-siswa/component/table-add','JadwalController@getComponentTableAddSiswa');
  Route::get('jadwal/add-siswa/component/edit-jam','JadwalController@getComponentModalEditJam');
  Route::post('jadwal','JadwalController@store');
  Route::post('jadwal/add-siswa','JadwalController@storeAddSiswa');
  Route::put('jadwal','JadwalController@update');
  Route::put('jadwal/jam-mengajar','JadwalController@updateJamMengajar');
  Route::delete('jadwal','JadwalController@delete');

  Route::get('jadwal-harian','JadwalHarianController@index');
  Route::get('jadwal-harian/instruktur','JadwalHarianController@indexInstruktur');
  Route::get('jadwal-harian/print','JadwalHarianController@printJadwal');
  Route::post('jadwal-harian','JadwalHarianController@store');
  Route::delete('jadwal-harian/reset','JadwalHarianController@resetJadwal');

  Route::get('pengubahan-jadwal/siswa','JadwalPengubahanController@indexSiswa');
  Route::get('pengubahan-jadwal/menunggu-konfirmasi','JadwalPengubahanController@indexMenungguKonfirmasi');
  Route::get('pengubahan-jadwal/dikonfirmasi','JadwalPengubahanController@indexDikonfirmasi');
  Route::get('pengubahan-jadwal/component/select-pengubahan','JadwalPengubahanController@getComponentPengubahan');
  Route::post('pengubahan-jadwal/siswa','JadwalPengubahanController@store');
  Route::put('pengubahan-jadwal/tolak','JadwalPengubahanController@tolak');
  Route::put('pengubahan-jadwal/konfirmasi','JadwalPengubahanController@konfirmasi');

  Route::get('absensi/instruktur','AbsensiController@indexInstruktur');
  Route::get('absensi/siswa','AbsensiController@indexSiswa');
  Route::get('absensi/menunggu-konfirmasi','AbsensiController@indexMenungguKonfirmasi');
  Route::get('absensi/menunggu-konfirmasi/component/form-konfirmasi','AbsensiController@getComponentFormKonfirmasi');
  Route::get('absensi/dikonfirmasi','AbsensiController@indexDikonfirmasi');
  Route::get('absensi/add','AbsensiController@viewAdd');
  Route::get('absensi/add/component/get-siswa','AbsensiController@getComponentTableSiswa');
  Route::get('absensi/edit/{id_absensi}','AbsensiController@viewEdit');
  Route::get('absensi/detail/{id_absensi}','AbsensiController@viewDetail');
  Route::post('absensi','AbsensiController@store');
  Route::put('absensi','AbsensiController@update');
  Route::put('absensi/konfirmasi','AbsensiController@konfirmasi');

  Route::get('slip-gaji/staff','SlipGajiStaffController@index');
  Route::get('slip-gaji/staff/add','SlipGajiStaffController@viewAdd');
  Route::get('slip-gaji/staff/edit/{id_gaji}','SlipGajiStaffController@viewEdit');
  Route::get('slip-gaji/staff/absensi/{id_gaji}','SlipGajiStaffController@viewEditAbsensi');
  Route::get('slip-gaji/staff/print/{id_gaji}','SlipGajiStaffController@printSlipGaji');
  Route::post('slip-gaji/staff','SlipGajiStaffController@store');
  Route::post('slip-gaji/staff/absensi','SlipGajiStaffController@storeAbsensi');
  Route::put('slip-gaji/staff','SlipGajiStaffController@update');
  Route::delete('slip-gaji/staff','SlipGajiStaffController@delete');

  Route::get('slip-gaji/fulltime','SlipGajiFulltimeController@index');
  Route::get('slip-gaji/fulltime/add','SlipGajiFulltimeController@viewAdd');
  Route::get('slip-gaji/fulltime/edit/{id_gaji}','SlipGajiFulltimeController@viewEdit');
  Route::get('slip-gaji/fulltime/mengajar/{id_gaji}','SlipGajiFulltimeController@viewEditMengajar');
  Route::get('slip-gaji/fulltime/absensi/{id_gaji}','SlipGajiFulltimeController@viewEditAbsensi');
  Route::get('slip-gaji/fulltime/print/{id_gaji}','SlipGajiFulltimeController@printSlipGaji');
  Route::post('slip-gaji/fulltime','SlipGajiFulltimeController@store');
  Route::post('slip-gaji/fulltime/mengajar','SlipGajiFulltimeController@storeMengajar');
  Route::post('slip-gaji/fulltime/absensi','SlipGajiFulltimeController@storeAbsensi');
  Route::put('slip-gaji/fulltime','SlipGajiFulltimeController@update');
  Route::delete('slip-gaji/fulltime','SlipGajiFulltimeController@delete');

  Route::get('slip-gaji/freelance','SlipGajiFreelanceController@index');
  Route::get('slip-gaji/freelance/add','SlipGajiFreelanceController@viewAdd');
  Route::get('slip-gaji/freelance/edit/{id_gaji}','SlipGajiFreelanceController@viewEdit');
  Route::get('slip-gaji/freelance/add/component/mengajar','SlipGajiFreelanceController@getComponentMengajar');
  Route::get('slip-gaji/freelance/absensi/{id_gaji}','SlipGajiFreelanceController@viewEditAbsensi');
  Route::get('slip-gaji/freelance/print/{id_gaji}','SlipGajiFreelanceController@printSlipGaji');
  Route::post('slip-gaji/freelance','SlipGajiFreelanceController@store');
  Route::post('slip-gaji/freelance/absensi','SlipGajiFreelanceController@storeAbsensi');
  Route::put('slip-gaji/freelance','SlipGajiFreelanceController@update');
  Route::delete('slip-gaji/freelance','SlipGajiFreelanceController@delete');

  Route::get('password','PasswordController@index');
  Route::put('password','PasswordController@update');

  Route::get('setting-menu','SettingMenuController@index');
  Route::put('setting-menu/status','SettingMenuController@updateStatus');
});