<?php

namespace App\Http\Controllers;

use App\GajiFreelance;
use App\GajiFulltime;
use App\GajiStaff;
use App\Instruktur;
use App\Instrumen;
use App\Jadwal;
use App\Kelas;
use App\Penempatan;
use App\Siswa;
use App\Studio;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
  public function index()
  {
    if(Auth::user()->level_user == User::L_GENERAL_ADMIN){
      $bulan = date('Y-m');
      $data_jumlah = $this->getDataJumlah($bulan);
//      dd($data_jumlah, $bulan);
      return view('pages.beranda.index_general_admin')
        ->with('data_jumlah', $data_jumlah)
        ->with('bulan', $bulan);
    }
    elseif(Auth::user()->level_user == User::L_ADMIN){
      $bulan = date('Y-m');
      $data_jumlah = $this->getDataJumlah($bulan);

      return view('pages.beranda.index_admin')
        ->with('data_jumlah', $data_jumlah)
        ->with('bulan', $bulan);
    }
    else{
      return view('pages.beranda.index');
    }
  }

  private function getDataJumlah($bulan)
  {
    $data = [
      'Jumlah Instruktur' => Instruktur::getJumlahAktif(),
      'Jumlah Siswa' => Siswa::getJumlahAktif(),
      'Jumlah Instrumen' => Instrumen::getJumlah(),
      'Jumlah Kelas' => Kelas::getJumlah(),
      'Jumlah Studio' => Studio::getJumlah(),
      'Jumlah Penempatan' => Penempatan::getJumlah(),
      'Jumlah Jadwal Bulan Ini' => Jadwal::getJumlahByBulan($bulan),
      'Total Gaji Staff Bulan Ini' => GajiStaff::getTotalByBulan($bulan),
      'Total Gaji Instruktur Full Time Bulan Ini' => GajiFulltime::getTotalByBulan($bulan),
      'Total Gaji Instruktur Freelance Bulan Ini' => GajiFreelance::getTotalByBulan($bulan),
    ];

    $total_gaji = $data['Total Gaji Staff Bulan Ini'] + $data['Total Gaji Instruktur Full Time Bulan Ini'] + $data['Total Gaji Instruktur Freelance Bulan Ini'];

    $not_null = $data['Total Gaji Staff Bulan Ini'] != null && $total_gaji != null;
    $data['Persentase Gaji Staff'] = $not_null ? round(($data['Total Gaji Staff Bulan Ini']/$total_gaji) * 100, 2) : 0;

    $not_null = $data['Total Gaji Instruktur Full Time Bulan Ini'] != null && $total_gaji != null;
    $data['Persentase Gaji Instruktur Full Time'] = $not_null ? round(($data['Total Gaji Instruktur Full Time Bulan Ini']/$total_gaji) * 100, 2) : 0;

    $not_null = $data['Total Gaji Instruktur Freelance Bulan Ini'] != null && $total_gaji != null;
    $data['Persentase Gaji Instruktur Freelance'] = $not_null ? round(($data['Total Gaji Instruktur Freelance Bulan Ini']/$total_gaji) * 100, 2) : 0;

    return $data;
  }
}
