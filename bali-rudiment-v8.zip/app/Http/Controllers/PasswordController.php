<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class PasswordController extends Controller
{
  public function index()
  {
    return view('pages.auth.password');
  }

  public function update(Request $req)
  {
    $id_user = Auth::user()->id;
    $get_password = User::where('id', $id_user)->first()['password'];
    $old_password_is_valid = Hash::check($req->old_password, $get_password);
    $new_password_is_match = $req->new_password == $req->confirm_password;
    $new_password_is_valid = $req->new_password != $req->old_password;
    $password_length_is_valid = strlen($req->new_password) >= 4;
    $error_msg = [];

    if($old_password_is_valid == false)
      $error_msg[] = 'Kata sandi lama tidak valid!';
    if($new_password_is_match == false)
      $error_msg[] = 'Kata sandi baru harus sama dengan konfirmasi kata sandi!';
    if($new_password_is_valid == false)
      $error_msg[] = 'Kata sandi baru tidak boleh sama dengan kata sandi lama!';
    if($password_length_is_valid == false)
      $error_msg[] = 'Kata sandi baru minimal 4 karakter!';
    if(count($error_msg)) return back()->withErrors($error_msg)->withInput();

    User::where('id', $id_user)->update([
      'password' => bcrypt($req->new_password)
    ]);

    return back()->with('success','Berhasil menyimpan kata sandi');
  }
}
