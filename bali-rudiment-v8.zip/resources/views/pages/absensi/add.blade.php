@extends('layouts.main')

@section('title','Input Data Absensi')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="{{ url('absensi/instruktur') }}">Absensi</a></li>
                  <li class="breadcrumb-item active">Input</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="{{ url('absensi/instruktur') }}">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input Absensi
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="{{ url('absensi') }}">
            @csrf
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_jadwal">Jadwal</label>
                <div class="col-lg-9">
                  <select name="id_jadwal" id="id_jadwal" class="form-control select2" onchange="getTableSiswa()" required>
                    @if(count($data_jadwal))
                      <option value="">Pilih Jadwal</option>
                      @foreach($data_jadwal as $l)
                        <option value="{{ $l->id_jadwal }}--{{ $l->tanggal }}" {{ old('id_jadwal_sebelum') == $l->id_jadwal .'--'. $l->tanggal ? 'selected' : '' }}>
                          {{ $l->hari .', '. date('d-m-Y', strtotime($l->tanggal)) }}&nbsp; | &nbsp;{{ $l->jam_mulai .'-'. $l->jam_selesai }}&nbsp; | &nbsp;{{ $l->nama_studio }}&nbsp; | &nbsp;{{ $l->nama_instrumen }}
                        </option>
                      @endforeach
                    @else
                      <option value="">Jadwal tidak tersedia!</option>
                    @endif
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="report">Report</label>
                <div class="col-lg-9">
                  <textarea id="report" name="report" class="form-control" rows="10" required>{{ old('report') }}</textarea>
                </div>
              </div>
              <div id="col-siswa"></div>
            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();

      // setTimeout(getItemInstrumen, 500);

      function getTableSiswa(){
          let id_jadwal = $("#id_jadwal").val();
          id_jadwal = id_jadwal ? id_jadwal : '{{ old('id_jadwal') }}';

          $.ajax({
              url: '{{ url('absensi/add/component/get-siswa') }}',
              type: 'get',
              data: {
                  id_jadwal: id_jadwal,
              },
              success: function(data) {
                  $("#col-siswa").html(data);
              },
              error: async function(data) {
                  swal('Gagal','Terjadi kesalahan sistem','error');
              },
          });
      }


  </script>
@endsection