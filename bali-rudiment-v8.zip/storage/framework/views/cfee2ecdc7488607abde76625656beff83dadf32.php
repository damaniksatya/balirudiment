<label class="col-lg-3 text-right col-form-label" for="id_jadwal_setelah">Pengubahan Jadwal</label>
<div class="col-lg-9">
  <select name="id_jadwal_setelah" id="id_jadwal_setelah" class="form-control select2">
    <?php if(count($pilihan_pengubahan_jadwal)): ?>
      <option value="">Pilih Jadwal</option>
      <?php $__currentLoopData = $pilihan_pengubahan_jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $l['arr_tgl']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $hari_tgl = $l->hari .', '. date('d-m-Y', strtotime($tgl)); ?>
          <?php $__currentLoopData = $l['arr_waktu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $waktu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $value = "$l->id_jadwal--$tgl--$waktu";
            ?>
            <option value="<?php echo e($value); ?>" <?php echo e(old('id_jadwal_setelah') == $value ? 'selected' : ''); ?>>
              <?php echo e($hari_tgl); ?>&nbsp; | &nbsp;<?php echo e($waktu); ?>&nbsp; | &nbsp;<?php echo e($l->nama_studio); ?>&nbsp; | &nbsp;<?php echo e($l->nama_instrumen); ?>&nbsp; | &nbsp;<?php echo e($l->nama_instruktur); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
      <option value="">Jadwal tidak tersedia!</option>
    <?php endif; ?>
  </select>
</div>