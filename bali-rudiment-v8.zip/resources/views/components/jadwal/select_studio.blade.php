<select name="id_studio" id="id_studio" class="form-control select2" title="Studio">
  @if(isset($id_instruktur) && isset($id_instrumen))
    <option value="">Pilih Studio</option>
  @else
    <option value="">Pilih Instruktur & Instrumen terlebih dahulu</option>
  @endif
  @isset($data_studio)
    @foreach($data_studio as $l)
      <option value="{{ $l->id_studio }}" {{ (isset($id_studio) ? $id_studio : null) == $l->id_studio ? 'selected' : '' }}>{{ $l->nama_studio }}</option>
    @endforeach
  @endif
</select>