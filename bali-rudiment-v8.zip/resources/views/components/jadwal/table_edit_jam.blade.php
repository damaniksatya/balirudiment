<form action="{{ url('jadwal/jam-mengajar') }}" method="post">
  @csrf @method('put')
  <input type="hidden" name="id_jadwal" value="{{ $id_jadwal }}">
  <input type="hidden" name="id_siswa" value="{{ $id_siswa }}">
  <table class="table table-sm">
    <tbody>
    @foreach($data_jadwal as $index=>$d)
      <tr>
        <td class="{{ !$index ? 'border-top-0' : '' }}">
          <label class="col-form-label">{{ \App\Http\Controllers\HelperController::setNamaBulan(null, $d->tanggal) }}</label>
        </td>
        <td class="{{ !$index ? 'border-top-0' : '' }}" style="vertical-align: middle !important;">
          <select name="jam_mulai{{ $d->id_jadwal_siswa }}" id="jam_mulai{{ $d->id_jadwal_siswa }}"
                  class="form-control form-control-sm" title="Jam Mulai" required>
            <option value="">Pilih Jam Mulai</option>
            @foreach($data_jam['arr_jam_mulai'] as $jam)
              <option value="{{ $jam }}" {{ $d->jam_mulai == $jam ? 'selected' : '' }}>{{ $jam }}</option>
            @endforeach
          </select>
        </td>
        <td class="font-12 {{ !$index ? 'border-top-0' : '' }}" style="vertical-align: middle !important;">Sampai</td>
        <td class="{{ !$index ? 'border-top-0' : '' }}" style="vertical-align: middle !important;">
          <select name="jam_selesai{{ $d->id_jadwal_siswa }}" id="jam_selesai{{ $d->id_jadwal_siswa }}"
                  class="form-control form-control-sm" title="Jam Selesai" required>
            <option value="">Pilih Jam Selesai</option>
            @foreach($data_jam['arr_jam_selesai'] as $jam)
              <option value="{{ $jam }}" {{ $d->jam_selesai == $jam ? 'selected' : '' }}>{{ $jam }}</option>
            @endforeach
          </select>
        </td>
      </tr>
    @endforeach
    </tbody>
  </table>
  <button class="btn btn-primary float-right">Simpan</button>
</form>