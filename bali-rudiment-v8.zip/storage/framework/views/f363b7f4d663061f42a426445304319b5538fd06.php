<?php $__env->startSection('title','Data Slip Gaji Instruktur Full Time'); ?>

<?php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_slip_gaji_instruktur_fulltime);
  $nonaktif_cetak = in_array(\App\SettingMenu::CETAK_SLIP_GAJI_INSTRUKTUR_FULLTIME, $arr_nonaktif);
?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right mt-2 pt-1">
              </div>
              <h4 class="page-title">Data Slip Gaji Instruktur Full Time</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <div class="table-responsive">
              <table id="datatable" class="table mb-0 table-sm table-bordered">
                <thead>
                <tr>
                  <th class="text-center" style="width: 40px">No</th>
                  <th class="">Bulan</th>
                  <th class="">Gaji Pokok</th>
                  <th class="">Kehadiran Harian</th>
                  <th class="">Tunjangan Tambahan</th>
                  <th class="">Lembur</th>
                  <th class="">Total Penerimaan</th>
                  <?php if(!$nonaktif_cetak): ?>
                    <th style="width: 120px" class="text">Aksi</th>
                  <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-center"><?php echo e($no+1); ?></td>
                    <td class=""><?php echo e(\App\Http\Controllers\HelperController::setNamaBulan($d['bulan'])); ?></td>
                    <td class="text-right"><?php echo e(number_format($d['gaji_pokok'], 0, ',', '.')); ?></td>
                    <td class="text-right"><?php echo e(number_format($d['kehadiran_harian'], 0, ',', '.')); ?></td>
                    <td class="text-right"><?php echo e(number_format($d['tunjangan_tambahan'], 0, ',', '.')); ?></td>
                    <td class="text-right"><?php echo e(number_format($d['lembur_jam']+$d['lembur_hari'], 0, ',', '.')); ?></td>
                    <td class="text-right font-weight-bold"><?php echo e(number_format($d['total_penerimaan'], 0, ',', '.')); ?></td>
                    <?php if(!$nonaktif_cetak): ?>
                      <td>
                        <div class="btn-group btn-block">
                          <a href="<?php echo e(url('slip-gaji/fulltime/print/'.$d['id_gaji'])); ?>" class="btn btn-sm btn-outline-primary" target="_blank">
                            <i class="mdi mdi-printer pr-2"></i>Cetak Slip Gaji
                          </a>
                        </div>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>