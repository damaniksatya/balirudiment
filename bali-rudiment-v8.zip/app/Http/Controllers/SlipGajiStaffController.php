<?php

namespace App\Http\Controllers;

use App\GajiStaff;
use App\GajiStaffAbsenKerja;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SlipGajiStaffController extends Controller
{
  public function index()
  {
    $data_bulan = GajiStaff::getArrBulan();
    $bulan = HelperController::getValue('gaji_staff',['bulan'])['bulan'];
    $data = GajiStaff::getData($bulan);

    return view('pages.slip_gaji.staff.index')
      ->with('bulan', $bulan)
      ->with('data_bulan', $data_bulan)
      ->with('data', $data);
  }

  public function viewAdd()
  {
    return view('pages.slip_gaji.staff.add');
  }

  public function viewEdit($id_gaji)
  {
    $info = GajiStaff::getInfo($id_gaji);
//    dd($info);
    return view('pages.slip_gaji.staff.edit')
      ->with('info', $info);
  }

  public function store(Request $req)
  {
//    dd($req);
    $id_gaji = GajiStaff::insertData([
      'nama_staff' => $req->nama_staff,
      'jabatan' => $req->jabatan,
      'dari_bulan' => $req->dari_bulan,
      'sampai_bulan' => $req->sampai_bulan,
      'gaji_pokok_jml_hari' => $req->gaji_pokok_jml_hari ?: 0,
      'gaji_pokok_per_hari' => $req->gaji_pokok_per_hari ?: 0,
      'gaji_pokok' => $req->gaji_pokok ?: 0,
      'tunj_harian_jml_hari' => $req->tunj_harian_jml_hari ?: 0,
      'tunj_harian_per_hari' => $req->tunj_harian_per_hari ?: 0,
      'tunj_harian' => $req->tunj_harian ?: 0,
      'transport_jml_hari' => $req->transport_jml_hari ?: 0,
      'transport_per_hari' => $req->transport_per_hari ?: 0,
      'transport' => $req->transport ?: 0,
      'tunj_tambahan_jml_hari' => $req->tunj_tambahan_jml_hari ?: 0,
      'tunj_tambahan_per_hari' => $req->tunj_tambahan_per_hari ?: 0,
      'tunj_tambahan' => $req->tunj_tambahan ?: 0,
      'bonus_jml_hari' => $req->bonus_jml_hari ?: 0,
      'bonus_per_hari' => $req->bonus_per_hari ?: 0,
      'bonus' => $req->bonus ?: 0,
      'total_1' => $req->total_1 ?: 0,
      'libur_jml_hari' => $req->libur_jml_hari ?: 0,
      'libur_per_hari' => $req->libur_per_hari ?: 0,
      'libur' => $req->libur ?: 0,
      'sakit_jml_hari' => $req->sakit_jml_hari ?: 0,
      'sakit_per_hari' => $req->sakit_per_hari ?: 0,
      'sakit' => $req->sakit ?: 0,
      'kasbon' => $req->kasbon ?: 0,
      'total_2' => $req->total_2 ?: 0,
      'lembur_jam_jml_jam' => $req->lembur_jam_jml_jam ?: 0,
      'lembur_jam_per_jam' => $req->lembur_jam_per_jam ?: 0,
      'lembur_jam' => $req->lembur_jam ?: 0,
      'lembur_hari_jml_hari' => $req->lembur_hari_jml_hari ?: 0,
      'lembur_hari_per_hari' => $req->lembur_hari_per_hari ?: 0,
      'lembur_hari' => $req->lembur_hari ?: 0,
      'sub_total' => $req->sub_total ?: 0,
      'total_penerimaan' => $req->total_penerimaan ?: 0,
      'notes' => $req->notes,
    ]);

    return redirect("slip-gaji/staff/absensi/$id_gaji");
  }

  public function update(Request $req)
  {
    GajiStaff::updateData([
      'id_gaji' => $req->id_gaji,
      'nama_staff' => $req->nama_staff,
      'jabatan' => $req->jabatan,
      'dari_bulan' => $req->dari_bulan,
      'sampai_bulan' => $req->sampai_bulan,
      'gaji_pokok_jml_hari' => $req->gaji_pokok_jml_hari ?: 0,
      'gaji_pokok_per_hari' => $req->gaji_pokok_per_hari ?: 0,
      'gaji_pokok' => $req->gaji_pokok ?: 0,
      'tunj_harian_jml_hari' => $req->tunj_harian_jml_hari ?: 0,
      'tunj_harian_per_hari' => $req->tunj_harian_per_hari ?: 0,
      'tunj_harian' => $req->tunj_harian ?: 0,
      'transport_jml_hari' => $req->transport_jml_hari ?: 0,
      'transport_per_hari' => $req->transport_per_hari ?: 0,
      'transport' => $req->transport ?: 0,
      'tunj_tambahan_jml_hari' => $req->tunj_tambahan_jml_hari ?: 0,
      'tunj_tambahan_per_hari' => $req->tunj_tambahan_per_hari ?: 0,
      'tunj_tambahan' => $req->tunj_tambahan ?: 0,
      'bonus_jml_hari' => $req->bonus_jml_hari ?: 0,
      'bonus_per_hari' => $req->bonus_per_hari ?: 0,
      'bonus' => $req->bonus ?: 0,
      'total_1' => $req->total_1 ?: 0,
      'libur_jml_hari' => $req->libur_jml_hari ?: 0,
      'libur_per_hari' => $req->libur_per_hari ?: 0,
      'libur' => $req->libur ?: 0,
      'sakit_jml_hari' => $req->sakit_jml_hari ?: 0,
      'sakit_per_hari' => $req->sakit_per_hari ?: 0,
      'sakit' => $req->sakit ?: 0,
      'kasbon' => $req->kasbon ?: 0,
      'total_2' => $req->total_2 ?: 0,
      'lembur_jam_jml_jam' => $req->lembur_jam_jml_jam ?: 0,
      'lembur_jam_per_jam' => $req->lembur_jam_per_jam ?: 0,
      'lembur_jam' => $req->lembur_jam ?: 0,
      'lembur_hari_jml_hari' => $req->lembur_hari_jml_hari ?: 0,
      'lembur_hari_per_hari' => $req->lembur_hari_per_hari ?: 0,
      'lembur_hari' => $req->lembur_hari ?: 0,
      'sub_total' => $req->sub_total ?: 0,
      'total_penerimaan' => $req->total_penerimaan ?: 0,
      'notes' => $req->notes,
    ]);

    return redirect("slip-gaji/staff")->with('success','Berhasil menyimpan data');
  }

  public function viewEditAbsensi($id_gaji)
  {
    $info = GajiStaff::getInfo($id_gaji);
    $arr_bln = $this->getArrBln($info->dari_bulan, $info->sampai_bulan);
    $arr_tgl = $this->getArrTgl($arr_bln);
    $data = $this->getDataAbsensi($id_gaji, $arr_tgl);

//    dd($info, $arr_bln, $arr_tgl, $data);
    return view('pages.slip_gaji.staff.absensi')
      ->with('data', $data)
      ->with('arr_tgl', $arr_tgl)
      ->with('info', $info);
  }

  public function storeAbsensi(Request $req)
  {
    $data_bln = (array)json_decode($req->arr_tgl);
    foreach($data_bln as $bln=>$arr_tgl){
//      $arr_tgl = json_decode($arr_tgl);
      $arr_masuk = [];
      $arr_keluar = [];
      $arr_lembur = [];

      foreach($arr_tgl as $tgl){
        $arr_masuk[] = $req["masuk-$bln-$tgl"];
        $arr_keluar[] = $req["keluar-$bln-$tgl"];
        $arr_lembur[] = $req["lembur-$bln-$tgl"];
      }

      GajiStaffAbsenKerja::insertOrUpdate([
        'id_gaji_staff' => $req->id_gaji_staff,
        'bulan' => $bln,
        'tanggal' => json_encode($arr_tgl),
        'masuk' => json_encode($arr_masuk),
        'keluar' => json_encode($arr_keluar),
        'lembur' => json_encode($arr_lembur),
        'note' => $req["note-$bln"]
      ]);
    }
//    dd($req, $data_bln);

    return redirect('slip-gaji/staff')->with('success','Berhasil menyimpan data');
  }

  public function printSlipGaji($id_gaji)
  {
    $info = GajiStaff::getInfo($id_gaji);
    $arr_bln = $this->getArrBln($info->dari_bulan, $info->sampai_bulan);
    $arr_tgl = $this->getArrTgl($arr_bln);
    if($info['dari_bulan'] == $info['sampai_bulan']){
      $nama_bulan = HelperController::setNamaBulan($info['dari_bulan']);
    }
    else{
      $nama_bulan = HelperController::setNamaBulan($info['dari_bulan']).' - ';
      $nama_bulan .= HelperController::setNamaBulan($info['sampai_bulan']);
    }
    $data = [
      'gaji' => $info,
      'absensi' => $this->getDataAbsensi($id_gaji, $arr_tgl),
      'arr_tgl' => $arr_tgl,
      'nama_bulan' => $nama_bulan
    ];
//    dd($data);
    $pdf = \App::make('dompdf.wrapper');
    $pdf->setPaper('a4', 'portrait');
    $pdf->loadView('pdf.slip_gaji_staff', $data);
    return $pdf->stream("Slip Gaji Staff.pdf");
  }

  public function delete(Request $req)
  {
    DB::transaction(function () use ($req){
      GajiStaff::deleteData($req->id_gaji);
      GajiStaffAbsenKerja::deleteData($req->id_gaji);
    });

    return back()->with('success','Berhasil menghapus data');
  }

  private function getArrBln($dari_bulan, $sampai_bulan)
  {
    $arr_bln = [];
    $tgl = $dari_bulan.'-01';
    $detik_per_28_hari = 86400 * 28;
    do{
      $tgl = date('Y-m-d', ((int)strtotime($tgl)+$detik_per_28_hari));
      $bln = date('Y-m', strtotime($tgl));
      if(!in_array($bln, $arr_bln) && $bln <= $sampai_bulan){
        $arr_bln[] = $bln;
      }
    }
    while($tgl <= $sampai_bulan.'-31');

    return $arr_bln;
  }

  private function getArrTgl($arr_bln)
  {
    $result = [];
    foreach($arr_bln as $bln){
      $arr_tgl = [];

      for($i=1; $i<=31; $i++){
        $tgl = sprintf("%02d", $i);
        $tgl = date('Y-m-d', ((int)strtotime($bln.'-'.$tgl)));
        if(date('Y-m', strtotime($tgl)) == $bln){
          $arr_tgl[] = date('d', strtotime($tgl));
        }
      }

      $result[$bln] = $arr_tgl;
    }
    return $result;
  }

  private function getDataAbsensi($id_gaji, $arr_tgl)
  {
    $data = [];
    foreach($arr_tgl as $bln=>$arr_tgl2){
      $get = GajiStaffAbsenKerja::getData($id_gaji, $bln);
      $arr_masuk = $get ? (array)json_decode($get->masuk) : [];
      $arr_keluar = $get ? (array)json_decode($get->keluar) : [];
      $arr_lembur = $get ? (array)json_decode($get->lembur) : [];
      $temp = [];

      foreach($arr_tgl2 as $index=>$tgl){
        $temp[$tgl] = [
          'masuk' => array_key_exists($index, $arr_masuk) ? $arr_masuk[$index] : null,
          'keluar' => array_key_exists($index, $arr_keluar) ? $arr_keluar[$index] : null,
          'lembur' => array_key_exists($index, $arr_lembur) ? $arr_lembur[$index] : null,
        ];
      }

      $data[$bln] = [
        'data' => $temp,
        'note' => $get ? $get->note : null
      ];
    }
    return $data;
  }
}
