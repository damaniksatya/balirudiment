<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Instrumen extends Model
{
  protected $table = 'instrumen';
  public $timestamps = false;

  const DRUM = 'DRUM';
  const GUITAR = 'GUITAR';
  const BIOLA = 'BIOLA';
  const PIANO = 'PIANO';
  const DANCE = 'DANCE';
  const THEATRE = 'THEATRE';
  const VLOG = 'VLOG';
  const MUSIC_PRODUCTION = 'MUSIC PRODUCTION';
  const VOCAL = 'VOCAL';

  public static $instrument = [
    self::DRUM,
    self::GUITAR,
    self::BIOLA,
    self::PIANO,
    self::DANCE,
    self::THEATRE,
    self::VLOG,
    self::MUSIC_PRODUCTION,
    self::VOCAL,
  ];

  public static function getInfo($id)
  {
    return self::where('id_instrumen', $id)->first();
  }

  public static function getData()
  {
    return self::all();
  }

  public static function getNamaInstrumen($id)
  {
    $get = self::where('id_instrumen', $id)->first();
    return $get ? $get->nama_instrumen : null;
  }

  public static function getDataByArrId($arr_id)
  {
    return self::whereIn('id_instrumen', $arr_id)->get();
  }

  public static function getJumlah()
  {
    return self::count();
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_instrumen', $data['id_instrumen'])->update($data);
  }

  public static function deleteData($id)
  {
    self::where('id_instrumen', $id)->delete();
  }
}
