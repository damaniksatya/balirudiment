<?php $__env->startSection('title','Input Data Studio'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(url('studio')); ?>">Studio</a></li>
                  <li class="breadcrumb-item active">Input</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="<?php echo e(url('studio')); ?>">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input Studio
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="<?php echo e(url('studio')); ?>">
            <?php echo csrf_field(); ?>
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="nama_studio">Nama Studio</label>
                <div class="col-lg-9">
                  <input type="text" id="nama_studio" name="nama_studio" value="<?php echo e(old('nama_studio')); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_penempatan">Penempatan</label>
                <div class="col-lg-9">
                  <select name="id_penempatan" id="id_penempatan" class="form-control select2">
                    <option value="">Pilih Penempatan</option>
                    <?php $__currentLoopData = $data_penempatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($l->id_penempatan); ?>" <?php echo e(old('id_penempatan') == $l->id_penempatan ? 'selected' : ''); ?>><?php echo e($l->nama_penempatan); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_instrumen">Instrumen</label>
                <div class="col-lg-9">
                  <?php
                    $arr_id_instrumen = old('id_instrumen') ?: [];
                  ?>
                  <?php $__currentLoopData = $data_instrumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="custom-control custom-checkbox">
                      <input type="checkbox" class="custom-control-input"
                             <?php echo e(in_array($d->id_instrumen, $arr_id_instrumen) ? 'checked' : ''); ?>

                             id="instrumen<?php echo e($d->id_instrumen); ?>"
                             value="<?php echo e($d->id_instrumen); ?>"
                             name="id_instrumen[]">
                      <label class="custom-control-label" style="cursor: pointer" for="instrumen<?php echo e($d->id_instrumen); ?>"><?php echo e($d->nama_instrumen); ?></label>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>