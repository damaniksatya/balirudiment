<?php $__env->startSection('title','Edit Data Absensi'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(url(request()->get('back_url') ?: 'absensi/instruktur')); ?>">Absensi</a></li>
                  <li class="breadcrumb-item active">Edit</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="<?php echo e(url(request()->get('back_url') ?: 'absensi/instruktur')); ?>">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Edit Absensi
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="<?php echo e(url('absensi')); ?>">
            <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
            <input type="hidden" name="id_absensi" value="<?php echo e($info->id_absensi); ?>">
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_jadwal">Jadwal</label>
                <div class="col-lg-9">
                  <div class="card shadow-none mt-2 mb-0" style="background-color: rgba(0, 0, 0, 0.07)">
                    <div class="card-body">
                      <table class="table table-sm table-borderless mb-0">
                        <tr>
                          <td style="width: 100px">Hari</td>
                          <td class="px-0" style="width: 5px">:</td>
                          <td><?php echo e($info->jadwal->hari); ?></td>
                        </tr>
                        <tr>
                          <td>Tanggal</td>
                          <td class="px-0">:</td>
                          <td><?php echo e(\App\Http\Controllers\HelperController::setNamaBulan(null, $info->tanggal)); ?></td>
                        </tr>
                        <tr>
                          <td>Jam</td>
                          <td class="px-0">:</td>
                          <td><?php echo e($info->jadwal->jam_mulai .'-'. $info->jadwal->jam_selesai); ?></td>
                        </tr>
                        <tr>
                          <td>Studio</td>
                          <td class="px-0">:</td>
                          <td><?php echo e($info->jadwal->nama_studio); ?></td>
                        </tr>
                        <tr>
                          <td>Instrumen</td>
                          <td class="px-0">:</td>
                          <td><?php echo e($info->jadwal->nama_instrumen); ?></td>
                        </tr>
                        <tr>
                          <td>Instruktur</td>
                          <td class="px-0">:</td>
                          <td><?php echo e($info->jadwal->nama_instruktur); ?></td>
                        </tr>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="report">Report</label>
                <div class="col-lg-9">
                  <textarea id="report" name="report" class="form-control" rows="10" required><?php echo e(old('report') ?: $info->report); ?></textarea>
                </div>
              </div>
              <div class="form-group row">
                <div class="col-lg-12">
                  <table class="table table-bordered mb-0">
                    <thead>
                    <tr>
                      <th>Nama Siswa</th>
                      <th colspan="4" class="text-center">Kehadiran</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $arr_id_siswa = []; ?>
                    <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $arr_id_siswa[] = $d['id_siswa']; ?>
                      <tr>
                        <td><label class="form-check-label"><?php echo e($d['siswa']['nama_siswa']); ?></label></td>
                        <td>
                          <div class="form-check">
                            <input class="form-check-input" type="radio" name="kehadiran<?php echo e($d['id_siswa']); ?>" style="cursor: pointer"
                                   <?php echo e($d['kehadiran'] == \App\Absensi::K_HADIR ? 'checked' : ''); ?>

                                   id="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_HADIR); ?>" value="<?php echo e(\App\Absensi::K_HADIR); ?>" >
                            <label class="form-check-label" for="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_HADIR); ?>" style="cursor: pointer">
                              <?php echo e(ucwords(strtolower(\App\Absensi::K_HADIR))); ?>

                            </label>
                          </div>
                        </td>
                        <td>
                          <div class="form-check">
                            <input class="form-check-input" type="radio" name="kehadiran<?php echo e($d['id_siswa']); ?>" style="cursor: pointer"
                                   <?php echo e($d['kehadiran'] == \App\Absensi::K_IZIN ? 'checked' : ''); ?>

                                   id="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_IZIN); ?>" value="<?php echo e(\App\Absensi::K_IZIN); ?>">
                            <label class="form-check-label" for="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_IZIN); ?>" style="cursor: pointer">
                              <?php echo e(ucwords(strtolower(\App\Absensi::K_IZIN))); ?>

                            </label>
                          </div>
                        </td>
                        <td>
                          <div class="form-check">
                            <input class="form-check-input" type="radio" name="kehadiran<?php echo e($d['id_siswa']); ?>" style="cursor: pointer"
                                   <?php echo e($d['kehadiran'] == \App\Absensi::K_SAKIT ? 'checked' : ''); ?>

                                   id="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_SAKIT); ?>" value="<?php echo e(\App\Absensi::K_SAKIT); ?>">
                            <label class="form-check-label" for="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_SAKIT); ?>" style="cursor: pointer">
                              <?php echo e(ucwords(strtolower(\App\Absensi::K_SAKIT))); ?>

                            </label>
                          </div>
                        </td>
                        <td>
                          <div class="form-check">
                            <input class="form-check-input" type="radio" name="kehadiran<?php echo e($d['id_siswa']); ?>" style="cursor: pointer"
                                   <?php echo e($d['kehadiran'] == \App\Absensi::K_TIDAK_HADIR ? 'checked' : ''); ?>

                                   id="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_TIDAK_HADIR); ?>" value="<?php echo e(\App\Absensi::K_TIDAK_HADIR); ?>">
                            <label class="form-check-label" for="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_TIDAK_HADIR); ?>" style="cursor: pointer">
                              <?php echo e(ucwords(strtolower(\App\Absensi::K_TIDAK_HADIR))); ?>

                            </label>
                          </div>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>

                  <input type="hidden" name="id_siswa" value="<?php echo e(json_encode($arr_id_siswa)); ?>">
                </div>
              </div>
            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>