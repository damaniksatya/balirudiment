@extends('layouts.main')

@section('title','Data Jadwal Harian')

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Material+Icons" />
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right mt-2 pt-1">
              </div>
              <h4 class="page-title">Data Jadwal Harian</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <form method="get" class="card-body">
            <div class="row">
              <div class="col-lg-6">
                <div class="form-group row mb-0">
                  <label class="col-form-label col-lg-3 text-lg-right" for="id_penempatan">Penempatan</label>
                  <div class="col-lg-9">
                    <select id="id_penempatan" class="form-control select2" disabled>
                      @foreach($data_penempatan as $d)
                        @if($id_penempatan == $d->id_penempatan)
                          <option value="{{ $d->id_penempatan }}" >{{ $d->nama_penempatan }}</option>
                        @endif
                      @endforeach
                    </select>
                  </div>
                </div>
              </div>
              <input type="hidden" id="id_penempatan" name="id_penempatan" value="{{ $id_penempatan }}">
              <div class="col-lg-6">
                <div class="form-group row mb-0">
                  <label class="col-form-label col-lg-3 text-lg-right" for="tanggal">Tanggal</label>
                  <div class="col-lg-9">
                    <input type="text" name="tanggal" id="tanggal" class="form-control datepicker"
                           value="{{ date('d-m-Y', strtotime($tanggal)) }}" onchange="this.form.submit()">
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>

      <div class="col-lg-12">
        <div class="card">
          <div class="card-body overflow-auto p-0">
            <table class="mx-auto" border="0">
              <tr>
                <td class="pl-3">
                  <p class="my-3 font-weight-bold">{{ $hari.', '.$tanggal_f }}</p>
                </td>
              </tr>
              <tr>
                <td class="text-center">

                  <table class="table-xs table-bordered">
                    <tbody>
                    @php
                      $arr_hidden = [];
                      $total_width = 0;
                      $jumlah_instruktur = array_key_exists(0, $data) ? count($data[0]) - 2 : 0;
                      $jumlah_instruktur = $jumlah_instruktur != 0 ? $jumlah_instruktur / 2 : 0;
                    @endphp
                    @foreach($data as $index_row=>$row)
                      <tr>
                        @foreach($row as $index_col=>$cell)
                          @php
                            $col_name = \App\Http\Controllers\HelperController::getColumnAlphabeticalNameByNumber($index_col+1);
                            $cell_name = $col_name.($index_row+1);
                            $is_merge = array_key_exists($cell_name, $merge_cell);
                            if($is_merge){
                              for($r=1; $r<=$merge_cell[$cell_name][1]; $r++){
                                for($c=1; $c<=$merge_cell[$cell_name][0]; $c++){
                                  $next_col = $c + $index_col;
                                  $next_row = $r + $index_row;
                                  $next_col_name = \App\Http\Controllers\HelperController::getColumnAlphabeticalNameByNumber($next_col);
                                  $next_cell_name = $next_col_name.$next_row;
                                  if($next_cell_name != $cell_name && !in_array($next_cell_name, $arr_hidden)) $arr_hidden[] = $next_cell_name;
                                }

                              }
                            }
                          @endphp
                          @if(!in_array($cell_name, $arr_hidden))
                            @php
                              $colspan = $is_merge ? $merge_cell[$cell_name][0] : 1;
                              $rowspan = $is_merge ? $merge_cell[$cell_name][1] : 1;
                              $arr_style = [];
                              $exists_style = array_key_exists($cell_name, $style);
                              $exists_read_only = array_key_exists($cell_name, $read_only);
                              if(in_array($index_row, [1, 2])){
                                $width = $column[$index_col]['width'];
                                $width = explode('px', $width);
                                $width = is_numeric($width[0]) ? $width[0] : 0;
                                $arr_style['width'] = $width.'px';
                                $arr_style['min-width'] = $width.'px !important';

                                if($index_row == 1){
                                  $padding_cell = 2.72;
                                  $border_width = 3.5;
                                  $total_width += ($width + ($padding_cell * 2) + ($border_width * 2));
                                }
                              }
                              if($exists_read_only && $read_only[$cell_name]['readonly'] == true){
                                if(!($exists_style && strpos('background-color', $style[$cell_name]) === false)){
                                  $arr_style['background-color'] = '#F3F3F3';
                                }
                              }
                              $temp_style = $exists_style ? $style[$cell_name].'; ' : '';
                              foreach($arr_style as $property=>$value){
                                $temp_style .= "$property: $value; ";
                              }
                            @endphp
                            <td colspan="{{ $colspan }}" rowspan="{{ $rowspan }}" style="{{ $temp_style }}">{{ $cell }}</td>
                          @endif
                        @endforeach
                      </tr>
                    @endforeach

                    </tbody>
                  </table>

                </td>
              </tr>
            </table>
          </div>
          <div class="card-body overflow-auto">
            <table style="width: 100%">
              <tr>
                <td class="text-left" style="vertical-align: top; min-width: 200px; font-size: .8rem; white-space: pre-wrap">{{ $info['note'] }}</td>
                <td class="text-left" style="vertical-align: top; min-width: 200px; font-size: .8rem; white-space: pre-wrap">{{ $info['note2'] }}</td>
                <td style="width: 200px; max-width: 200px; vertical-align: top !important;">
                  <table class="table table-bordered table-xs text-left mb-0">
                    @foreach(\App\JadwalHarian::$arr_keterangan as $ket)
                      <tr>
                        <td style="width: 29px; background-color: {{ $ket['background'] }}"></td>
                        <td class="pl-2">{{ $ket['text'] }}</td>
                      </tr>
                    @endforeach
                  </table>
                </td>
              </tr>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <style>
    .table tr td{
      vertical-align: top !important;
    }
    #spreadsheet{
      z-index: 101;
    }
    .jss thead, .jss tbody tr td:first-child, .jss colgroup col:first-child{
      visibility: hidden;
    }
    .jss thead tr td{
      padding: 0 !important;
      border: none !important;
    }
    .jss tbody tr td:first-child{
      padding: 0 !important;
      border: none !important;
    }
    .jss tbody tr .readonly{
      background-color: #F3F3F3;
      color: #495057 !important;
    }
    .jss_scroll{
      max-height: 540px;
    }
    .jss_content_overflow{
      border-right: none;
      border-bottom: none;
      width: 100%;
    }
    .jss > tbody > tr > td.jss_number {
      text-align: center;
    }
    .table-xs tr td{
      padding: 0.2rem;
    }
  </style>
@endsection
@section('script')
  @include('components.datepicker')
@endsection