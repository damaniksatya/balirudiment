<tr>
  @if($with_hari)
    @php
      $rowspan_hari = $hari['siswa_total'] >= $hari['jadwal_total'] ? $hari['siswa_total'] : $hari['jadwal_total'];
    @endphp
    <td rowspan="{{ $rowspan_hari }}">{{ $hari['hari'] }}</td>
  @endif

  @if($with_jadwal)
    <td rowspan="{{ $jadwal['siswa_total'] + 1 }}" class="text-center">{{ $jadwal['jam_mulai'] .' - '. $jadwal['jam_selesai'] }}</td>
    <td rowspan="{{ $jadwal['siswa_total'] + 1 }}">{{ $jadwal['nama_studio'] }}</td>
    <td rowspan="{{ $jadwal['siswa_total'] + 1 }}" style="width: 150px">{{ $jadwal['nama_instrumen'] }}</td>
    @if(!($nonaktif_edit && $nonaktif_delete))
      <td rowspan="{{ $jadwal['siswa_total'] + 1 }}" style="width: 40px; padding: 2px">
        <div class="btn-group btn-block">
          @if(!$nonaktif_edit)
            <a class="btn btn-xs btn-outline-primary"
               href="{{ url('jadwal/edit/'.$jadwal['id_jadwal']) }}"
               style="padding-top: 3px; padding-bottom: 3px" title="Edit Jadwal">
              <i class="mdi mdi-pencil"></i>
            </a>
          @endif

          @if(!$nonaktif_delete)
            <button class="btn btn-xs btn-outline-danger" style="padding-top: 3px; padding-bottom: 3px"
                    title="Hapus Jadwal" onclick="deleteData('{{ $jadwal['id_jadwal'] }}')">
              <i class="mdi mdi-trash-can"></i>
            </button>
          @endif
        </div>
      </td>
    @endif
  @endif

  @if($index_siswa != $jadwal['siswa_total'])
    <td class="p-0">
      <table style="width: 100%" class="table-borderless">
        <tr>
          <td>{{ $jadwal['siswa'][$index_siswa]['nama_siswa'] }}</td>
          @if(!$nonaktif_edit_siswa)
            <td style="width: 30px">
              <div class="btn-group dropleft">
                <button class="btn btn-sm btn-outline-primary border-0" data-toggle="dropdown" style="padding: 2px 5px 1px 5px; border-radius: 0.2rem">
                  <i class="mdi mdi-settings"></i>
                </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" href="#" onclick="openModalEditJam('{{ $jadwal['id_jadwal'] }}','{{ $jadwal['siswa'][$index_siswa]['id_siswa'] }}')">
                    Edit Jam Mengajar Per Tanggal
                  </a>
                </div>
              </div>
            </td>
          @endif
        </tr>
      </table>

    </td>
  @else
    @if(!$nonaktif_edit_siswa)
      <td style="padding: 2px" class="text-center">
          <button class="btn btn-sm btn-block btn-outline-secondary" style="padding-top: 3px; padding-bottom: 3px; border-color: #e9ecef !important;"
                  onclick="openModalAddSiswa('{{ $jadwal['id_jadwal'] }}')">
            @if(!$jadwal['siswa_total'])
              Masukkan Siswa
            @else
              Edit Siswa
            @endif
          </button>
      </td>
    @endif
  @endif
</tr>