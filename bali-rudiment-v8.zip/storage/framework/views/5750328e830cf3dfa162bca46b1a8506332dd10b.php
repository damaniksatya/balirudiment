<div class="slimscroll-menu">
  <div id="sidebar-menu">
    <?php if(\Illuminate\Support\Facades\Auth::user()->level_user == \App\User::L_ADMIN): ?>
      <?php echo $__env->make('components.sidebar_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(\Illuminate\Support\Facades\Auth::user()->level_user == \App\User::L_GENERAL_ADMIN): ?>
      <?php echo $__env->make('components.sidebar_general_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(\Illuminate\Support\Facades\Auth::user()->level_user == \App\User::L_INSTRUKTUR): ?>
      <?php echo $__env->make('components.sidebar_instruktur', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(\Illuminate\Support\Facades\Auth::user()->level_user == \App\User::L_ACCOUNTING): ?>
      <?php echo $__env->make('components.sidebar_accounting', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php elseif(\Illuminate\Support\Facades\Auth::user()->level_user == \App\User::L_SISWA): ?>
      <?php echo $__env->make('components.sidebar_siswa', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
  </div>
  <div class="clearfix"></div>
  
</div>
