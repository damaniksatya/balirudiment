<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta content="Bali Rudiment" name="description" />
  
  <meta content="LaraDev" name="author" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <link rel="icon" type="image/jpg" sizes="16x16" href="<?php echo e(url('images/logo.jpg')); ?>">
  <?php echo $__env->yieldContent('css'); ?>
  <link href="<?php echo e(url('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" id="bootstrap-stylesheet" />
  <link href="<?php echo e(url('css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(url('css/app.min.css')); ?>" rel="stylesheet" type="text/css"  id="app-stylesheet" />
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/@mdi/font@6.9.96/css/materialdesignicons.min.css">
</head>
<body>
<div id="wrapper">
  <div class="navbar-custom">
    <?php echo $__env->make('components.top_navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <div class="left-side-menu" style="width: 260px">
    <?php echo $__env->make('components.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <div class="content-page" style="margin-left: 260px">
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('components.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</div>
<script src="<?php echo e(url('js/vendor.min.js')); ?>"></script>
<script src="<?php echo e(url('js/app.min.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>