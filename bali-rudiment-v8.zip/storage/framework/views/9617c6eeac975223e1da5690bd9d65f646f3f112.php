<?php $__env->startSection('title','Data Slip Gaji Staff'); ?>

<?php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_slip_gaji_staff);
  $nonaktif_cetak = in_array(\App\SettingMenu::CETAK_SLIP_GAJI_STAFF, $arr_nonaktif);
  $nonaktif_input = in_array(\App\SettingMenu::INPUT_SLIP_GAJI_STAFF, $arr_nonaktif);
  $nonaktif_edit = in_array(\App\SettingMenu::EDIT_SLIP_GAJI_STAFF, $arr_nonaktif);
  $nonaktif_delete = in_array(\App\SettingMenu::HAPUS_SLIP_GAJI_STAFF, $arr_nonaktif);
?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right mt-2 pt-1">
                <?php if($nonaktif_input == false): ?>
                  <a href="<?php echo e(url('slip-gaji/staff/add')); ?>" class="btn btn-primary">
                    <i class="mdi mdi-plus mr-2"></i>Input Data Slip Gaji Staff
                  </a>
                <?php endif; ?>
              </div>
              <h4 class="page-title">Data Slip Gaji Staff</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <form method="get" class="card-body border-bottom">
            <div class="form-group row mb-0">
              <label class="col-lg-3 text-right col-form-label" for="bulan">Bulan</label>
              <div class="col-lg-9">
                <select name="bulan" id="bulan" class="form-control select2" onchange="this.form.submit()">
                  <option value="">Semua Bulan</option>
                  <?php $__currentLoopData = $data_bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($bln); ?>" <?php echo e($bln == $bulan ? 'selected' : ''); ?>><?php echo e(\App\Http\Controllers\HelperController::setNamaBulan($bln)); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
          </form>
          <div class="card-body">
            <div class="table-responsive">
              <table id="datatable" class="table mb-0 table-sm table-bordered">
                <thead>
                <tr>
                  <th class="text-center" style="width: 40px">No</th>
                  <th class="">Nama Staff</th>
                  <th class="">Jabatan</th>
                  <th class="">Bulan</th>
                  <th class="">Total Penerimaan</th>
                  <?php if(!($nonaktif_edit && $nonaktif_delete && $nonaktif_cetak)): ?>
                    <th style="width: 220px" class="text">Aksi</th>
                  <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-center"><?php echo e($no+1); ?></td>
                    <td class=""><?php echo e($d['nama_staff']); ?></td>
                    <td class=""><?php echo e($d['jabatan']); ?></td>
                    <?php if($d['dari_bulan'] == $d['sampai_bulan']): ?>
                      <td class=""><?php echo e(\App\Http\Controllers\HelperController::setNamaBulan($d['dari_bulan'])); ?></td>
                    <?php else: ?>
                      <td class="">
                        <?php echo e(\App\Http\Controllers\HelperController::setNamaBulan($d['dari_bulan']) .' - '.
                      \App\Http\Controllers\HelperController::setNamaBulan($d['sampai_bulan'])); ?>

                      </td>
                    <?php endif; ?>
                    <td class="text-right"><?php echo e(number_format($d['total_penerimaan'], 0, ',', '.')); ?></td>
                    <?php if(!($nonaktif_edit && $nonaktif_delete && $nonaktif_cetak)): ?>
                      <td>
                        <div class="btn-group btn-block">
                          <?php if(!$nonaktif_cetak): ?>
                            <a href="<?php echo e(url('slip-gaji/staff/print/'.$d['id_gaji'])); ?>" class="btn btn-sm btn-outline-primary" target="_blank">
                              <i class="mdi mdi-printer pr-2"></i>Cetak Slip Gaji
                            </a>
                          <?php endif; ?>

                          <?php if(!$nonaktif_edit): ?>
                            <button type="button" class="btn btn-outline-primary btn-sm dropdown-toggle pr-1"
                                    data-toggle="dropdown" aria-expanded="false" style="border-top-right-radius: 0; border-bottom-right-radius: 0">
                              Edit <i class="mdi mdi-chevron-down"></i>
                            </button>
                            <div class="dropdown-menu">
                              <?php
                                $back_url = '?back_url='.\Illuminate\Support\Facades\Route::current()->uri;
                              ?>
                              <a class="dropdown-item" href="<?php echo e(url('slip-gaji/staff/edit/'.$d['id_gaji'].$back_url)); ?>">Edit Gaji</a>
                              <a class="dropdown-item" href="<?php echo e(url('slip-gaji/staff/absensi/'.$d['id_gaji'].$back_url)); ?>">Edit Absensi</a>
                            </div>
                          <?php endif; ?>

                          <?php if(!$nonaktif_delete): ?>
                            <button id="delete-<?php echo e($d['id_gaji']); ?>" type="button" class="btn btn-sm btn-outline-danger">Hapus</button>
                          <?php endif; ?>
                        </div>

                        <form id="form-delete<?php echo e($d['id_gaji']); ?>" action="<?php echo e(url('slip-gaji/staff')); ?>" method="post">
                          <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                          <input type="hidden" name="id_gaji" value="<?php echo e($d['id_gaji']); ?>">
                        </form>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          $('#delete-<?php echo e($d['id_gaji']); ?>').click(function(){
              swal({
                  title: "Anda yakin?",
                  text: "Data Slip Gaji <?php echo e($d['nama_staff']); ?> yang akan dihapus, tidak bisa dikembalikan!",
                  type: "warning",
                  showCancelButton: true,
                  confirmButtonColor: "#E62129",
                  confirmButtonText: "Ya, hapus!",
                  cancelButtonText: "Batalkan",
                  closeOnConfirm: false
              }, function(){
                  $("#form-delete<?php echo e($d['id_gaji']); ?>").submit();
              });
          });
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>