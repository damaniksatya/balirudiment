<title>Jadwal Instruktur Bali Rudiment {{ $nama_tempat }} {{ $hari.', '.$tanggal_f }}</title>

<h6 class="text-center mb-1">JADWAL INSTRUKTUR</h6>
<h6 class="text-center mt-0">BALI RUDIMENT {{ $nama_tempat }}</h6>

<div class="text-center">
  <table class=" mx-auto" border="0">
    <tr>
      <td>
        <p class="my-1 font-weight-bold">{{ $hari.', '.$tanggal_f }}</p>
      </td>
    </tr>
    <tr>
      <td class="text-center">

        <table class="table-xs table-bordered">
          <colgroup>
            @foreach($column as $colgroup)
              <col width="{{ $colgroup['width'] }}">
            @endforeach
          </colgroup>
          <tbody>
          @php
            $arr_hidden = [];
            $total_width = 0;
            $jumlah_instruktur = array_key_exists(0, $data) ? count($data[0]) - 2 : 0;
            $jumlah_instruktur = $jumlah_instruktur != 0 ? $jumlah_instruktur / 2 : 0;
          @endphp
          @foreach($data as $index_row=>$row)
            <tr>
              @foreach($row as $index_col=>$cell)
                @php
                  $col_name = \App\Http\Controllers\HelperController::getColumnAlphabeticalNameByNumber($index_col+1);
                  $cell_name = $col_name.($index_row+1);
                  $is_merge = array_key_exists($cell_name, $merge_cell);
                  if($is_merge){
                    for($r=1; $r<=$merge_cell[$cell_name][1]; $r++){
                      for($c=1; $c<=$merge_cell[$cell_name][0]; $c++){
                        $next_col = $c + $index_col;
                        $next_row = $r + $index_row;
                        $next_col_name = \App\Http\Controllers\HelperController::getColumnAlphabeticalNameByNumber($next_col);
                        $next_cell_name = $next_col_name.$next_row;
                        if($next_cell_name != $cell_name && !in_array($next_cell_name, $arr_hidden)) $arr_hidden[] = $next_cell_name;
                      }

                    }
                  }
                @endphp
                @if(!in_array($cell_name, $arr_hidden))
                  @php
                    $colspan = $is_merge ? $merge_cell[$cell_name][0] : 1;
                    $rowspan = $is_merge ? $merge_cell[$cell_name][1] : 1;
                    $arr_style = [];
                    $exists_style = array_key_exists($cell_name, $style);
                    $exists_read_only = array_key_exists($cell_name, $read_only);
                    if(in_array($index_row, [1, 2])){
                      if($jumlah_instruktur == 1){
                        $persentase = 1.9;
                      }
                      elseif($jumlah_instruktur <= 2){
                        $persentase = 1.2;
                      }
                      elseif($jumlah_instruktur <= 4){
                        $persentase = 0.95;
                      }
                      elseif($jumlah_instruktur <= 6){
                        $persentase = 0.85;
                      }
                      else $persentase = 0.65;

                      $width = $column[$index_col]['width'];
                      $width = explode('px', $width);
                      $width = is_numeric($width[0]) ? ($width[0] * $persentase) : 0;
                      $arr_style['width'] = $width.'px';

                      if($index_row == 1){
                        $padding_cell = 2.72;
                        $border_width = 3.5;
                        $total_width += ($width + ($padding_cell * 2) + ($border_width * 2));
                      }
                    }
                    if($exists_read_only && $read_only[$cell_name]['readonly'] == true){
                      if(!($exists_style && strpos('background-color', $style[$cell_name]) === false)){
                        $arr_style['background-color'] = '#F3F3F3';
                      }
                    }
                    $temp_style = $exists_style ? $style[$cell_name].'; ' : '';
                    foreach($arr_style as $property=>$value){
                      $temp_style .= "$property: $value; ";
                    }
                  @endphp
                  <td colspan="{{ $colspan }}" rowspan="{{ $rowspan }}" style="{{ $temp_style }}">{{ $cell }}</td>
                @endif
              @endforeach
            </tr>
          @endforeach

          </tbody>
        </table>

      </td>
    </tr>
    <tr>
      <td class="pt-2">

        <table style="width: 100%">
          <tr>
            <td class="text-left" style="vertical-align: top; min-width: 200px; font-size: .8rem; white-space: pre-wrap">{{ $info['note'] }}</td>
            <td class="text-left" style="vertical-align: top; min-width: 200px; font-size: .8rem; white-space: pre-wrap">{{ $info['note2'] }}</td>
            <td style="width: 120px; max-width: 120px; vertical-align: top !important;">
              <table class="table table-bordered table-xs text-left mb-0">
                @foreach(\App\JadwalHarian::$arr_keterangan as $ket)
                  <tr>
                    <td style="width: 12px; background-color: {{ $ket['background'] }}"></td>
                    <td class="pl-2">{{ $ket['text'] }}</td>
                  </tr>
                @endforeach
              </table>
            </td>
          </tr>
        </table>

      </td>
    </tr>
  </table>

</div>

<style>
  @php
    $margin_left = 25;
    $margin_right = 25;
    if($jumlah_instruktur <= 7){
      $page_length = '30cm';
    }
    else{
      $page_length = $total_width + $margin_left + $margin_right;
      $page_length = $page_length.'px';
    }
  @endphp
  @page{
    /*size: 30cm 21cm;*/
    size: {{ $page_length }} 21cm;
    margin-left: {{ $margin_left }}px;
    margin-right: {{ $margin_right }}px;
  }
  table tr td{
    text-align: center;
    vertical-align: middle;
  }
</style>
@include('pdf.style')