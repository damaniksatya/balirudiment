<?php

namespace App\Http\Controllers;

use App\User;
use App\Accounting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;

class AccountingController extends Controller
{
  public function index()
  {
    $data = Accounting::getData();
//    dd($data);
    return view('pages.accounting.index')
      ->with('data', $data);
  }

  public function viewAdd()
  {
    return view('pages.accounting.add');
  }

  public function viewEdit($id_pengguna)
  {
    $info = Accounting::getInfo($id_pengguna);

    return view('pages.accounting.edit')
      ->with('info', $info);
  }

  public function viewEditProfile()
  {
    $id_pengguna = Auth::user()->id;
    $info = Accounting::getInfo($id_pengguna);

    return view('pages.accounting.profile')
      ->with('info', $info);
  }

  public function store(Request $req)
  {
    $this->validateData();

    DB::transaction(function () use ($req){
      $id_pengguna = User::insertData([
        'nama' => $req->nama,
        'username' => $req->username,
        'password' => bcrypt($req->password),
        'foto_profile' => $this->storeImageFile(),
        'level_user' => User::L_ACCOUNTING,
        'status' => User::S_AKTIF
      ]);

      Accounting::insertData([
        'id_pengguna' => $id_pengguna,
        'nama_accounting' => $req->nama,
        'email_accounting' => $req->email_accounting,
        'no_hp' => $req->no_hp,
        'jenis_kelamin' => $req->jenis_kelamin
      ]);
    });

    return back()->with('success','Berhasil menyimpan data');
  }

  public function update(Request $req)
  {
    DB::transaction(function () use ($req){
      $new_username = $req->username != $req->username_old;
      $new_email = $req->email_accounting != $req->email_accounting_old;
      $new_password = $req->password != null;
      $this->validateData($new_username, $new_email, $new_password);

      $data_pengguna = [
        'id' => $req->id_pengguna,
        'nama' => $req->nama,
        'username' => $req->username,
      ];
      if($new_password){
        $data_pengguna['password'] = bcrypt($req->password);
      }
      if(request()->file('foto_profile')){
        $data_pengguna['foto_profile'] = $this->storeImageFile();
        $this->deleteFile($req->foto_profile_old);
      }

      User::updateData($req->id_pengguna, $data_pengguna);

      Accounting::updateData([
        'id_pengguna' => $req->id_pengguna,
        'nama_accounting' => $req->nama,
        'email_accounting' => $req->email_accounting,
        'no_hp' => $req->no_hp,
        'jenis_kelamin' => $req->jenis_kelamin
      ]);
    });

    return redirect('accounting')->with('success','Berhasil menyimpan data');
  }

  public function updateProfile(Request $req)
  {
    DB::transaction(function () use ($req){
      $new_username = $req->username != $req->username_old;
      $new_email = $req->email_accounting != $req->email_accounting_old;
      $this->validateData($new_username, $new_email, false);

      $data_pengguna = [
        'id' => $req->id_pengguna,
        'username' => $req->username,
      ];
      if(request()->file('foto_profile')){
        $data_pengguna['foto_profile'] = $this->storeImageFile();
        $this->deleteFile($req->foto_profile_old);
      }

      User::updateData($req->id_pengguna, $data_pengguna);

      Accounting::updateData([
        'id_pengguna' => $req->id_pengguna,
        'email_accounting' => $req->email_accounting,
        'no_hp' => $req->no_hp,
      ]);
    });

    return back()->with('success','Berhasil menyimpan data');
  }

  public function updateStatus(Request $req)
  {
    User::updateData($req->id, [
      'status' => $req->status
    ]);

    return back()->with('success','Berhasil menyimpan data');
  }

  private function validateData($new_username = true, $new_email = true, $new_password = true)
  {
    return request()->validate([
      'nama' => 'required|max:80',
      'email_accounting' => 'required|email|max:80'.($new_email ? '|unique:accounting' : ''),
      'no_hp' => 'required|max:20',
      'jenis_kelamin' => 'required',
      'username' => 'required|max:30|min:3'.($new_username ? '|unique:pengguna' : ''),
      'password' => $new_password ? 'required|min:6' : '',
    ],[
      'nama.required' => 'Nama harus diisi!',
      'nama.max' => 'Nama maksimal :max karakter!',
      'email_accounting.required' => 'Email harus diisi!',
      'email_accounting.max' => 'Email maksimal :max karakter!',
      'email_accounting.unique' => 'Email telah digunakan!',
      'email_accounting.email' => 'Email tidak valid!',
      'no_hp.required' => 'No HP harus diisi!',
      'no_hp.max' => 'No HP maksimal :max karakter!',
      'jenis_kelamin.required' => 'Jenis Kelamin harus diisi!',
      'username.required' => 'Username harus diisi!',
      'username.max' => 'Username maksimal :max karakter!',
      'username.min' => 'Username minimal :min karakter!',
      'username.unique' => 'Username telah digunakan!',
      'password.required' => 'Kata Sandi harus diisi!',
      'password.min' => 'Kata Sandi minimal :min karakter!',
    ]);
  }

  private function storeImageFile($location = 'storage/foto_profile')
  {
    if(request()->file('foto_profile')){
      $file = request()->file('foto_profile');
      $ext = $file->getClientOriginalExtension();
      $name = time() .'.' . $ext;
      $file->move(public_path() . "/$location", $name);
      return $location.'/'.$name;
    }
    else{
      return null;
    }
  }

  private function deleteFile($nama)
  {
    File::delete("public/$nama");
  }
}
