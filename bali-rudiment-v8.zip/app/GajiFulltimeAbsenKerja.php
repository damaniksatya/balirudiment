<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GajiFulltimeAbsenKerja extends Model
{
  protected $table = 'gaji_fulltime_absen_kerja';
  public $timestamps = false;

  public static function getInfo($id_gaji_fulltime)
  {
    return self::where('id_gaji_fulltime', $id_gaji_fulltime)->first();
  }

  public static function insertOrUpdate($data)
  {
    $exists = self::where('id_gaji_fulltime', $data['id_gaji_fulltime'])
      ->where('bulan', $data['bulan'])
      ->exists();

    if($exists) self::updateData($data);
    else self::insertData($data);
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_gaji_fulltime', $data['id_gaji_fulltime'])
      ->where('bulan', $data['bulan'])
      ->update($data);
  }

  public static function deleteData($id_gaji_fulltime)
  {
    self::where('id_gaji_fulltime', $id_gaji_fulltime)->delete();
  }
}
