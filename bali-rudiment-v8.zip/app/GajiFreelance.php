<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GajiFreelance extends Model
{
  protected $table = 'gaji_freelance';
  public $timestamps = false;
  protected $primaryKey = 'id_gaji';

  public static function getInfo($id_gaji)
  {
    $get = self::where('id_gaji', $id_gaji)->first();
    if($get){
      $get->instruktur = Instruktur::getInfoByIdInstruktur($get->id_instruktur);
    }
    return $get;
  }

  public static function getData($bulan)
  {
    if($bulan == null){
      $get = self::all();
    }
    else{
      $get = self::where('bulan', $bulan)->get();
    }

    foreach($get as $index=>$g){
      $get[$index]->instruktur = Instruktur::getInfoByIdInstruktur($g->id_instruktur);
    }

    return $get;
  }

  public static function getDataByIdInstruktur($id_instruktur)
  {
    return self::where('id_instruktur', $id_instruktur)
      ->orderBy('bulan','DESC')
      ->get();
  }

  public static function getArrBulan()
  {
    return self::groupBy('bulan')->pluck('bulan')->toArray();
  }

  public static function getTotalByBulan($bulan)
  {
    return self::where('bulan', $bulan)
      ->selectRaw("SUM(grand_total) as total")
      ->first()->total;
  }

  public static function insertData($data)
  {
    $keys = array_keys($data);
    $new = new self();
    foreach($keys as $key){
      $new->$key = $data[$key];
    }
    $new->save();

    return $new->id_gaji;
  }

  public static function updateData($data)
  {
    self::where('id_gaji', $data['id_gaji'])->update($data);
  }

  public static function deleteData($id_gaji)
  {
    self::where('id_gaji', $id_gaji)->delete();
  }
}
