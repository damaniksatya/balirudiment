@if(count($data_siswa))
  <form action="{{ url('jadwal/add-siswa') }}" method="post">
    @csrf
    <input type="hidden" name="siswa_in_jadwal" value="{{ json_encode($siswa_in_jadwal) }}">
    <input type="hidden" name="siswa_not_in_jadwal" value="{{ json_encode($siswa_not_in_jadwal) }}">
    <input type="hidden" name="id_jadwal" value="{{ $info->id_jadwal }}">
    <input type="hidden" name="bulan" value="{{ $info->bulan }}">
    <input type="hidden" name="hari" value="{{ $info->hari }}">
    <table class="table table-sm table-bordered">
      <tbody>
      @foreach($data_siswa as $d)
        @php
          $jam_siswa = \App\JadwalSiswa::getJamMulaiSelesai($info->id_jadwal, $d->id_siswa);
        @endphp
        <tr>
          <td>
            <div class="custom-control custom-checkbox">
              <input type="checkbox" name="id_siswa[]" value="{{ $d->id_siswa }}" class="custom-control-input"
                     onchange="showJam('{{ $d->id_siswa }}')"
                     id="id_siswa{{ $d->id_siswa }}" {{ in_array($d->id_siswa, $siswa_in_jadwal) ? 'checked' : '' }}>
              <label class="custom-control-label" for="id_siswa{{ $d->id_siswa }}" style="cursor: pointer">{{ $d->nama_siswa }}</label>
            </div>
            <table class="table-borderless" id="jam_siswa{{ $d->id_siswa }}" style="display: {{ in_array($d->id_siswa, $siswa_in_jadwal) ? 'block' : 'none' }}">
              <tr>
                <td style="width: 20px"></td>
                <td>
                  <input type="hidden" name="jam_mulai_old{{ $d->id_siswa }}" value="{{ $jam_siswa['jam_mulai'] }}">
                  <select name="jam_mulai{{ $d->id_siswa }}" id="jam_mulai{{ $d->id_siswa }}" class="form-control form-control-sm" title="Jam Mulai">
                    <option value="">Pilih Jam Mulai</option>
                    @foreach($data_jam['arr_jam_mulai'] as $jam)
                      <option value="{{ $jam }}" {{ $jam_siswa['jam_mulai'] == $jam ? 'selected' : '' }}>{{ $jam }}</option>
                    @endforeach
                  </select>
                </td>
                <td class="font-12" style="vertical-align: middle !important;">Sampai</td>
                <td>
                  <input type="hidden" name="jam_selesai_old{{ $d->id_siswa }}" value="{{ $jam_siswa['jam_selesai'] }}">
                  <select name="jam_selesai{{ $d->id_siswa }}" id="jam_selesai{{ $d->id_siswa }}" class="form-control form-control-sm" title="Jam Selesai">
                    <option value="">Pilih Jam Selesai</option>
                    @foreach($data_jam['arr_jam_selesai'] as $jam)
                      <option value="{{ $jam }}" {{ $jam_siswa['jam_selesai'] == $jam ? 'selected' : '' }}>{{ $jam }}</option>
                    @endforeach
                  </select>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      @endforeach
      </tbody>
    </table>
    <button class="btn btn-primary float-right">Simpan</button>
  </form>
@else
  <div class="text-center alert alert-info mb-0">
    <i class="mdi mdi-information-outline" style="font-size: 42px"></i>
    <p class="mb-2 font-weight-bold">Data siswa tidak tersedia!</p>
    <p class="border-bottom mb-2" style="border-color: rgba(0, 0, 0, 0.15) !important;"></p>
    <p class="mb-0">Data siswa aktif yang bertempat di <b>{{ $info->nama_penempatan }}</b> dengan instrumen <b>{{ $info->nama_instrumen }}</b> tidak tersedia!</p>
  </div>
@endif