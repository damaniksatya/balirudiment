<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GajiStaffAbsenKerja extends Model
{
  protected $table = 'gaji_staff_absen_kerja';
  public $timestamps = false;

  public static function getData($id_gaji_staff, $bulan)
  {
    return self::where('id_gaji_staff', $id_gaji_staff)
      ->where('bulan', $bulan)
      ->first();
  }

  public static function insertOrUpdate($data)
  {
    $exists = self::where('id_gaji_staff', $data['id_gaji_staff'])
      ->where('bulan', $data['bulan'])
      ->exists();

    if($exists) self::updateData($data);
    else self::insertData($data);
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_gaji_staff', $data['id_gaji_staff'])
      ->where('bulan', $data['bulan'])
      ->update($data);
  }

  public static function deleteData($id_gaji_staff)
  {
    self::where('id_gaji_staff', $id_gaji_staff)->delete();
  }
}
