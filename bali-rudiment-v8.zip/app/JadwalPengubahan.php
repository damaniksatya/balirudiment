<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JadwalPengubahan extends Model
{
  protected $table = 'jadwal_pengubahan';
  public $timestamps = false;

  const S_MENUNGGU_KONFIRMASI = 'MENUNGGU KONFIRMASI';
  const S_DIKONFIRMASI = 'DIKONFIRMASI';
  const S_DITOLAK = 'DITOLAK';

  public static $color = [
    self::S_MENUNGGU_KONFIRMASI => 'primary',
    self::S_DIKONFIRMASI => 'success',
    self::S_DITOLAK => 'danger',
  ];

  public static function getInfo($id)
  {
    $info = self::where('id_jadwal_pengubahan', $id)->first();
    $info->siswa = Siswa::getInfoByIdSiswa($info->id_siswa);
    $info->jadwal_sebelum = Jadwal::getInfo($info->id_jadwal_sebelum);
    $info->jadwal_setelah = Jadwal::getInfo($info->id_jadwal_setelah);
    return $info;
  }

  public static function getDataBySiswa($status = null)
  {
    $id_siswa = Siswa::getIdSiswa();
    if($status == null){
      $get = self::where('id_siswa', $id_siswa)->orderBy('id_jadwal_pengubahan','DESC')->get();
    }
    else{
      $get = self::where('id_siswa', $id_siswa)->where('status', $status)->orderBy('id_jadwal_pengubahan','DESC')->get();
    }

    foreach($get as $index=>$g){
      $get[$index]['jadwal_sebelum'] = Jadwal::getInfo($g->id_jadwal_sebelum);
      $get[$index]['jadwal_setelah'] = Jadwal::getInfo($g->id_jadwal_setelah);
    }

    return $get;
  }

  public static function getDataByStatus($status)
  {
    $get = self::where('status', $status)->get();

    foreach($get as $index=>$g){
      $get[$index]['siswa'] = Siswa::getInfoByIdSiswa($g->id_siswa);
      $get[$index]['jadwal_sebelum'] = Jadwal::getInfo($g->id_jadwal_sebelum);
      $get[$index]['jadwal_setelah'] = Jadwal::getInfo($g->id_jadwal_setelah);
    }

    return $get;
  }

  public static function getJumlahMenungguKonfirmasi()
  {
    return self::where('status', self::S_MENUNGGU_KONFIRMASI)->count();
  }
  
  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_jadwal_pengubahan', $data['id_jadwal_pengubahan'])->update($data);
  }
}
