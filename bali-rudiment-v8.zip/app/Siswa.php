<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Siswa extends Model
{
  protected $table = 'siswa';
  public $timestamps = false;

  const J_LAKI_LAKI = 'LAKI-LAKI';
  const J_PEREMPUAN = 'PEREMPUAN';

  const T_KANAN = 'KANAN';
  const T_KIRI = 'KIRI';

  public static $jenis_kelamin = [
    self::J_LAKI_LAKI,
    self::J_PEREMPUAN,
  ];

  public static $tangan_dominan = [
    self::T_KANAN,
    self::T_KIRI
  ];

  public static $color = [
    self::J_LAKI_LAKI => 'primary',
    self::J_PEREMPUAN => 'purple',
    self::T_KANAN => 'primary',
    self::T_KIRI => 'purple',
    '' => ''
  ];

  public static function getInfo($id_pengguna)
  {
    return self::leftJoin('pengguna as p','p.id','=','siswa.id_pengguna')
      ->leftJoin('penempatan as pp','pp.id_penempatan','=','siswa.id_penempatan')
      ->leftJoin('kelas as k','k.id_kelas','=','siswa.id_kelas')
      ->leftJoin('instrumen as i','i.id_instrumen','=','siswa.id_instrumen')
      ->where('siswa.id_pengguna', $id_pengguna)
      ->first();
  }

  public static function getInfoByIdSiswa($id_siswa)
  {
    return self::leftJoin('pengguna as p','p.id','=','siswa.id_pengguna')
      ->leftJoin('penempatan as pp','pp.id_penempatan','=','siswa.id_penempatan')
      ->leftJoin('kelas as k','k.id_kelas','=','siswa.id_kelas')
      ->leftJoin('instrumen as i','i.id_instrumen','=','siswa.id_instrumen')
      ->where('siswa.id_siswa', $id_siswa)
      ->first();
  }

  public static function getNamaSiswa($id_siswa)
  {
    $get = self::where('id_siswa', $id_siswa)->first();
    return $get ? $get->nama_siswa : null;
  }

  public static function getData()
  {
    return self::leftJoin('pengguna as p','p.id','=','siswa.id_pengguna')
      ->leftJoin('penempatan as pp','pp.id_penempatan','=','siswa.id_penempatan')
      ->leftJoin('kelas as k','k.id_kelas','=','siswa.id_kelas')
      ->leftJoin('instrumen as i','i.id_instrumen','=','siswa.id_instrumen')
      ->get();
  }

  public static function getDataByArrId($arr_id)
  {
    return self::leftJoin('pengguna as p','p.id','=','siswa.id_pengguna')
      ->whereIn('siswa.id_siswa', $arr_id)
      ->where('p.status', User::S_AKTIF)
      ->get();
  }

  public static function getArrIdByPenempatanInstrumen($id_penempatan, $id_instrumen, $not_in_id)
  {
    return self::where('id_penempatan', $id_penempatan)
      ->where('id_instrumen', $id_instrumen)
      ->whereNotIn('id_siswa', $not_in_id)
      ->pluck('id_siswa')->toArray();
  }

  public static function getJumlahAktif()
  {
    return self::leftJoin('pengguna as p','p.id','=','siswa.id_pengguna')
      ->where('p.status', User::S_AKTIF)
      ->count();
  }

  public static function getIdSiswa()
  {
    if(Auth::user()){
      $get = self::where('id_pengguna', Auth::user()->id)->first();
      return $get ? $get->id_siswa : null;
    }
    else return null;
  }

  public static function getInfoSiswaLogin()
  {
    if(Auth::user()){
      return self::where('id_pengguna', Auth::user()->id)->first();
    }
    else return null;
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_pengguna', $data['id_pengguna'])->update($data);
  }
}
