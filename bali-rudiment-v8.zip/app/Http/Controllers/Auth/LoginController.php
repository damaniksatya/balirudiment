<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;

class LoginController extends Controller
{
  use AuthenticatesUsers;
  protected $redirectTo = '/home';

  public function __construct()
  {
    $this->middleware('guest')->except('logout');
  }

  public function showLoginForm()
  {
    return view('pages.auth.login');
  }

  public function username()
  {
    $login = request()->input('username');
    $field = 'username';
    request()->merge([$field => $login]);
    return $field;
  }

  public function login(Request $request)
  {
    $this->validateLogin($request);
    if ($this->hasTooManyLoginAttempts($request)) {
      $this->fireLockoutEvent($request);

      return $this->sendLockoutResponse($request);
    }

    if ($this->guard()->validate($this->credentials($request))) {
      $user = $this->guard()->getLastAttempted();
      $user->active = true;
      $get = User::getInfoByUsername($request->username);
      if($get){
        $user->active = $get->status == User::S_AKTIF;
      }
      if ($user->active && $this->attemptLogin($request)) {
//        dd($get);
        return $this->sendLoginResponse($request);
      }
      else {
        $this->incrementLoginAttempts($request);
        return back()->withInput()->withErrors(['username' => 'Akun anda telah dinonaktifkan!']);
      }
    }

    $this->incrementLoginAttempts($request);

    return $this->sendFailedLoginResponse($request);
  }

  protected function loggedOut(Request $request)
  {
    return redirect('login');
  }

  protected function sendFailedLoginResponse(Request $request)
  {
    $errors = ['username' => ['Username / password tidak valid!']];
    return back()->withErrors($errors)->withInput();
  }
}
