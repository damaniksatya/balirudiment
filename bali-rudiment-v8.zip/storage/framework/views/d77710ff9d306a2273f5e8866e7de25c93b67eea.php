<select name="id_instrumen" id="id_instrumen" class="form-control select2" title="Instrumen" onchange="getItemStudio()">
  <?php if(isset($id_instruktur)): ?>
    <option value="">Pilih Instrumen</option>
  <?php else: ?>
    <option value="">Pilih Instruktur terlebih dahulu</option>
  <?php endif; ?>
  <?php if(isset($data_instrumen)): ?>
    <?php $__currentLoopData = $data_instrumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($l->id_instrumen); ?>" <?php echo e((isset($id_instrumen) ? $id_instrumen : null) == $l->id_instrumen ? 'selected' : ''); ?>><?php echo e($l->nama_instrumen); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
</select>