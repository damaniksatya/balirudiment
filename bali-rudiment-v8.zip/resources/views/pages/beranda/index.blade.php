@extends('layouts.main')

@section('title','Beranda')

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row justify-content-center">
            <div class="col-lg-8">
              <h4 class="page-title">Beranda</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body text-center pt-5">
            <img src="{{ url('images/logo.jpg') }}" alt="Logo" width="120px">
            <p class="px-lg-5 pt-3">
              <h5 class="px-lg-5">
                Selamat datang
              </h5>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection

@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
@endsection