<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kelas extends Model
{
  protected $table = 'kelas';
  public $timestamps = false;

  const DEBUT = 'DEBUT';
  const GROUP_CLASS = 'GROUP CLASS';
  const DEBUT_INTERNATIONAL = 'DEBUT INTERNATIONAL';
  const REGULAR = 'REGULAR';
  const REGULAR_INTERNATIONAL = 'INTERNATIONAL';
  const SPECIAL_NEED = 'SPECIAL NEED';
  const MASTERCLASS = 'MASTER CLASS';

  public static $kelas = [
    self::DEBUT,
    self::GROUP_CLASS,
    self::DEBUT_INTERNATIONAL,
    self::REGULAR,
    self::REGULAR_INTERNATIONAL,
    self::SPECIAL_NEED,
    self::MASTERCLASS,
  ];

  public static function getInfo($id)
  {
    return self::where('id_kelas', $id)->first();
  }

  public static function getData()
  {
    return self::all();
  }

  public static function getJumlah()
  {
    return self::count();
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_kelas', $data['id_kelas'])->update($data);
  }

  public static function deleteData($id)
  {
    self::where('id_kelas', $id)->delete();
  }
}
