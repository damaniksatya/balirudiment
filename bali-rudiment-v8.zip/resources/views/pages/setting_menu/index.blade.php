@extends('layouts.main')

@section('title','Setting Menu')

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="page-title-right mt-2 pt-1">
          </div>
          <h4 class="page-title">Setting Menu</h4>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <div class="table-responsive">
              <table id="datatable" class="table mb-0 table-sm table-bordered table-hover">
                <thead>
                <tr>
                  <th class="text-center" style="width: 40px">No</th>
                  <th class="">Level User</th>
                  <th>Aksi</th>
                  <th class="text-center no-sort">Status</th>
                  <th style="width: 70px" class="no-sort"></th>
                </tr>
                </thead>
                <tbody>
                @php $no = 1 @endphp
                @foreach($data as $index_user=>$level_user)
                  @foreach($level_user['aksi'] as $index_aksi=>$aksi)
                    @php $is_aktif = $aksi['status'] == \App\SettingMenu::S_AKTIF; @endphp
                    <tr>
                      <td class="text-center">{{ $no++ }}</td>
                      <td class="">{{ $level_user['level_user'] }}</td>
                      <td class="">{{ $aksi['aksi'] }}</td>
                      <td class="text-center">
                        <span style="padding-top: 5px; display: {{ $is_aktif ? 'inline-block' : 'none' }}" id="badge-aktif{{ $no }}"
                              class="badge badge-{{ \App\SettingMenu::$color[\App\SettingMenu::S_AKTIF] }}">
                          {{ \App\SettingMenu::S_AKTIF }}
                        </span>
                        <span style="padding-top: 5px; display: {{ !$is_aktif ? 'inline-block' : 'none' }}" id="badge-nonaktif{{ $no }}"
                              class="badge badge-{{ \App\SettingMenu::$color[\App\SettingMenu::S_NONAKTIF] }}">
                          {{ \App\SettingMenu::S_NONAKTIF }}
                        </span>
                      </td>
                      <td>
                        <button type="button" onclick="nonaktifkan('{{ $level_user['level_user'] }}','{{ $aksi['aksi'] }}','{{ $no }}')"
                                style="display: {{ $is_aktif ? 'block' : 'none' }};" id="btn-nonaktif{{ $no }}"
                                class="btn btn-block btn-sm btn-outline-danger px-1 my-0">Nonaktifkan</button>
                        <button onclick="aktifkan('{{ $level_user['level_user'] }}','{{ $aksi['aksi'] }}','{{ $no }}')"
                                style="display: {{ $is_aktif ? 'none' : 'block' }};" id="btn-aktif{{ $no }}"
                                type="button" class="btn btn-block btn-sm btn-outline-primary px-1 my-0">Aktifkan</button>
                      </td>
                    </tr>
                  @endforeach
                @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection
@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script>
    function nonaktifkan(level_user, aksi, no) {
        $.ajax({
            url: '{{ url('setting-menu/status') }}',
            type: 'put',
            data: {
                _token: '{{ csrf_token() }}',
                level_user: level_user,
                aksi: aksi,
                status: '{{ \App\SettingMenu::S_NONAKTIF }}',
            },
            success: function(data) {
                $(`#badge-aktif${no}`).hide();
                $(`#badge-nonaktif${no}`).show();
                $(`#btn-aktif${no}`).show();
                $(`#btn-nonaktif${no}`).hide();
            },
            error: async function(data) {
                swal({
                    title: 'Gagal',
                    text: "Terjadi kesalahan sistem",
                    type: 'error',
                    confirmButtonColor: '#306397'
                });
            },
        });
    }
    function aktifkan(level_user, aksi, no) {
        $.ajax({
            url: '{{ url('setting-menu/status') }}',
            type: 'put',
            data: {
                _token: '{{ csrf_token() }}',
                level_user: level_user,
                aksi: aksi,
                status: '{{ \App\SettingMenu::S_AKTIF }}',
            },
            success: function(data) {
                $(`#badge-aktif${no}`).show();
                $(`#badge-nonaktif${no}`).hide();
                $(`#btn-aktif${no}`).hide();
                $(`#btn-nonaktif${no}`).show();
            },
            error: async function(data) {
                swal({
                    title: 'Gagal',
                    text: "Terjadi kesalahan sistem",
                    type: 'error',
                    confirmButtonColor: '#306397'
                });
            },
        });
    }
  </script>
@endsection