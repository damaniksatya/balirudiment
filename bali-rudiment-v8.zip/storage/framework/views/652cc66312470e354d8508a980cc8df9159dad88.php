<?php $__env->startSection('title','Data Absensi'); ?>

<?php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_absensi_siswa);
  $nonaktif_input = in_array(\App\SettingMenu::INPUT_ABSENSI_SISWA, $arr_nonaktif);
  $nonaktif_edit = in_array(\App\SettingMenu::EDIT_ABSENSI_SISWA, $arr_nonaktif);
?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              <div class="page-title-right mt-2 pt-1">
                <?php if(!$nonaktif_input): ?>
                  <a href="<?php echo e(url('absensi/add')); ?>" class="btn btn-primary">
                    <i class="mdi mdi-plus mr-2"></i>Input Data Absensi
                  </a>
                <?php endif; ?>
              </div>
              <h4 class="page-title">Data Absensi</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <form class="form-horizontal" method="get">
              <div class="form-group row mb-0">
                <label class="col-lg-3 text-right col-form-label" for="bulan">Bulan</label>
                <div class="col-lg-9">
                  <select name="bulan" id="bulan" class="form-control select2" onchange="this.form.submit()">
                    <option value="">Pilih Bulan</option>
                    <?php $__currentLoopData = $data_bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($bln); ?>" <?php echo e($bln == $bulan ? 'selected' : ''); ?>><?php echo e(\App\Http\Controllers\HelperController::setNamaBulan($bln)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <table class="table table-sm table-bordered mb-0">
                <thead>
                <tr>
                  <th>Hari, Tanggal</th>
                  <th class="text-center">Jam</th>
                  <th class="text-center">Durasi</th>
                  <th>Studio</th>
                  <th>Instrumen</th>
                  <th class="text-center">Fee</th>
                  <th class="text-center">Status</th>
                  <th class="text-center" style="width: 100px">Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($d->hari); ?>, <?php echo e(\App\Http\Controllers\HelperController::setNamaBulan(null, $d->tanggal)); ?></td>
                    <td class="text-center"><?php echo e($d->jadwal->jam_mulai .'-'. $d->jadwal->jam_selesai); ?></td>
                    <td class="text-center"><?php echo e($d->durasi_mengajar); ?> Menit</td>
                    <td><?php echo e($d->jadwal->nama_studio); ?></td>
                    <td><?php echo e($d->jadwal->nama_instrumen); ?></td>
                    <?php if($d->status == \App\Absensi::S_DIKONFIRMASI): ?>
                      <td class="text-right"><?php echo e(number_format($d->fee, 0, ',', '.')); ?></td>
                      <td class="text-center">
                        <span class="badge badge-<?php echo e(\App\Absensi::$color[$d->status]); ?>" style="padding-top: 5px"><?php echo e($d->status); ?></span>
                      </td>
                    <?php else: ?>
                      <td class="text-center" colspan="2">
                        <span class="badge badge-<?php echo e(\App\Absensi::$color[$d->status]); ?>" style="padding-top: 5px"><?php echo e($d->status); ?></span>
                      </td>
                    <?php endif; ?>
                    <td class="p-1">
                      <div class="btn-group btn-block">
                        <a href="<?php echo e(url('absensi/detail/'.$d->id_absensi.'?back_url='.\Illuminate\Support\Facades\Route::current()->uri)); ?>"
                           class="btn btn-sm btn-outline-primary">Detail</a>
                        <?php if(!$nonaktif_edit): ?>
                          <a href="<?php echo e(url('absensi/edit/'.$d->id_absensi.'?back_url='.\Illuminate\Support\Facades\Route::current()->uri)); ?>"
                             class="btn btn-sm btn-primary">Edit</a>
                        <?php endif; ?>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>