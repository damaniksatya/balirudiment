<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JadwalHarian extends Model
{
  protected $table = 'jadwal_harian';
  protected $primaryKey = 'id_jadwal_harian';
  public $timestamps = false;

  const MINUTE_STEP = 30;

  public static $jam_ke = [
    '10:00',
    '10:30',
    '11:00',
    '11:30',
    '12:00',
    '12:30',
    '13:00',
    '13:30',
    '14:00',
    '14:30',
    '15:00',
    '15:30',
    '16:00',
    '16:30',
    '17:00',
    '17:30',
    '18:00',
    '18:30',
    '19:00',
    '19:30',
  ];

  public static $jam_selesai = [
    '10:30',
    '11:00',
    '11:30',
    '12:00',
    '12:30',
    '13:00',
    '13:30',
    '14:00',
    '14:30',
    '15:00',
    '15:30',
    '16:00',
    '16:30',
    '17:00',
    '17:30',
    '18:00',
    '18:30',
    '19:00',
    '19:30',
    '20:00',
  ];

  public static $arr_keterangan = [
    ['background' => '#D32F2F', 'text' => 'Siswa Baru'],
    ['background' => '#F57C00', 'text' => 'Siswa Trial'],
    ['background' => '#FBC02D', 'text' => 'Pergantian'],
    ['background' => '#1976D2', 'text' => 'Extra Lesson'],
    ['background' => '#7B1FA2', 'text' => 'Parents Meeting'],
    ['background' => '#388E3C', 'text' => 'Sewa Studio'],
  ];

  public static function getInfo($tanggal, $id_penempatan)
  {
    return self::where('tanggal', $tanggal)
      ->where('id_penempatan', $id_penempatan)
      ->first();
  }

  public static function insertOrUpdate($data)
  {
    $info = self::where('id_penempatan', $data['id_penempatan'])
      ->where('tanggal', $data['tanggal'])
      ->first();

    if($info){
      $info->note = $data['note'];
      $info->note2 = $data['note2'];
      $info->data = $data['data'];
      $info->merge = $data['merge'];
      $info->cells = $data['cells'];
      $info->column = $data['column'];
      $info->style = $data['style'];
      $info->save();
    }
    else{
      self::insert($data);
    }
  }

  public static function deleteData($id_penempatan, $tanggal)
  {
    self::where('id_penempatan', $id_penempatan)
      ->where('tanggal', $tanggal)
      ->delete();
  }
}
