<div class="form-group row">
  <label class="col-lg-3 text-right col-form-label" for="id_jadwal_setelah">Durasi Mengajar</label>
  <label class="col-lg-9 text-left col-form-label"><?php echo e($durasi_mengajar); ?> Menit</label>
  <input type="hidden" name="durasi_mengajar" value="<?php echo e($durasi_mengajar); ?>">
</div>
<?php if(isset($data_siswa)): ?>
  <?php if(count($data_siswa)): ?>
    <div class="form-group row">
      <div class="col-lg-12">
        <table class="table table-bordered mb-0">
          <thead>
          <tr>
            <th>Nama Siswa</th>
            <th colspan="4" class="text-center">Kehadiran</th>
          </tr>
          </thead>
          <tbody>
          <?php $arr_id_siswa = []; ?>
          <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $arr_id_siswa[] = $d['id_siswa']; ?>
            <tr>
              <td><label class="form-check-label"><?php echo e($d['nama_siswa']); ?></label></td>
              <td>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="kehadiran<?php echo e($d['id_siswa']); ?>" style="cursor: pointer"
                         id="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_HADIR); ?>" value="<?php echo e(\App\Absensi::K_HADIR); ?>" checked>
                  <label class="form-check-label" for="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_HADIR); ?>" style="cursor: pointer">
                    <?php echo e(ucwords(strtolower(\App\Absensi::K_HADIR))); ?>

                  </label>
                </div>
              </td>
              <td>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="kehadiran<?php echo e($d['id_siswa']); ?>" style="cursor: pointer"
                         id="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_IZIN); ?>" value="<?php echo e(\App\Absensi::K_IZIN); ?>">
                  <label class="form-check-label" for="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_IZIN); ?>" style="cursor: pointer">
                    <?php echo e(ucwords(strtolower(\App\Absensi::K_IZIN))); ?>

                  </label>
                </div>
              </td>
              <td>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="kehadiran<?php echo e($d['id_siswa']); ?>" style="cursor: pointer"
                         id="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_SAKIT); ?>" value="<?php echo e(\App\Absensi::K_SAKIT); ?>">
                  <label class="form-check-label" for="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_SAKIT); ?>" style="cursor: pointer">
                    <?php echo e(ucwords(strtolower(\App\Absensi::K_SAKIT))); ?>

                  </label>
                </div>
              </td>
              <td>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="kehadiran<?php echo e($d['id_siswa']); ?>" style="cursor: pointer"
                         id="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_TIDAK_HADIR); ?>" value="<?php echo e(\App\Absensi::K_TIDAK_HADIR); ?>">
                  <label class="form-check-label" for="kehadiran<?php echo e($d['id_siswa']); ?><?php echo e(\App\Absensi::K_TIDAK_HADIR); ?>" style="cursor: pointer">
                    <?php echo e(ucwords(strtolower(\App\Absensi::K_TIDAK_HADIR))); ?>

                  </label>
                </div>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

        <input type="hidden" name="id_siswa" value="<?php echo e(json_encode($arr_id_siswa)); ?>">
      </div>
    </div>

  <?php else: ?>
    <p class="text-center mb-0">Data siswa tidak tersedia!</p>
  <?php endif; ?>
<?php endif; ?>