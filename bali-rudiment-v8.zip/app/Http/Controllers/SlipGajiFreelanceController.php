<?php

namespace App\Http\Controllers;

use App\GajiFreelance;
use App\GajiFreelanceAbsenKerja;
use App\GajiFreelanceMengajar;
use App\Instruktur;
use App\JadwalSiswa;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class SlipGajiFreelanceController extends Controller
{
  private $id_gaji;

  public function index()
  {
    if(Auth::user()->level_user == User::L_GENERAL_ADMIN){
      $data_bulan = GajiFreelance::getArrBulan();
      $bulan = HelperController::getValue('gaji_freelance',['bulan'])['bulan'];
      $data = GajiFreelance::getData($bulan);

      return view('pages.slip_gaji.freelance.index')
        ->with('bulan', $bulan)
        ->with('data_bulan', $data_bulan)
        ->with('data', $data);
    }
    else{
      $id_instruktur = Instruktur::getIdInstruktur();
      $data = GajiFreelance::getDataByIdInstruktur($id_instruktur);

      return view('pages.slip_gaji.freelance.index_instruktur')
        ->with('data', $data);
    }
  }

  public function viewAdd()
  {
    $data_instruktur = Instruktur::getData(Instruktur::JI_FREELANCE);

    return view('pages.slip_gaji.freelance.add')
      ->with('data_instruktur', $data_instruktur);
  }

  public function viewEdit($id_gaji)
  {
    $info = GajiFreelance::getInfo($id_gaji);
    $data = GajiFreelanceMengajar::getData($id_gaji);
//    dd($info, $data);
    return view('pages.slip_gaji.freelance.edit')
      ->with('info', $info)
      ->with('data', $data);
  }

  public function getComponentMengajar(Request $req)
  {
    $data = JadwalSiswa::getJadwalUntukSlipGajiFreelance($req->id_instruktur, $req->bulan);
//    return $data;
    return view('components.slip_gaji.freelance.mengajar')
      ->with('data', $data);
  }

  public function store(Request $req)
  {
//    dd($req);
    DB::transaction(function () use ($req){
      $this->id_gaji = GajiFreelance::insertData([
        'id_instruktur' => $req->id_instruktur,
        'bulan' => $req->bulan,
        'total_mengajar' => $req->total_fee ?: 0,
        'ensemble_jml_hari' => $req->ensemble_jml_hari ?: 0,
        'ensemble_per_hari' => $req->ensemble_per_hari ?: 0,
        'ensemble' => $req->ensemble ?: 0,
        'ensemble_note' => $req->ensemble_note,
        'trial_jml_hari' => $req->trial_jml_hari ?: 0,
        'trial_per_hari' => $req->trial_per_hari ?: 0,
        'trial' => $req->trial ?: 0,
        'trial_note' => $req->trial_note,
        'extra_lesson_jml_hari' => $req->extra_lesson_jml_hari ?: 0,
        'extra_lesson_per_hari' => $req->extra_lesson_per_hari ?: 0,
        'extra_lesson' => $req->extra_lesson ?: 0,
        'extra_lesson_note' => $req->extra_lesson_note,
        'kinerja_jml_hari' => $req->kinerja_jml_hari ?: 0,
        'kinerja_per_hari' => $req->kinerja_per_hari ?: 0,
        'kinerja' => $req->kinerja ?: 0,
        'kinerja_note' => $req->kinerja_note,
        'week_20_hours_jml_hari' => $req->week_20_hours_jml_hari ?: 0,
        'week_20_hours_per_hari' => $req->week_20_hours_per_hari ?: 0,
        'week_20_hours' => $req->week_20_hours ?: 0,
        'week_20_hours_note' => $req->week_20_hours_note,
        'konser_jml_hari' => $req->konser_jml_hari ?: 0,
        'konser_per_hari' => $req->konser_per_hari ?: 0,
        'konser' => $req->konser ?: 0,
        'konser_note' => $req->konser_note,
        'set_up_konser_jml_hari' => $req->set_up_konser_jml_hari ?: 0,
        'set_up_konser_per_hari' => $req->set_up_konser_per_hari ?: 0,
        'set_up_konser' => $req->set_up_konser ?: 0,
        'set_up_konser_note' => $req->set_up_konser_note,
        'set_down_konser_jml_hari' => $req->set_down_konser_jml_hari ?: 0,
        'set_down_konser_per_hari' => $req->set_down_konser_per_hari ?: 0,
        'set_down_konser' => $req->set_down_konser ?: 0,
        'set_down_konser_note' => $req->set_down_konser_note,
        'set_up_bw_jml_hari' => $req->set_up_bw_jml_hari ?: 0,
        'set_up_bw_per_hari' => $req->set_up_bw_per_hari ?: 0,
        'set_up_bw' => $req->set_up_bw ?: 0,
        'set_up_bw_note' => $req->set_up_bw_note,
        'set_down_bw_jml_hari' => $req->set_down_bw_jml_hari ?: 0,
        'set_down_bw_per_hari' => $req->set_down_bw_per_hari ?: 0,
        'set_down_bw' => $req->set_down_bw ?: 0,
        'set_down_bw_note' => $req->set_down_bw_note,
        'total' => $req->sub_total ?: 0,
        'kasbon' => $req->kasbon ?: 0,
        'grand_total' => $req->grand_total ?: 0,
      ]);

      for($i=0; $i<$req->total_row; $i++){
        $temp = [
          'id' => $req["id$i"],
          'id_gaji_freelance' => $this->id_gaji,
          'nama_siswa' => $req["nama_siswa$i"],
          'jumlah_pertemuan' => $req["jumlah_pertemuan$i"],
          'fee' => $req["fee$i"],
          'total_fee' => $req["total_fee$i"],
          'kelas' => $req["kelas$i"],
          'notes' => $req["notes$i"],
        ];

        if($req["nama_siswa$i"] || $req["jumlah_pertemuan$i"] || $req["fee$i"] || $req["total_fee$i"] || $req["kelas$i"] || $req["notes$i"]){
          if($req["id$i"]){
            GajiFreelanceMengajar::updateData($temp);
          }
          else{
            GajiFreelanceMengajar::insertData($temp);
          }
        }
        elseif($req["id$i"] != null){
          GajiFreelanceMengajar::deleteData($temp);
        }
      }

    });

    if($req->back_url){
      return redirect($req->back_url)->with('success','Berhasil menyimpan data');
    }
    else{
      return redirect("slip-gaji/freelance/absensi/$this->id_gaji");
    }
  }

  public function update(Request $req)
  {
    DB::transaction(function () use ($req){
      GajiFreelance::updateData([
        'id_gaji' => $req->id_gaji,
        'total_mengajar' => $req->total_fee ?: 0,
        'ensemble_jml_hari' => $req->ensemble_jml_hari ?: 0,
        'ensemble_per_hari' => $req->ensemble_per_hari ?: 0,
        'ensemble' => $req->ensemble ?: 0,
        'ensemble_note' => $req->ensemble_note,
        'trial_jml_hari' => $req->trial_jml_hari ?: 0,
        'trial_per_hari' => $req->trial_per_hari ?: 0,
        'trial' => $req->trial ?: 0,
        'trial_note' => $req->trial_note,
        'extra_lesson_jml_hari' => $req->extra_lesson_jml_hari ?: 0,
        'extra_lesson_per_hari' => $req->extra_lesson_per_hari ?: 0,
        'extra_lesson' => $req->extra_lesson ?: 0,
        'extra_lesson_note' => $req->extra_lesson_note,
        'kinerja_jml_hari' => $req->kinerja_jml_hari ?: 0,
        'kinerja_per_hari' => $req->kinerja_per_hari ?: 0,
        'kinerja' => $req->kinerja ?: 0,
        'kinerja_note' => $req->kinerja_note,
        'week_20_hours_jml_hari' => $req->week_20_hours_jml_hari ?: 0,
        'week_20_hours_per_hari' => $req->week_20_hours_per_hari ?: 0,
        'week_20_hours' => $req->week_20_hours ?: 0,
        'week_20_hours_note' => $req->week_20_hours_note,
        'konser_jml_hari' => $req->konser_jml_hari ?: 0,
        'konser_per_hari' => $req->konser_per_hari ?: 0,
        'konser' => $req->konser ?: 0,
        'konser_note' => $req->konser_note,
        'set_up_konser_jml_hari' => $req->set_up_konser_jml_hari ?: 0,
        'set_up_konser_per_hari' => $req->set_up_konser_per_hari ?: 0,
        'set_up_konser' => $req->set_up_konser ?: 0,
        'set_up_konser_note' => $req->set_up_konser_note,
        'set_down_konser_jml_hari' => $req->set_down_konser_jml_hari ?: 0,
        'set_down_konser_per_hari' => $req->set_down_konser_per_hari ?: 0,
        'set_down_konser' => $req->set_down_konser ?: 0,
        'set_down_konser_note' => $req->set_down_konser_note,
        'set_up_bw_jml_hari' => $req->set_up_bw_jml_hari ?: 0,
        'set_up_bw_per_hari' => $req->set_up_bw_per_hari ?: 0,
        'set_up_bw' => $req->set_up_bw ?: 0,
        'set_up_bw_note' => $req->set_up_bw_note,
        'set_down_bw_jml_hari' => $req->set_down_bw_jml_hari ?: 0,
        'set_down_bw_per_hari' => $req->set_down_bw_per_hari ?: 0,
        'set_down_bw' => $req->set_down_bw ?: 0,
        'set_down_bw_note' => $req->set_down_bw_note,
        'total' => $req->sub_total ?: 0,
        'kasbon' => $req->kasbon ?: 0,
        'grand_total' => $req->grand_total ?: 0,
      ]);

      for($i=0; $i<$req->total_row; $i++){
        $temp = [
          'id' => $req["id$i"],
          'id_gaji_freelance' => $req->id_gaji,
          'nama_siswa' => $req["nama_siswa$i"],
          'jumlah_pertemuan' => $req["jumlah_pertemuan$i"],
          'fee' => $req["fee$i"],
          'total_fee' => $req["total_fee$i"],
          'kelas' => $req["kelas$i"],
          'notes' => $req["notes$i"],
        ];

        if($req["nama_siswa$i"] || $req["jumlah_pertemuan$i"] || $req["fee$i"] || $req["total_fee$i"] || $req["kelas$i"] || $req["notes$i"]){
          if($req["id$i"]){
            GajiFreelanceMengajar::updateData($temp);
          }
          else{
            GajiFreelanceMengajar::insertData($temp);
          }
        }
        elseif($req["id$i"] != null){
          GajiFreelanceMengajar::deleteData($temp);
        }
      }

    });

    if($req->back_url){
      return redirect($req->back_url)->with('success','Berhasil menyimpan data');
    }
    else{
      return redirect("slip-gaji/freelance/absensi/$req->id_gaji");
    }
  }

  public function storeAbsensi(Request $req)
  {
    $arr_tgl = (array)json_decode($req->arr_tgl);
    $arr_kehadiran = [];
    $arr_note = [];

    foreach($arr_tgl as $tgl){
      $arr_kehadiran[] = $req["kehadiran-$tgl"];
      $arr_note[] = $req["note-$tgl"];
    }

    GajiFreelanceAbsenKerja::insertOrUpdate([
      'id_gaji_freelance' => $req->id_gaji_freelance,
      'bulan' => $req->bulan,
      'tanggal' => json_encode($arr_tgl),
      'kehadiran' => json_encode($arr_kehadiran),
      'note' => json_encode($arr_note),
    ]);

//    dd($req, $arr_tgl);
    return redirect('slip-gaji/freelance')->with('success','Berhasil menyimpan data');
  }

  public function viewEditAbsensi($id_gaji)
  {
    $info = GajiFreelance::getInfo($id_gaji);
    $arr_tgl = $this->getArrTgl($info->bulan);
    $data = $this->getDataAbsensi($id_gaji, $arr_tgl);
//    dd($info, $data, $arr_tgl);

    return view('pages.slip_gaji.freelance.absensi')
      ->with('data', $data)
      ->with('arr_tgl', $arr_tgl)
      ->with('info', $info);
  }

  public function printSlipGaji($id_gaji)
  {
    $info = GajiFreelance::getInfo($id_gaji);
    $arr_tgl = $this->getArrTgl($info->bulan);
    $absensi = $this->getDataAbsensi($id_gaji, $arr_tgl);
    $data = [
      'gaji' => $info,
      'mengajar' => GajiFreelanceMengajar::getData($id_gaji),
      'absensi' => $absensi,
      'nama_bulan' => HelperController::setNamaBulan($info->bulan)
    ];
//    dd($data);
    $pdf = \App::make('dompdf.wrapper');
    $pdf->setPaper('a4', 'portrait');
    $pdf->loadView('pdf.slip_gaji_freelance', $data);
    return $pdf->stream("Slip Gaji Instruktur Freelance.pdf");
  }

  public function delete(Request $req)
  {
    DB::transaction(function () use ($req){
      GajiFreelance::deleteData($req->id_gaji);
      GajiFreelanceMengajar::deleteByIdGaji($req->id_gaji);
      GajiFreelanceAbsenKerja::deleteData($req->id_gaji);
    });

    return back()->with('success','Berhasil menghapus data');
  }

  private function getArrTgl($bln)
  {
    $arr_tgl = [];

    for($i=1; $i<=31; $i++){
      $tgl = sprintf("%02d", $i);
      $tgl = date('Y-m-d', ((int)strtotime($bln.'-'.$tgl)));
      if(date('Y-m', strtotime($tgl)) == $bln){
        $arr_tgl[] = date('d', strtotime($tgl));
      }
    }

    return $arr_tgl;
  }

  private function getDataAbsensi($id_gaji, $arr_tgl)
  {
    $get = GajiFreelanceAbsenKerja::getInfo($id_gaji);
    $arr_kehadiran = $get ? (array)json_decode($get->kehadiran) : [];
    $arr_note = $get ? (array)json_decode($get->note) : [];
    $temp = [];

    foreach($arr_tgl as $index=>$tgl){
      $temp[$tgl] = [
        'kehadiran' => array_key_exists($index, $arr_kehadiran) ? $arr_kehadiran[$index] : null,
        'note' => array_key_exists($index, $arr_note) ? $arr_note[$index] : null,
      ];
    }

    $data = [
      'data' => $temp,
      'note' => $get ? $get->note : null
    ];

    return $data;
  }
}
