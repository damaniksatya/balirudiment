<?php $__env->startSection('title','Input Data Slip Gaji Staff'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(url('slip-gaji/staff')); ?>">Slip Gaji Staff</a></li>
                  <li class="breadcrumb-item active">Input</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="<?php echo e(url('slip-gaji/staff')); ?>">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input Slip Gaji Staff
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="<?php echo e(url('slip-gaji/staff')); ?>">
            <?php echo csrf_field(); ?>
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="dari_bulan">Bulan</label>
                <div class="col-lg-9">
                  <table style="width: 100%">
                    <tr>
                      <td>
                        <input type="month" id="dari_bulan" title="Dari bulan" name="dari_bulan"
                               value="<?php echo e(old('dari_bulan') ?: date('Y-m')); ?>" class="form-control" required>
                      </td>
                      <td class="text-center px-2">Sampai</td>
                      <td>
                        <input type="month" id="sampai_bulan" title="Sampai bulan" name="sampai_bulan"
                               value="<?php echo e(old('sampai_bulan') ?: date('Y-m')); ?>" class="form-control" required>
                      </td>
                    </tr>
                  </table>

                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="nama_staff">Nama Staff</label>
                <div class="col-lg-9">
                  <input type="text" id="nama_staff" name="nama_staff" value="<?php echo e(old('nama_staff')); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row mb-0">
                <label class="col-lg-3 text-right col-form-label" for="jabatan">Jabatan</label>
                <div class="col-lg-9">
                  <input type="text" id="jabatan" name="jabatan" value="<?php echo e(old('jabatan')); ?>" class="form-control" required>
                </div>
              </div>
            </div>
            <div class="card-body pb-0">
              <table class="table table-sm table-bordered mb-0">
                <thead>
                <tr>
                  <th>Keterangan</th>
                  <th class="text-center" style="width: 70px">Jumlah</th>
                  <th class="text-center" style="width: 150px">Nominal</th>
                  <th class="text-center">Total</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>Gaji Pokok</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Gaji Pokok"
                           name="gaji_pokok_jml_hari" value="<?php echo e(old('gaji_pokok_jml_hari')); ?>" oninput="calculateGaji()">
                    <input type="hidden" name="gaji_pokok" id="gaji_pokok_hidden" value="<?php echo e(old('gaji_pokok')); ?>">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Gaji Pokok Per Hari"
                           name="gaji_pokok_per_hari" value="<?php echo e(old('gaji_pokok_per_hari')); ?>" oninput="calculateGaji()">
                  </td>
                  <td id="gaji_pokok_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Tunjangan Harian</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Tunjangan Harian"
                           name="tunj_harian_jml_hari" value="<?php echo e(old('tunj_harian_jml_hari')); ?>" oninput="calculateGaji()">
                    <input type="hidden" name="tunj_harian" id="tunj_harian_hidden" value="<?php echo e(old('tunj_harian')); ?>">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Tunjangan Harian Per Hari"
                           name="tunj_harian_per_hari" value="<?php echo e(old('tunj_harian_per_hari')); ?>" oninput="calculateGaji()">
                  </td>
                  <td id="tunj_harian_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Transport</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Transport"
                           name="transport_jml_hari" value="<?php echo e(old('transport_jml_hari')); ?>" oninput="calculateGaji()">
                    <input type="hidden" name="transport" id="transport_hidden" value="<?php echo e(old('transport')); ?>">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Transport Per Hari"
                           name="transport_per_hari" value="<?php echo e(old('transport_per_hari')); ?>" oninput="calculateGaji()">
                  </td>
                  <td id="transport_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Tunjangan Tambahan</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Tunjangan Tambahan"
                           name="tunj_tambahan_jml_hari" value="<?php echo e(old('tunj_tambahan_jml_hari')); ?>" oninput="calculateGaji()">
                    <input type="hidden" name="tunj_tambahan" id="tunj_tambahan_hidden" value="<?php echo e(old('tunj_tambahan')); ?>">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Tunjangan Tambahan Per Hari"
                           name="tunj_tambahan_per_hari" value="<?php echo e(old('tunj_tambahan_per_hari')); ?>" oninput="calculateGaji()">
                  </td>
                  <td id="tunj_tambahan_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Bonus</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Bonus"
                           name="bonus_jml_hari" value="<?php echo e(old('bonus_jml_hari')); ?>" oninput="calculateGaji()">
                    <input type="hidden" name="bonus" id="bonus_hidden" value="<?php echo e(old('bonus')); ?>">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Bonus Per Hari"
                           name="bonus_per_hari" value="<?php echo e(old('bonus_per_hari')); ?>" oninput="calculateGaji()">
                  </td>
                  <td id="bonus_text" class="text-right"></td>
                </tr>
                <tr>
                  <td class="text-right font-weight-bold" colspan="3">Total</td>
                  <td class="text-right font-weight-bold">
                    <span id="total_1_text"></span>
                    <input type="hidden" name="total_1" id="total_1_hidden">
                  </td>
                </tr>
                <tr>
                  <td>Libur Cuti</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Libur Cuti"
                           name="libur_jml_hari" value="<?php echo e(old('libur_jml_hari')); ?>" oninput="calculateGaji()">
                    <input type="hidden" name="libur" id="libur_hidden" value="<?php echo e(old('libur')); ?>">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Libur Cuti Per Hari"
                           name="libur_per_hari" value="<?php echo e(old('libur_per_hari')); ?>" oninput="calculateGaji()">
                  </td>
                  <td id="libur_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Sakit / Izin</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Sakit / Izin"
                           name="sakit_jml_hari" value="<?php echo e(old('sakit_jml_hari')); ?>" oninput="calculateGaji()">
                    <input type="hidden" name="sakit" id="sakit_hidden" value="<?php echo e(old('sakit')); ?>">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Sakit / Izin Per Hari"
                           name="sakit_per_hari" value="<?php echo e(old('sakit_per_hari')); ?>" oninput="calculateGaji()">
                  </td>
                  <td id="sakit_text" class="text-right"></td>
                </tr>
                <tr>
                  <td colspan="2">Kasbon</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Kasbon"
                           name="kasbon" value="<?php echo e(old('kasbon')); ?>" oninput="calculateGaji()">
                  </td>
                  <td id="kasbon_text" class="text-right"></td>
                </tr>
                <tr>
                  <td class="text-right font-weight-bold" colspan="3">Total</td>
                  <td class="text-right font-weight-bold">
                    <span id="total_2_text"></span>
                    <input type="hidden" name="total_2" id="total_2_hidden">
                  </td>
                </tr>
                <tr>
                  <td>Lembur/Jam</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Jam Lembur"
                           name="lembur_jam_jml_jam" value="<?php echo e(old('lembur_jam_jml_jam')); ?>" oninput="calculateGaji()">
                    <input type="hidden" name="lembur_jam" id="lembur_jam_hidden" value="<?php echo e(old('lembur_jam')); ?>">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Lembur Per Jam"
                           name="lembur_jam_per_jam" value="<?php echo e(old('lembur_jam_per_jam')); ?>" oninput="calculateGaji()">
                  </td>
                  <td id="lembur_jam_text" class="text-right"></td>
                </tr>
                <tr>
                  <td>Lembur Harian</td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Jumlah Hari Lembur"
                           name="lembur_hari_jml_hari" value="<?php echo e(old('lembur_hari_jml_hari')); ?>" oninput="calculateGaji()">
                    <input type="hidden" name="lembur_hari" id="lembur_hari_hidden" value="<?php echo e(old('lembur_hari')); ?>">
                  </td>
                  <td class="p-1">
                    <input type="number" class="form-control form-control-sm text-right" title="Lembur Per Hari"
                           name="lembur_hari_per_hari" value="<?php echo e(old('lembur_hari_per_hari')); ?>" oninput="calculateGaji()">
                  </td>
                  <td id="lembur_hari_text" class="text-right"></td>
                </tr>
                <tr>
                  <td class="text-right font-weight-bold" colspan="3">Sub Total</td>
                  <td class="text-right font-weight-bold">
                    <span id="sub_total_text"></span>
                    <input type="hidden" name="sub_total" id="sub_total_hidden">
                  </td>
                </tr>
                <tr style="background: #FFFF00">
                  <td class="text-right font-weight-bold" colspan="3">Total Penerimaan</td>
                  <td class="text-right font-weight-bold">
                    <span id="total_penerimaan_text"></span>
                    <input type="hidden" name="total_penerimaan" id="total_penerimaan_hidden">
                  </td>
                </tr>
                </tbody>
              </table>
            </div>
            <div class="card-body">
              <div class="form-group row mb-0">
                <label class="col-lg-3 text-right col-form-label" for="notes">Notes</label>
                <div class="col-lg-9">
                  <textarea name="notes" id="notes" class="form-control" rows="5"><?php echo e(old('notes')); ?></textarea>
                </div>
              </div>
            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>

  <style>
    /* Chrome, Safari, Edge, Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }

    /* Firefox */
    input[type=number] {
      -moz-appearance: textfield;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();

      function calculateGaji() {
          let gaji_pokok_jml_hari = getValue('gaji_pokok_jml_hari');
          let gaji_pokok_per_hari = getValue('gaji_pokok_per_hari');
          let tunj_harian_jml_hari = getValue('tunj_harian_jml_hari');
          let tunj_harian_per_hari = getValue('tunj_harian_per_hari');
          let transport_jml_hari = getValue('transport_jml_hari');
          let transport_per_hari = getValue('transport_per_hari');
          let tunj_tambahan_jml_hari = getValue('tunj_tambahan_jml_hari');
          let tunj_tambahan_per_hari = getValue('tunj_tambahan_per_hari');
          let bonus_jml_hari = getValue('bonus_jml_hari');
          let bonus_per_hari = getValue('bonus_per_hari');
          let libur_jml_hari = getValue('libur_jml_hari');
          let libur_per_hari = getValue('libur_per_hari');
          let sakit_jml_hari = getValue('sakit_jml_hari');
          let sakit_per_hari = getValue('sakit_per_hari');
          let lembur_jam_jml_jam = getValue('lembur_jam_jml_jam');
          let lembur_jam_per_jam = getValue('lembur_jam_per_jam');
          let lembur_hari_jml_hari = getValue('lembur_hari_jml_hari');
          let lembur_hari_per_hari = getValue('lembur_hari_per_hari');

          let gaji_pokok = gaji_pokok_jml_hari * gaji_pokok_per_hari;
          let tunj_harian = tunj_harian_jml_hari * tunj_harian_per_hari;
          let transport = transport_jml_hari * transport_per_hari;
          let tunj_tambahan = tunj_tambahan_jml_hari * tunj_tambahan_per_hari;
          let bonus = bonus_jml_hari * bonus_per_hari;
          let libur = libur_jml_hari * libur_per_hari;
          let sakit = sakit_jml_hari * sakit_per_hari;
          let lembur_jam = lembur_jam_jml_jam * lembur_jam_per_jam;
          let lembur_hari = lembur_hari_jml_hari * lembur_hari_per_hari;

          let kasbon = getValue('kasbon');

          let total_1 = gaji_pokok + tunj_harian + transport + tunj_tambahan + bonus;
          let total_2 = total_1 - (libur + sakit + kasbon);
          let sub_total = total_2 + lembur_jam + lembur_hari;
          let total_penerimaan = sub_total;

          $("#gaji_pokok_text").text(gaji_pokok ? formatNumber(gaji_pokok) : '');
          $("#gaji_pokok_hidden").val(gaji_pokok);
          $("#tunj_harian_text").text(tunj_harian ? formatNumber(tunj_harian) : '');
          $("#tunj_harian_hidden").val(tunj_harian);
          $("#transport_text").text(transport ? formatNumber(transport) : '');
          $("#transport_hidden").val(transport);
          $("#tunj_tambahan_text").text(tunj_tambahan ? formatNumber(tunj_tambahan) : '');
          $("#tunj_tambahan_hidden").val(tunj_tambahan);
          $("#bonus_text").text(bonus ? formatNumber(bonus) : '');
          $("#bonus_hidden").val(bonus);
          $("#libur_text").text(libur ? formatNumber(libur) : '');
          $("#libur_hidden").val(libur);
          $("#sakit_text").text(sakit ? formatNumber(sakit) : '');
          $("#sakit_hidden").val(sakit);
          $("#lembur_jam_text").text(lembur_jam ? formatNumber(lembur_jam) : '');
          $("#lembur_jam_hidden").val(lembur_jam);
          $("#lembur_hari_text").text(lembur_hari ? formatNumber(lembur_hari) : '');
          $("#lembur_hari_hidden").val(lembur_hari);
          $("#kasbon_text").text(kasbon ? formatNumber(kasbon) : '');

          $("#total_1_text").text(total_1 ? formatNumber(total_1) : '');
          $("#total_1_hidden").val(total_1);
          $("#total_2_text").text(total_2 ? formatNumber(total_2) : '');
          $("#total_2_hidden").val(total_2);
          $("#sub_total_text").text(sub_total ? formatNumber(sub_total) : '');
          $("#sub_total_hidden").val(sub_total);
          $("#total_penerimaan_text").text(total_penerimaan ? formatNumber(total_penerimaan) : '');
          $("#total_penerimaan_hidden").val(total_penerimaan);
      }
      function getValue(name) {
          let value = $(`[name=${name}]`).val();
          if(value && !isNaN(value*1)){
              return value*1;
          }
          else return 0;
      }
      function formatNumber(number, with_rp = false, fraction_digits = 0) {
          let text = (number).toLocaleString('id-ID', { minimumFractionDigits: fraction_digits });
          return (with_rp ? 'Rp ' : '') + text;
      }

  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>