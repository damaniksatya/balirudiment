<form action="<?php echo e(url('jadwal/jam-mengajar')); ?>" method="post">
  <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
  <input type="hidden" name="id_jadwal" value="<?php echo e($id_jadwal); ?>">
  <input type="hidden" name="id_siswa" value="<?php echo e($id_siswa); ?>">
  <table class="table table-sm">
    <tbody>
    <?php $__currentLoopData = $data_jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td class="<?php echo e(!$index ? 'border-top-0' : ''); ?>">
          <label class="col-form-label"><?php echo e(\App\Http\Controllers\HelperController::setNamaBulan(null, $d->tanggal)); ?></label>
        </td>
        <td class="<?php echo e(!$index ? 'border-top-0' : ''); ?>" style="vertical-align: middle !important;">
          <select name="jam_mulai<?php echo e($d->id_jadwal_siswa); ?>" id="jam_mulai<?php echo e($d->id_jadwal_siswa); ?>"
                  class="form-control form-control-sm" title="Jam Mulai" required>
            <option value="">Pilih Jam Mulai</option>
            <?php $__currentLoopData = $data_jam['arr_jam_mulai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($jam); ?>" <?php echo e($d->jam_mulai == $jam ? 'selected' : ''); ?>><?php echo e($jam); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </td>
        <td class="font-12 <?php echo e(!$index ? 'border-top-0' : ''); ?>" style="vertical-align: middle !important;">Sampai</td>
        <td class="<?php echo e(!$index ? 'border-top-0' : ''); ?>" style="vertical-align: middle !important;">
          <select name="jam_selesai<?php echo e($d->id_jadwal_siswa); ?>" id="jam_selesai<?php echo e($d->id_jadwal_siswa); ?>"
                  class="form-control form-control-sm" title="Jam Selesai" required>
            <option value="">Pilih Jam Selesai</option>
            <?php $__currentLoopData = $data_jam['arr_jam_selesai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($jam); ?>" <?php echo e($d->jam_selesai == $jam ? 'selected' : ''); ?>><?php echo e($jam); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <button class="btn btn-primary float-right">Simpan</button>
</form>