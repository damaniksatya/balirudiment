<?php

namespace App\Http\Controllers;

use App\Admin;
use App\Penempatan;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
  public function index()
  {
    $data = Admin::getData();
//    dd($data);
    return view('pages.admin.index')
      ->with('data', $data);
  }

  public function viewAdd()
  {
    $data_penempatan = Penempatan::getData();

    return view('pages.admin.add')
      ->with('data_penempatan', $data_penempatan);
  }

  public function viewEdit($id_pengguna)
  {
    $info = Admin::getInfo($id_pengguna);
    $data_penempatan = Penempatan::getData();
//    dd($info);
    return view('pages.admin.edit')
      ->with('info', $info)
      ->with('data_penempatan', $data_penempatan);
  }

  public function viewEditProfile()
  {
    $id_pengguna = Auth::user()->id;
    $info = Admin::getInfo($id_pengguna);
//    dd($info);
    return view('pages.admin.profile')
      ->with('info', $info);
  }

  public function store(Request $req)
  {
    $this->validateData();

    DB::transaction(function () use ($req){
      $id_pengguna = User::insertData([
        'nama' => $req->nama,
        'username' => $req->username,
        'password' => bcrypt($req->password),
        'foto_profile' => $this->storeImageFile(),
        'level_user' => $req->level_user,
        'status' => User::S_AKTIF
      ]);

      Admin::insertData([
        'id_pengguna' => $id_pengguna,
        'nama_admin' => $req->nama,
        'id_penempatan' => $req->id_penempatan
      ]);
    });

    return back()->with('success','Berhasil menyimpan data');
  }

  public function update(Request $req)
  {
    DB::transaction(function () use ($req){
      $new_username = $req->username != $req->username_old;
      $new_password = $req->password != null;
      $this->validateData($new_username, $new_password);

      $data_pengguna = [
        'id' => $req->id_pengguna,
        'nama' => $req->nama,
        'username' => $req->username,
        'level_user' => $req->level_user,
      ];
      if($new_password){
        $data_pengguna['password'] = bcrypt($req->password);
      }
      if(request()->file('foto_profile')){
        $data_pengguna['foto_profile'] = $this->storeImageFile();
        $this->deleteFile($req->foto_profile_old);
      }

      User::updateData($req->id_pengguna, $data_pengguna);

      Admin::updateData([
        'id_pengguna' => $req->id_pengguna,
        'nama_admin' => $req->nama,
        'id_penempatan' => $req->id_penempatan
      ]);
    });

    return redirect('admin')->with('success','Berhasil menyimpan data');
  }

  public function updateProfile(Request $req)
  {

    DB::transaction(function () use ($req){
      $new_username = $req->username != $req->username_old;
      $this->validateData($new_username, false);

      $data_pengguna = [
        'id' => $req->id_pengguna,
        'username' => $req->username,
      ];
      if(request()->file('foto_profile')){
        $data_pengguna['foto_profile'] = $this->storeImageFile();
        $this->deleteFile($req->foto_profile_old);
      }

      User::updateData($req->id_pengguna, $data_pengguna);

      Admin::updateData([
        'id_pengguna' => $req->id_pengguna,
        'penempatan' => $req->penempatan
      ]);
    });

    return back()->with('success','Berhasil menyimpan data');
  }

  public function updateStatus(Request $req)
  {
    User::updateData($req->id, [
      'status' => $req->status
    ]);

    return back()->with('success','Berhasil menyimpan data');
  }

  private function validateData($new_username = true, $new_password = true)
  {
    return request()->validate([
      'nama' => 'required|max:80',
      'username' => 'required|max:30|min:3'.($new_username ? '|unique:pengguna' : ''),
      'password' => $new_password ? 'required|min:6' : '',
      'level_user' => 'required',
    ],[
      'nama.required' => 'Nama Admin harus diisi!',
      'nama.max' => 'Nama maksimal :max karakter!',
      'username.required' => 'Username harus diisi!',
      'username.max' => 'Username maksimal :max karakter!',
      'username.min' => 'Username minimal :min karakter!',
      'username.unique' => 'Username telah digunakan!',
      'password.required' => 'Kata Sandi harus diisi!',
      'password.min' => 'Kata Sandi minimal :min karakter!',
      'level_user.required' => 'Tingkatan Admin harus dipilih!',
    ]);
  }

  private function storeImageFile($location = 'storage/foto_profile')
  {
    if(request()->file('foto_profile')){
      $file = request()->file('foto_profile');
      $ext = $file->getClientOriginalExtension();
      $name = time() .'.' . $ext;
      $file->move(public_path() . "/$location", $name);
      return $location.'/'.$name;
    }
    else{
      return null;
    }
  }

  private function deleteFile($nama)
  {
    File::delete("public/$nama");
  }
}
