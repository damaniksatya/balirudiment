<?php
  $list_menu = \App\SettingMenu::getListMenu(\App\User::L_ADMIN);
  $arr_disable_menu = \App\SettingMenu::getAksiNonaktif(\App\User::L_ADMIN, $list_menu);
?>

<ul class="metismenu" id="side-menu">
  <li class="text-center">
    <img src="<?php echo e(url('images/logo.jpg')); ?>" alt="Logo" width="60px" class="mt-2">
    <p class="menu-title">Bali Rudiment</p>
  </li>
  <li class="dropdown-divider"></li>
  <li>
    <a href="<?php echo e(url('home')); ?>">
      <i class="mdi mdi-home"></i>
      <span> Beranda </span>
    </a>
  </li>
  <li style="display: <?php echo e(in_array(\App\SettingMenu::MENU_ADMIN, $arr_disable_menu) ? 'none' : 'list-item'); ?>">
    <a href="<?php echo e(url('admin')); ?>">
      <i class="mdi mdi-account"></i>
      <span> Admin </span>
    </a>
  </li>
  <li style="display: <?php echo e(in_array(\App\SettingMenu::MENU_ACCOUNTING, $arr_disable_menu) ? 'none' : 'list-item'); ?>">
    <a href="<?php echo e(url('accounting')); ?>">
      <i class="mdi mdi-account-cash"></i>
      <span> Accounting </span>
    </a>
  </li>
  <li style="display: <?php echo e(in_array(\App\SettingMenu::MENU_INSTRUKTUR, $arr_disable_menu) ? 'none' : 'list-item'); ?>">
    <a href="<?php echo e(url('instruktur')); ?>">
      <i class="mdi mdi-account-tie"></i>
      <span> Instruktur </span>
    </a>
  </li>
  <li style="display: <?php echo e(in_array(\App\SettingMenu::MENU_SISWA, $arr_disable_menu) ? 'none' : 'list-item'); ?>">
    <a href="<?php echo e(url('siswa')); ?>">
      <i class="mdi mdi-school"></i>
      <span> Siswa </span>
    </a>
  </li>
  <li style="display: <?php echo e(in_array(\App\SettingMenu::MENU_INSTRUMEN, $arr_disable_menu) ? 'none' : 'list-item'); ?>">
    <a href="<?php echo e(url('instrumen')); ?>">
      <i class="mdi mdi-guitar-acoustic"></i>
      <span> Instrumen </span>
    </a>
  </li>
  <li style="display: <?php echo e(in_array(\App\SettingMenu::MENU_KELAS, $arr_disable_menu) ? 'none' : 'list-item'); ?>">
    <a href="<?php echo e(url('kelas')); ?>">
      <i class="mdi mdi-account-music"></i>
      <span> Kelas </span>
    </a>
  </li>
  <li style="display: <?php echo e(in_array(\App\SettingMenu::MENU_STUDIO, $arr_disable_menu) ? 'none' : 'list-item'); ?>">
    <a href="<?php echo e(url('studio')); ?>">
      <i class="mdi mdi-office-building"></i>
      <span> Studio </span>
    </a>
  </li>
  <li style="display: <?php echo e(in_array(\App\SettingMenu::MENU_PENEMPATAN, $arr_disable_menu) ? 'none' : 'list-item'); ?>">
    <a href="<?php echo e(url('penempatan')); ?>">
      <i class="mdi mdi-map-marker"></i>
      <span> Penempatan </span>
    </a>
  </li>

  <?php
    $menu_jadwal_mengajar = in_array(\App\SettingMenu::MENU_JADWAL_MENGAJAR, $arr_disable_menu);
    $menu_jadwal_harian = in_array(\App\SettingMenu::MENU_JADWAL_HARIAN, $arr_disable_menu);
  ?>

  <li style="display: <?php echo e($menu_jadwal_mengajar && $menu_jadwal_harian ? 'none' : 'list-item'); ?>">
    <a href="javascript: void(0);">
      <i class="mdi mdi-timer-sand"></i>
      <span> Data Jadwal </span>
      <span class="menu-arrow"></span>
    </a>
    <ul class="nav-second-level mm-collapse" aria-expanded="false">
      <li style="display: <?php echo e($menu_jadwal_mengajar ? 'none' : 'list-item'); ?>">
        <a href="<?php echo e(url('jadwal')); ?>">
          Jadwal Mengajar
        </a>
      </li>
      <li style="display: <?php echo e($menu_jadwal_harian ? 'none' : 'list-item'); ?>">
        <a href="<?php echo e(url('jadwal-harian')); ?>">
          Jadwal Harian
        </a>
      </li>
    </ul>
  </li>

  <?php $jumlah_menunggu_konfirmasi = \App\JadwalPengubahan::getJumlahMenungguKonfirmasi() ?>
  <li style="display: <?php echo e(in_array(\App\SettingMenu::MENU_PENGUBAHAN_JADWAL, $arr_disable_menu) ? 'none' : 'list-item'); ?>">
    <a href="javascript: void(0);">
      <i class="mdi mdi-pencil"></i>
      <span> Pengubahan Jadwal </span>
      <?php if($jumlah_menunggu_konfirmasi >= 1): ?>
        <span class="badge badge-danger" style="padding-top: 5px; padding-left: 4px"><?php echo e($jumlah_menunggu_konfirmasi); ?></span>
      <?php endif; ?>
      <span class="menu-arrow"></span>
    </a>
    <ul class="nav-second-level mm-collapse" aria-expanded="false">
      <li>
        <a href="<?php echo e(url('pengubahan-jadwal/menunggu-konfirmasi')); ?>">
          Menunggu Konfirmasi
          <?php if($jumlah_menunggu_konfirmasi >= 1): ?>
            <span class="badge badge-danger" style="padding-top: 5px"><?php echo e($jumlah_menunggu_konfirmasi); ?></span>
          <?php endif; ?>
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('pengubahan-jadwal/dikonfirmasi')); ?>">
          Dikonfirmasi
        </a>
      </li>
    </ul>
  </li>


  <?php
    $menu_absensi_siswa = in_array(\App\SettingMenu::MENU_ABSENSI_SISWA, $arr_disable_menu);
    $jumlah_menunggu_konfirmasi = !$menu_absensi_siswa ? \App\Absensi::getJumlahMenungguKonfirmasi() : 0;
  ?>
  <li style="display: <?php echo e($menu_absensi_siswa ? 'none' : 'list-item'); ?>">
    <a href="javascript: void(0);">
      <i class="mdi mdi-fingerprint"></i>
      <span> Absensi </span>
      <?php if($jumlah_menunggu_konfirmasi >= 1): ?>
        <span class="badge badge-danger" style="padding-top: 5px; padding-left: 4px"><?php echo e($jumlah_menunggu_konfirmasi); ?></span>
      <?php endif; ?>
      <span class="menu-arrow"></span>
    </a>
    <ul class="nav-second-level mm-collapse" aria-expanded="false">
      <li>
        <a href="<?php echo e(url('absensi/menunggu-konfirmasi')); ?>">
          Menunggu Konfirmasi
          <?php if($jumlah_menunggu_konfirmasi >= 1): ?>
            <span class="badge badge-danger" style="padding-top: 5px"><?php echo e($jumlah_menunggu_konfirmasi); ?></span>
          <?php endif; ?>
        </a>
      </li>
      <li>
        <a href="<?php echo e(url('absensi/dikonfirmasi')); ?>">
          Dikonfirmasi
        </a>
      </li>
    </ul>
  </li>


  <?php
    $menu_gaji_staff = in_array(\App\SettingMenu::MENU_SLIP_GAJI_STAFF, $arr_disable_menu);
    $menu_gaji_fulltime = in_array(\App\SettingMenu::MENU_SLIP_GAJI_INSTRUKTUR_FULLTIME, $arr_disable_menu);
    $menu_gaji_freelance = in_array(\App\SettingMenu::MENU_SLIP_GAJI_INSTRUKTUR_FREELANCE, $arr_disable_menu);
  ?>
  <li style="display: <?php echo e($menu_gaji_staff && $menu_gaji_fulltime && $menu_gaji_freelance ? 'none' : 'list-item'); ?>">
    <a href="javascript: void(0);">
      <i class="mdi mdi-file"></i>
      <span> Slip Gaji </span>
      <span class="menu-arrow"></span>
    </a>
    <ul class="nav-second-level mm-collapse" aria-expanded="false">
      <li style="display: <?php echo e($menu_gaji_staff ? 'none' : 'list-item'); ?>">
        <a href="<?php echo e(url('slip-gaji/staff')); ?>">
          Staff
        </a>
      </li>
      <li style="display: <?php echo e($menu_gaji_fulltime ? 'none' : 'list-item'); ?>">
        <a href="<?php echo e(url('slip-gaji/fulltime')); ?>">
          Instruktur Full Time
        </a>
      </li>
      <li style="display: <?php echo e($menu_gaji_freelance ? 'none' : 'list-item'); ?>">
        <a href="<?php echo e(url('slip-gaji/freelance')); ?>">
          Instruktur Freelance
        </a>
      </li>
    </ul>


</ul>