<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Accounting extends Model
{
  protected $table = 'accounting';
  public $timestamps = false;

  const J_LAKI_LAKI = 'LAKI-LAKI';
  const J_PEREMPUAN = 'PEREMPUAN';

  public static $jenis_kelamin = [
    self::J_LAKI_LAKI,
    self::J_PEREMPUAN,
  ];

  public static $color = [
    self::J_LAKI_LAKI => 'primary',
    self::J_PEREMPUAN => 'purple',
  ];

  public static function getData()
  {
    return self::leftJoin('pengguna as p','p.id','=','accounting.id_pengguna')
      ->get();
  }

  public static function getInfo($id_pengguna)
  {
    return self::leftJoin('pengguna as p','p.id','=','accounting.id_pengguna')
      ->where('accounting.id_pengguna', $id_pengguna)
      ->first();
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_pengguna', $data['id_pengguna'])->update($data);
  }
}
