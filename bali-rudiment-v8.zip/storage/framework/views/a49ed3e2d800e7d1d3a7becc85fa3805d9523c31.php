<?php $__env->startSection('title','Bali Rudiment'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-8 col-lg-6 col-xl-5">
        <div class="account-card-box">
          <div class="card mb-0" style="border-color: #263238">
            <div class="card-body p-4">

              <div class="text-center">
                <div class="my-3">
                  <span><img src="<?php echo e(url('images/logo.jpg')); ?>" alt="Logo" width="120px" style="border-radius: 7px"></span>
                </div>
                <h5 class="py-3 font-16">Bali Rudiment</h5>
              </div>

              <form method="POST" action="<?php echo e(route('login')); ?>" class="mt-2">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                  <input type="text" id="username" name="username" value="<?php echo e(old('username')); ?>"
                         class="form-control" placeholder="Masukkan Username" required>
                </div>

                <div class="form-group mb-3">
                  <input type="password" id="password" name="password" value="<?php echo e(old('password')); ?>"
                         class="form-control" placeholder="Masukkan kata sandi" required>
                </div>

                <div class="form-group text-center mb-0">
                  <button class="btn btn-outline-primary btn-block waves-effect waves-light" type="submit"> Login </button>
                </div>
              </form>

            </div>
          </div>
        </div>
        <p class="text-center text-white mt-3"><?php echo e(date('Y')); ?> &copy; Bali Rudiment</p>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script>
      function disableAutoComplete() {
          $("#username").val('');
          $("#password").val('');
      }

      setTimeout(disableAutoComplete, 500);
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>