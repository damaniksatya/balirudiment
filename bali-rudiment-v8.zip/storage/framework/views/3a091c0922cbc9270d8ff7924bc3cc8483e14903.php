<?php $__env->startSection('title','Input Data Siswa'); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/dropify/css/dropify.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right">
                <ol class="breadcrumb m-0">
                  <li class="breadcrumb-item"><a href="<?php echo e(url('siswa')); ?>">Siswa</a></li>
                  <li class="breadcrumb-item active">Input</li>
                </ol>
              </div>
              <h4 class="page-title">
                <a href="<?php echo e(url('siswa')); ?>">
                  <i class="mdi mdi-arrow-left mr-1 text-primary"></i>
                </a>
                Input Siswa
              </h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <form class="form-horizontal" method="post" action="<?php echo e(url('siswa')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card-body pb-0">
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="nama_siswa">Nama</label>
                <div class="col-lg-9">
                  <input type="text" id="nama_siswa" name="nama_siswa" value="<?php echo e(old('nama_siswa')); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_penempatan">Penempatan</label>
                <div class="col-lg-9">
                  <select name="id_penempatan" id="id_penempatan" class="form-control select2">
                    <option value="">Pilih Penempatan</option>
                    <?php $__currentLoopData = $data_penempatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($d->id_penempatan); ?>" <?php echo e(old('id_penempatan') == $d->id_penempatan ? 'selected' : ''); ?>><?php echo e($d->nama_penempatan); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_kelas">Kelas</label>
                <div class="col-lg-9">
                  <select name="id_kelas" id="id_kelas" class="form-control select2">
                    <option value="">Pilih Kelas</option>
                    <?php $__currentLoopData = $data_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($d->id_kelas); ?>" <?php echo e(old('id_kelas') == $d->id_kelas ? 'selected' : ''); ?>><?php echo e($d->nama_kelas); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="id_instrumen">Instrumen</label>
                <div class="col-lg-9">
                  <select name="id_instrumen" id="id_instrumen" class="form-control select2">
                    <option value="">Pilih Instrumen</option>
                    <?php $__currentLoopData = $data_instrumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($d->id_instrumen); ?>" <?php echo e(old('id_instrumen') == $d->id_instrumen ? 'selected' : ''); ?>><?php echo e($d->nama_instrumen); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="email_siswa">Email Siswa</label>
                <div class="col-lg-9">
                  <input type="text" id="email_siswa" name="email_siswa" value="<?php echo e(old('email_siswa')); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="tanggal_lahir">Tanggal Lahir</label>
                <div class="col-lg-9">
                  <input type="text" id="tanggal_lahir" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir')); ?>" class="form-control datepicker" autocomplete="off" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="sekolah">Sekolah</label>
                <div class="col-lg-9">
                  <input type="text" id="sekolah" name="sekolah" value="<?php echo e(old('sekolah')); ?>" class="form-control">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="jenis_kelamin">Jenis Kelamin</label>
                <div class="col-lg-9">
                  <select name="jenis_kelamin" id="jenis_kelamin" class="form-control select2">
                    <option value="">Pilih Jenis Kelamin</option>
                    <?php $__currentLoopData = \App\Siswa::$jenis_kelamin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($l); ?>" <?php echo e(old('jenis_kelamin') == $l ? 'selected' : ''); ?>><?php echo e($l); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="alamat">Alamat</label>
                <div class="col-lg-9">
                  <textarea name="alamat" id="alamat" class="form-control" required rows="5"><?php echo e(old('alamat')); ?></textarea>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="email_orangtua">Email Orang Tua</label>
                <div class="col-lg-9">
                  <input type="text" id="email_orangtua" name="email_orangtua" value="<?php echo e(old('email_orangtua')); ?>" class="form-control">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="no_hp_orangtua">No HP Orang Tua</label>
                <div class="col-lg-9">
                  <input type="text" id="no_hp_orangtua" name="no_hp_orangtua" value="<?php echo e(old('no_hp_orangtua')); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="tangan_dominan">Tangan Dominan</label>
                <div class="col-lg-9">
                  <select name="tangan_dominan" id="tangan_dominan" class="form-control select2">
                    <option value="">Pilih Tangan Dominan</option>
                    <?php $__currentLoopData = \App\Siswa::$tangan_dominan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($l); ?>" <?php echo e(old('tangan_dominan') == $l ? 'selected' : ''); ?>><?php echo e($l); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="username">Username Login</label>
                <div class="col-lg-9">
                  <input type="text" id="username" name="username" value="<?php echo e(old('username')); ?>" class="form-control" required>
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="password">Password</label>
                <div class="col-lg-9">
                  <input type="password" id="password" name="password" class="form-control" autocomplete="off">
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="foto_profile">Foto Profil</label>
                <div class="col-lg-9">
                  <input type="file"
                         name="foto_profile"
                         class="dropify dropify-photo"
                         data-height="150"
                         data-show-remove="false"
                         data-allowed-file-extensions="jpg jpeg png"
                         data-max-file-size="1M"
                         accept=".jpg, .jpeg, .png" />
                </div>
              </div>
              <div class="form-group row">
                <label class="col-lg-3 text-right col-form-label" for="sosial-media">Sosial Media</label>
                <div class="col-lg-9">
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-20" id="instagram" style="padding: 2px 10px"><i class="mdi mdi-instagram"></i></span>
                    </div>
                    <input type="text" id="instagram" name="instagram" value="<?php echo e(old('instagram')); ?>" class="form-control" title="Instagram">
                  </div>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-20" id="twitter" style="padding: 2px 10px"><i class="mdi mdi-twitter"></i></span>
                    </div>
                    <input type="text" id="twitter" name="twitter" value="<?php echo e(old('twitter')); ?>" class="form-control" title="Twitter">
                  </div>
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-20" id="facebook" style="padding: 2px 10px"><i class="mdi mdi-facebook"></i></span>
                    </div>
                    <input type="text" id="facebook" name="facebook" value="<?php echo e(old('facebook')); ?>" class="form-control" title="Facebook">
                  </div>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text font-20" id="youtube" style="padding: 2px 10px"><i class="mdi mdi-youtube"></i></span>
                    </div>
                    <input type="text" id="youtube" name="youtube" value="<?php echo e(old('youtube')); ?>" class="form-control" title="Youtube">
                  </div>
                </div>
              </div>

            </div>
            <div class="card-body pt-0 text-right">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.datepicker', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/dropify/js/dropify.min.js')); ?>"></script>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(document).ready(function(){
          $(".select2").select2();
          $('.dropify-photo').dropify({
              messages: {
                  'default': 'Drag & drop foto di sini atau klik',
                  'replace': 'Drag & drop atau klik untuk mengganti foto',
                  'error': 'Hanya format png/jpeg/jpg yang di izinkan'
              },
              error: {
                  'fileSize': 'Ukuran foto melebihi maksimal (1M max).',
              }
          });
      });
      function disableAutoComplete() {
          $("#username").val('');
          $("#password").val('');
      }

      setTimeout(disableAutoComplete, 500);
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>