@extends('layouts.main')

@section('title','Data Absensi Menunggu Konfirmasi')

@php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_absensi_siswa);
  $nonaktif_konfirmasi = in_array(\App\SettingMenu::KONFIRMASI_ABSENSI_SISWA, $arr_nonaktif);
@endphp

@section('css')
  <link rel="stylesheet" href="{{ url('plugins/select2/select2.min.css') }}"/>
@endsection

@section('content')
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              {{--<div class="page-title-right mt-2 pt-1">--}}
                {{--<a href="{{ url('absensi/add') }}" class="btn btn-primary">--}}
                  {{--<i class="mdi mdi-plus mr-2"></i>Input Data Absensi--}}
                {{--</a>--}}
              {{--</div>--}}
              <h4 class="page-title">Data Absensi Menunggu Konfirmasi</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <table class="table table-sm table-bordered mb-0">
              <thead>
              <tr>
                <th>Hari, Tanggal</th>
                <th class="text-center">Jam</th>
                <th class="text-center">Durasi</th>
                <th>Studio</th>
                <th>Instrumen</th>
                <th>Instruktur</th>
                <th class="text-center" style="width: 100px">Aksi</th>
              </tr>
              </thead>
              <tbody>
              @foreach($data as $index=>$d)
                <tr>
                  <td>{{ $d->hari }}, {{ \App\Http\Controllers\HelperController::setNamaBulan(null, $d->tanggal) }}</td>
                  <td class="text-center">{{ $d->jadwal->jam_mulai .'-'. $d->jadwal->jam_selesai }}</td>
                  <td class="text-center">{{ $d->durasi_mengajar }} Menit</td>
                  <td>{{ $d->jadwal->nama_studio }}</td>
                  <td>{{ $d->jadwal->nama_instrumen }}</td>
                  <td>{{ $d->jadwal->nama_instruktur }}</td>
                  <td class="p-1">
                    <div class="btn-group btn-block">
                      <a href="{{ url('absensi/detail/'.$d->id_absensi.'?back_url='.\Illuminate\Support\Facades\Route::current()->uri) }}"
                         class="btn btn-sm btn-outline-primary">Detail</a>
                      @if(!$nonaktif_konfirmasi)
                        <button onclick="openModalKonfirmasi('{{ $d->id_absensi }}')"
                           class="btn btn-sm btn-primary">Konfirmasi</button>
                      @endif
                    </div>
                  </td>
                </tr>
              @endforeach
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="modal-konfirmasi" tabindex="-1" role="dialog" aria-labelledby="label">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="label">Konfirmasi</h5>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body" id="modal-body">

        </div>
      </div>
    </div>
  </div>
@endsection
@section('script')
  @include('components.datatable')
  @include('components.sweet_alert')
  <script src="{{ url('plugins/select2/select2.min.js') }}"></script>
  <script>
      $(".select2").select2();

      function openModalKonfirmasi(id_absensi) {
          $.ajax({
              url: '{{ url('absensi/menunggu-konfirmasi/component/form-konfirmasi') }}',
              type: 'get',
              data: {
                  id_absensi: id_absensi,
              },
              success: function(data) {
                  $("#modal-konfirmasi").modal('show');
                  $("#modal-body").html(data);
              },
              error: async function(data) {
                  swal('Gagal','Terjadi kesalahan sistem','error');
              },
          });
      }
  </script>
@endsection