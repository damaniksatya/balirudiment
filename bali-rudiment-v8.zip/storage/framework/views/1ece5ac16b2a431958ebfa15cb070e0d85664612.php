<tr>
  <?php if($with_tgl): ?>
    <td rowspan="<?php echo e($tgl['total_siswa']); ?>"><?php echo e($tgl['hari'] .', '. \App\Http\Controllers\HelperController::setNamaBulan(null, $tgl['tanggal'])); ?></td>
  <?php endif; ?>

  <?php if($with_jadwal): ?>
    <td rowspan="<?php echo e($jadwal['total_siswa']); ?>" class="text-center"><?php echo e($jadwal['jam_mulai'] .' - '. $jadwal['jam_selesai']); ?></td>
    <td rowspan="<?php echo e($jadwal['total_siswa']); ?>"><?php echo e($jadwal['nama_studio']); ?></td>
    <td rowspan="<?php echo e($jadwal['total_siswa']); ?>" style="width: 150px"><?php echo e($jadwal['nama_instrumen']); ?></td>
    <td rowspan="<?php echo e($jadwal['total_siswa']); ?>" style="width: 150px"><?php echo e($jadwal['nama_instruktur']); ?></td>
  <?php endif; ?>

  <td><?php echo e($siswa['nama_siswa']); ?></td>
</tr>