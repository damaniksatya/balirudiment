<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JadwalSiswa extends Model
{
  protected $table = 'jadwal_siswa';
  public $timestamps = false;

  public static function getInfo($tanggal, $id_siswa, $id_jadwal)
  {
    return self::where('tanggal', $tanggal)
      ->where('id_siswa', $id_siswa)
      ->where('id_jadwal', $id_jadwal)
      ->first();
  }

  public static function getData($id_jadwal, $id_siswa)
  {
    return self::where('id_jadwal', $id_jadwal)
      ->where('id_siswa', $id_siswa)
      ->get();
  }

  public static function getSiswaByIdJadwal($id_jadwal, $tanggal = null)
  {
    $get = self::leftJoin('siswa as s','s.id_siswa','=','jadwal_siswa.id_siswa')
      ->leftJoin('pengguna as p','p.id','=','s.id_pengguna')
      ->select('jadwal_siswa.id_siswa','s.nama_siswa')
      ->where('jadwal_siswa.id_jadwal', $id_jadwal)
      ->where('p.status', User::S_AKTIF);

    if($tanggal != null){
      $get = $get->where('jadwal_siswa.tanggal', $tanggal);
    }

    return $get->groupBy('jadwal_siswa.id_siswa','s.nama_siswa')
      ->orderBy('s.nama_siswa')
      ->get()->toArray();
  }

  public static function getNamaSiswaJadwalHarian($param)
  {
//    dd($param);
    $get = self::leftJoin('jadwal as j','j.id_jadwal','=','jadwal_siswa.id_jadwal')
      ->where('j.id_instruktur', $param['id_instruktur'])
      ->where('jadwal_siswa.tanggal', $param['tanggal'])
      ->where('jadwal_siswa.jam_mulai','<=', $param['jam_mulai'])
      ->where('jadwal_siswa.jam_selesai','>=', $param['jam_selesai'])
      ->select('jadwal_siswa.id_siswa','jadwal_siswa.id_jadwal','jadwal_siswa.jam_mulai','jadwal_siswa.jam_selesai','j.id_studio')
      ->get();

    $data =[
      'nama_siswa' => null,
      'no_studio' => null,
    ];

    if(count($get)){
      $nama_siswa = [];
      foreach($get as $g){
        $data['no_studio'] = $data['no_studio'] ? $data['no_studio'] : Studio::getNoStudio($g->id_studio);
        $nama_siswa[] = Siswa::getNamaSiswa($g->id_siswa);
      }
      $data['nama_siswa'] = implode(count($nama_siswa) == 2 ? ' & ' : ', ', $nama_siswa);

    }
//    dd($data, $param, $get);

    return $data;
  }

  public static function getArrIdSiswa($id_jadwal)
  {
    return self::select('id_siswa')
      ->where('id_jadwal', $id_jadwal)
      ->groupBy('id_siswa')
      ->pluck('id_siswa')->toArray();
  }

  public static function getArrIdJadwalBySiswa($id_siswa)
  {
    return self::select('id_jadwal')
      ->where('id_siswa', $id_siswa)
      ->groupBy('id_jadwal')
      ->pluck('id_jadwal')->toArray();
  }

  public static function getJadwalSiswaUntukPengubahan()
  {
    $id_siswa = Siswa::getIdSiswa();
    $date_now = date('Y-m-d');
    $get = self::leftJoin('jadwal as j','j.id_jadwal','=','jadwal_siswa.id_jadwal')
      ->leftJoin('studio as s','s.id_studio','=','j.id_studio')
      ->leftJoin('instrumen','instrumen.id_instrumen','=','j.id_instrumen')
      ->leftJoin('instruktur','instruktur.id_instruktur','=','j.id_instruktur')
      ->select('j.id_jadwal','j.bulan','j.hari','s.nama_studio','jadwal_siswa.*','instrumen.nama_instrumen','instruktur.nama_instruktur')
      ->where('jadwal_siswa.id_siswa', $id_siswa)
      ->where('jadwal_siswa.tanggal','>=', $date_now)
      ->orderBy('jadwal_siswa.tanggal','ASC')
      ->get();

    $data_pengubahan = JadwalPengubahan::getDataBySiswa(JadwalPengubahan::S_MENUNGGU_KONFIRMASI);

    if(count($data_pengubahan)){
      $data = [];

      foreach($get as $g){
        foreach($data_pengubahan as $d){
          if(!($g->id_jadwal == $d->id_jadwal_sebelum && $g->tanggal == $d->tanggal_sebelum)){
            $data[] = $g;
          }
        }
      }
      return $data;
    }
    else return $get;
  }

  public static function getJadwalUntukSlipGaji($id_instruktur, $bulan)
  {
    $get = self::leftJoin('jadwal as j','j.id_jadwal','=','jadwal_siswa.id_jadwal')
      ->where('j.id_instruktur', $id_instruktur)
      ->where('j.bulan', $bulan)
      ->select('j.id_jadwal','j.id_instrumen','j.jam_mulai','j.jam_selesai','jadwal_siswa.id_siswa')
      ->selectRaw("COUNT(jadwal_siswa.id_jadwal_siswa) as jumlah_jadwal")
      ->groupBy('j.id_jadwal','j.id_instrumen','j.jam_mulai','j.jam_selesai','jadwal_siswa.id_siswa')
      ->get()
      ->toArray();

    $data = [];

    foreach($get as $index=>$g){
      $jml_tidak_hadir = AbsensiSiswa::getJumlahTidakHadir($g['id_jadwal'], $g['id_siswa']);
      $siswa = Siswa::getInfoByIdSiswa($g['id_siswa']);
      $instrumen = Instrumen::getInfo($g['id_instrumen']);

      $temp = [
        'id' => null,
        'nama_siswa' => $siswa['nama_siswa'],
        'durasi' => Jadwal::getDurasiMengajar($g['id_jadwal']),
        'jumlah_pertemuan' => $g['jumlah_jadwal'] - $jml_tidak_hadir,
        'debut' => in_array($siswa['nama_kelas'], ['DEBUT','DEBUT INTERNATIONAL']) ? 1 : 0,
        'regular' => $siswa['nama_kelas'] == 'REGULAR' ? 1 : 0,
        'notes' => $instrumen['nama_instrumen'],
      ];
      $data[] = $temp;
    }

    return $data;
  }

  public static function getJadwalUntukSlipGajiFreelance($id_instruktur, $bulan)
  {
    $get = self::leftJoin('jadwal as j','j.id_jadwal','=','jadwal_siswa.id_jadwal')
      ->where('j.id_instruktur', $id_instruktur)
      ->where('j.bulan', $bulan)
      ->select('j.id_jadwal','j.id_instrumen','jadwal_siswa.id_siswa')
      ->selectRaw("COUNT(jadwal_siswa.id_jadwal_siswa) as jumlah_jadwal")
      ->groupBy('j.id_jadwal','j.id_instrumen','jadwal_siswa.id_siswa')
      ->get()
      ->toArray();

    $data = [];
    foreach($get as $index=>$g){
      $jml_tidak_hadir = AbsensiSiswa::getJumlahTidakHadir($g['id_jadwal'], $g['id_siswa']);
      $jumlah_pertemuan = $g['jumlah_jadwal'] - $jml_tidak_hadir;
      $siswa = Siswa::getInfoByIdSiswa($g['id_siswa']);
      $total_fee = AbsensiSiswa::getTotalFee($g['id_jadwal'], $g['id_siswa']);

      $temp = [
        'id' => null,
        'nama_siswa' => $siswa['nama_siswa'],
        'jumlah_pertemuan' => $jumlah_pertemuan,
        'fee' => ($jumlah_pertemuan && $total_fee) ? round($total_fee / $jumlah_pertemuan, 0) : 0,
        'total_fee' => $total_fee,
        'kelas' => $siswa['nama_kelas'],
        'notes' => null
      ];
      $data[] = $temp;
    }
    return $data;
  }

  public static function getJamMulaiSelesai($id_jadwal, $id_siswa)
  {
    $get = self::where('id_jadwal', $id_jadwal)
      ->where('id_siswa', $id_siswa)
      ->selectRaw("COUNT(id_jadwal_siswa) as jumlah, jam_mulai, jam_selesai")
      ->groupBy('jam_mulai','jam_selesai')
      ->orderBy('jumlah','DESC')
      ->first();

    return [
      'jam_mulai' => $get ? $get->jam_mulai : null,
      'jam_selesai' => $get ? $get->jam_selesai : null,
    ];
  }

  public static function getArrBulanBySiswa()
  {
    $id_siswa = Siswa::getIdSiswa();
    return self::selectRaw("SUBSTRING(tanggal, 1, 7) as bulan")
      ->where('id_siswa', $id_siswa)
      ->groupBy('bulan')
      ->orderBy('bulan','DESC')
      ->pluck('bulan')
      ->toArray();
  }

  public static function getDurasi($id_jadwal, $tanggal)
  {
    $get = self::where('id_jadwal', $id_jadwal)
      ->where('tanggal', $tanggal)
      ->first();
    if($get && $get->jam_mulai && $get->jam_selesai){
      $waktu_mulai = strtotime(date("Y-m-d $get->jam_mulai"));
      $waktu_selesai = strtotime(date("Y-m-d $get->jam_selesai"));
      $durasi = ($waktu_selesai - $waktu_mulai) / 60;
      return $durasi;
    }
    else return 0;
  }

  public static function isExists($id_siswa, $id_jadwal)
  {
    return self::where('id_siswa', $id_siswa)
      ->where('id_jadwal', $id_jadwal)
      ->exists();
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_jadwal_siswa', $data['id_jadwal_siswa'])->update($data);
  }

  public static function updateByIdJadwalAndSiswa($id_jadwal, $id_siswa, $data)
  {
    self::where('id_jadwal', $id_jadwal)
      ->where('id_siswa', $id_siswa)
      ->update($data);
  }

  public static function deleteData($id_jadwal, $id_siswa = null)
  {
    if($id_siswa !== null){
      self::where('id_siswa', $id_siswa)
        ->where('id_jadwal', $id_jadwal)
        ->delete();
    }
    else{
      self::where('id_jadwal', $id_jadwal)
        ->delete();
    }
  }

  public static function deleteByTanggal($id_jadwal, $id_siswa, $tanggal)
  {
    self::where('id_jadwal', $id_jadwal)
      ->where('id_siswa', $id_siswa)
      ->where('tanggal', $tanggal)
      ->delete();
  }
}
