<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Penempatan extends Model
{
  protected $table = 'penempatan';
  public $timestamps = false;

  const PENAMPARAN = 'PENAMPARAN';
  const RENON = 'RENON';
  const TABANAN = 'TABANAN';
  const JIMBARAN = 'JIMBARAN';

  public static $penempatan = [
    self::PENAMPARAN,
    self::RENON,
    self::TABANAN,
    self::JIMBARAN,
  ];

  public static function getInfo($id_penempatan)
  {
    return self::where('id_penempatan', $id_penempatan)->first();
  }

  public static function getNamaTempat($id_penempatan)
  {
    $get = self::getInfo($id_penempatan);
    return $get ? $get->nama_penempatan : null;
  }

  public static function getData()
  {
    return self::all();
  }

  public static function getJumlah()
  {
    return self::count();
  }

  public static function insertData($data)
  {
    self::insert($data);
  }

  public static function updateData($data)
  {
    self::where('id_penempatan', $data['id_penempatan'])->update($data);
  }

  public static function deleteData($id)
  {
    self::where('id_penempatan', $id)->delete();
  }
}
