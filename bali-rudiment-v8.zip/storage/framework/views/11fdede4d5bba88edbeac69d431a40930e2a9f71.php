<?php $__env->startSection('title','Beranda'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row justify-content-center">
            <div class="col-lg-12">
              <h4 class="page-title">Beranda</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row justify-content-center">
      <div class="col-lg-3">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-account-tie float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Instruktur</h6>
          <h3 class="my-3" data-plugin="counterup"><?php echo e($data_jumlah['Jumlah Instruktur']); ?></h3>
          <span class="text-muted">Aktif saat ini</span>
        </div>
      </div>
      <div class="col-lg-3">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-school float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Siswa</h6>
          <h3 class="my-3" data-plugin="counterup"><?php echo e($data_jumlah['Jumlah Siswa']); ?></h3>
          <span class="text-muted">Aktif saat ini</span>
        </div>
      </div>
      <div class="col-lg-3">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-guitar-acoustic float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Instrumen</h6>
          <h3 class="my-3" data-plugin="counterup"><?php echo e($data_jumlah['Jumlah Instrumen']); ?></h3>
          <span class="text-muted">Saat ini</span>
        </div>
      </div>
      <div class="col-lg-3">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-account-music float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Kelas</h6>
          <h3 class="my-3" data-plugin="counterup"><?php echo e($data_jumlah['Jumlah Kelas']); ?></h3>
          <span class="text-muted">Saat ini</span>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-office-building float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Studio</h6>
          <h3 class="my-3" data-plugin="counterup"><?php echo e($data_jumlah['Jumlah Studio']); ?></h3>
          <span class="text-muted">Saat ini</span>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-map-marker float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Penempatan</h6>
          <h3 class="my-3" data-plugin="counterup"><?php echo e($data_jumlah['Jumlah Penempatan']); ?></h3>
          <span class="text-muted">Saat ini</span>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card-box tilebox-one">
          <i class="mdi mdi-timer-sand float-right m-0 h2 text-muted"></i>
          <h6 class="text-muted text-uppercase mt-0">Jumlah Jadwal</h6>
          <h3 class="my-3" data-plugin="counterup"><?php echo e($data_jumlah['Jumlah Jadwal Bulan Ini']); ?></h3>
          <span class="text-muted">Bulan <?php echo e(\App\Http\Controllers\HelperController::setNamaBulan($bulan)); ?></span>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>