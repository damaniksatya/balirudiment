<tr>
  <?php if($with_hari): ?>
    <?php
      $rowspan_hari = $hari['siswa_total'] >= $hari['jadwal_total'] ? $hari['siswa_total'] : $hari['jadwal_total'];
    ?>
    <td rowspan="<?php echo e($rowspan_hari); ?>"><?php echo e($hari['hari']); ?></td>
  <?php endif; ?>

  <?php if($with_jadwal): ?>
    <td rowspan="<?php echo e($jadwal['siswa_total'] + 1); ?>" class="text-center"><?php echo e($jadwal['jam_mulai'] .' - '. $jadwal['jam_selesai']); ?></td>
    <td rowspan="<?php echo e($jadwal['siswa_total'] + 1); ?>"><?php echo e($jadwal['nama_studio']); ?></td>
    <td rowspan="<?php echo e($jadwal['siswa_total'] + 1); ?>" style="width: 150px"><?php echo e($jadwal['nama_instrumen']); ?></td>
    <?php if(!($nonaktif_edit && $nonaktif_delete)): ?>
      <td rowspan="<?php echo e($jadwal['siswa_total'] + 1); ?>" style="width: 40px; padding: 2px">
        <div class="btn-group btn-block">
          <?php if(!$nonaktif_edit): ?>
            <a class="btn btn-xs btn-outline-primary"
               href="<?php echo e(url('jadwal/edit/'.$jadwal['id_jadwal'])); ?>"
               style="padding-top: 3px; padding-bottom: 3px" title="Edit Jadwal">
              <i class="mdi mdi-pencil"></i>
            </a>
          <?php endif; ?>

          <?php if(!$nonaktif_delete): ?>
            <button class="btn btn-xs btn-outline-danger" style="padding-top: 3px; padding-bottom: 3px"
                    title="Hapus Jadwal" onclick="deleteData('<?php echo e($jadwal['id_jadwal']); ?>')">
              <i class="mdi mdi-trash-can"></i>
            </button>
          <?php endif; ?>
        </div>
      </td>
    <?php endif; ?>
  <?php endif; ?>

  <?php if($index_siswa != $jadwal['siswa_total']): ?>
    <td class="p-0">
      <table style="width: 100%" class="table-borderless">
        <tr>
          <td><?php echo e($jadwal['siswa'][$index_siswa]['nama_siswa']); ?></td>
          <?php if(!$nonaktif_edit_siswa): ?>
            <td style="width: 30px">
              <div class="btn-group dropleft">
                <button class="btn btn-sm btn-outline-primary border-0" data-toggle="dropdown" style="padding: 2px 5px 1px 5px; border-radius: 0.2rem">
                  <i class="mdi mdi-settings"></i>
                </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" href="#" onclick="openModalEditJam('<?php echo e($jadwal['id_jadwal']); ?>','<?php echo e($jadwal['siswa'][$index_siswa]['id_siswa']); ?>')">
                    Edit Jam Mengajar Per Tanggal
                  </a>
                </div>
              </div>
            </td>
          <?php endif; ?>
        </tr>
      </table>

    </td>
  <?php else: ?>
    <?php if(!$nonaktif_edit_siswa): ?>
      <td style="padding: 2px" class="text-center">
          <button class="btn btn-sm btn-block btn-outline-secondary" style="padding-top: 3px; padding-bottom: 3px; border-color: #e9ecef !important;"
                  onclick="openModalAddSiswa('<?php echo e($jadwal['id_jadwal']); ?>')">
            <?php if(!$jadwal['siswa_total']): ?>
              Masukkan Siswa
            <?php else: ?>
              Edit Siswa
            <?php endif; ?>
          </button>
      </td>
    <?php endif; ?>
  <?php endif; ?>
</tr>