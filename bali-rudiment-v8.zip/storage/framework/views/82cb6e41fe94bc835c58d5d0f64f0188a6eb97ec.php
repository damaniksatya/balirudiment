<?php $__env->startSection('title','Data Absensi Menunggu Konfirmasi'); ?>

<?php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_absensi_siswa);
  $nonaktif_konfirmasi = in_array(\App\SettingMenu::KONFIRMASI_ABSENSI_SISWA, $arr_nonaktif);
?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('plugins/select2/select2.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-12">
              
                
                  
                
              
              <h4 class="page-title">Data Absensi Menunggu Konfirmasi</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <table class="table table-sm table-bordered mb-0">
              <thead>
              <tr>
                <th>Hari, Tanggal</th>
                <th class="text-center">Jam</th>
                <th class="text-center">Durasi</th>
                <th>Studio</th>
                <th>Instrumen</th>
                <th>Instruktur</th>
                <th class="text-center" style="width: 100px">Aksi</th>
              </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($d->hari); ?>, <?php echo e(\App\Http\Controllers\HelperController::setNamaBulan(null, $d->tanggal)); ?></td>
                  <td class="text-center"><?php echo e($d->jadwal->jam_mulai .'-'. $d->jadwal->jam_selesai); ?></td>
                  <td class="text-center"><?php echo e($d->durasi_mengajar); ?> Menit</td>
                  <td><?php echo e($d->jadwal->nama_studio); ?></td>
                  <td><?php echo e($d->jadwal->nama_instrumen); ?></td>
                  <td><?php echo e($d->jadwal->nama_instruktur); ?></td>
                  <td class="p-1">
                    <div class="btn-group btn-block">
                      <a href="<?php echo e(url('absensi/detail/'.$d->id_absensi.'?back_url='.\Illuminate\Support\Facades\Route::current()->uri)); ?>"
                         class="btn btn-sm btn-outline-primary">Detail</a>
                      <?php if(!$nonaktif_konfirmasi): ?>
                        <button onclick="openModalKonfirmasi('<?php echo e($d->id_absensi); ?>')"
                           class="btn btn-sm btn-primary">Konfirmasi</button>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="modal-konfirmasi" tabindex="-1" role="dialog" aria-labelledby="label">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="label">Konfirmasi</h5>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        </div>
        <div class="modal-body" id="modal-body">

        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(url('plugins/select2/select2.min.js')); ?>"></script>
  <script>
      $(".select2").select2();

      function openModalKonfirmasi(id_absensi) {
          $.ajax({
              url: '<?php echo e(url('absensi/menunggu-konfirmasi/component/form-konfirmasi')); ?>',
              type: 'get',
              data: {
                  id_absensi: id_absensi,
              },
              success: function(data) {
                  $("#modal-konfirmasi").modal('show');
                  $("#modal-body").html(data);
              },
              error: async function(data) {
                  swal('Gagal','Terjadi kesalahan sistem','error');
              },
          });
      }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>