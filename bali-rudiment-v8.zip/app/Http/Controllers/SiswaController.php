<?php

namespace App\Http\Controllers;

use App\Instrumen;
use App\Kelas;
use App\Penempatan;
use App\Siswa;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;

class SiswaController extends Controller
{
  public function index()
  {
    $data = Siswa::getData();

    return view('pages.siswa.index')
      ->with('data', $data);
  }

  public function viewAdd()
  {
    $data_penempatan = Penempatan::getData();
    $data_kelas = Kelas::getData();
    $data_instrumen = Instrumen::getData();

    return view('pages.siswa.add')
      ->with('data_penempatan', $data_penempatan)
      ->with('data_kelas', $data_kelas)
      ->with('data_instrumen', $data_instrumen);
  }

  public function viewEdit($id_pengguna)
  {
    $info = Siswa::getInfo($id_pengguna);
    $data_penempatan = Penempatan::getData();
    $data_kelas = Kelas::getData();
    $data_instrumen = Instrumen::getData();

    return view('pages.siswa.edit')
      ->with('info', $info)
      ->with('data_penempatan', $data_penempatan)
      ->with('data_kelas', $data_kelas)
      ->with('data_instrumen', $data_instrumen);
  }

  public function viewEditProfile()
  {
    $id_pengguna = Auth::user()->id;
    $info = Siswa::getInfo($id_pengguna);

    return view('pages.siswa.profile')
      ->with('info', $info);
  }

  public function store(Request $req)
  {
    $this->validateData();

    DB::transaction(function () use ($req){
      $id_pengguna = User::insertData([
        'nama' => $req->nama_siswa,
        'username' => $req->username,
        'password' => bcrypt($req->password),
        'foto_profile' => $this->storeImageFile(),
        'level_user' => User::L_SISWA,
        'status' => User::S_AKTIF
      ]);

      Siswa::insertData([
        'id_pengguna' => $id_pengguna,
        'id_penempatan' => $req->id_penempatan,
        'id_kelas' => $req->id_kelas,
        'id_instrumen' => $req->id_instrumen,
        'nama_siswa' => $req->nama_siswa,
        'email_siswa' => $req->email_siswa,
        'tanggal_lahir' => date('Y-m-d', strtotime($req->tanggal_lahir)),
        'sekolah' => $req->sekolah,
        'jenis_kelamin' => $req->jenis_kelamin,
        'alamat' => $req->alamat,
        'email_orangtua' => $req->email_orangtua,
        'no_hp_orangtua' => $req->no_hp_orangtua,
        'tangan_dominan' => $req->tangan_dominan,
        'sosial_media' => json_encode([
          'instagram' => $req->instagram,
          'twitter' => $req->twitter,
          'facebook' => $req->facebook,
          'youtube' => $req->youtube,
        ])
      ]);
    });

    return back()->with('success','Berhasil menyimpan data');
  }

  public function update(Request $req)
  {
    DB::transaction(function () use ($req){
      $new_username = $req->username != $req->username_old;
      $new_email = $req->email_siswa != $req->email_siswa_old;
      $new_password = $req->password != null;
      $this->validateData($new_username, $new_email, $new_password);

      $data_pengguna = [
        'id' => $req->id_pengguna,
        'nama' => $req->nama_siswa,
        'username' => $req->username,
      ];
      if($new_password){
        $data_pengguna['password'] = bcrypt($req->password);
      }
      if(request()->file('foto_profile')){
        $data_pengguna['foto_profile'] = $this->storeImageFile();
        $this->deleteFile($req->foto_profile_old);
      }

      User::updateData($req->id_pengguna, $data_pengguna);

      Siswa::updateData([
        'id_pengguna' => $req->id_pengguna,
        'id_penempatan' => $req->id_penempatan,
        'id_kelas' => $req->id_kelas,
        'id_instrumen' => $req->id_instrumen,
        'nama_siswa' => $req->nama_siswa,
        'email_siswa' => $req->email_siswa,
        'tanggal_lahir' => date('Y-m-d', strtotime($req->tanggal_lahir)),
        'sekolah' => $req->sekolah,
        'jenis_kelamin' => $req->jenis_kelamin,
        'alamat' => $req->alamat,
        'email_orangtua' => $req->email_orangtua,
        'no_hp_orangtua' => $req->no_hp_orangtua,
        'tangan_dominan' => $req->tangan_dominan,
        'sosial_media' => json_encode([
          'instagram' => $req->instagram,
          'twitter' => $req->twitter,
          'facebook' => $req->facebook,
          'youtube' => $req->youtube,
        ])
      ]);
    });

    return redirect('siswa')->with('success','Berhasil menyimpan data');
  }

  public function updateProfile(Request $req)
  {
    DB::transaction(function () use ($req){
      $new_username = $req->username != $req->username_old;
      $new_email = $req->email_siswa != $req->email_siswa_old;
      $this->validateData($new_username, $new_email, false);

      $data_pengguna = [
        'id' => $req->id_pengguna,
        'username' => $req->username,
      ];
      if(request()->file('foto_profile')){
        $data_pengguna['foto_profile'] = $this->storeImageFile();
        $this->deleteFile($req->foto_profile_old);
      }

      User::updateData($req->id_pengguna, $data_pengguna);

      Siswa::updateData([
        'id_pengguna' => $req->id_pengguna,
        'email_siswa' => $req->email_siswa,
        'alamat' => $req->alamat,
        'email_orangtua' => $req->email_orangtua,
        'no_hp_orangtua' => $req->no_hp_orangtua,
        'sosial_media' => json_encode([
          'instagram' => $req->instagram,
          'twitter' => $req->twitter,
          'facebook' => $req->facebook,
          'youtube' => $req->youtube,
        ])
      ]);
    });

    return back()->with('success','Berhasil menyimpan data');
  }

  public function updateStatus(Request $req)
  {
    User::updateData($req->id, [
      'status' => $req->status
    ]);

    return back()->with('success','Berhasil menyimpan data');
  }

  private function validateData($new_username = true, $new_email_siswa = true, $new_password = true)
  {
    return request()->validate([
      'id_penempatan' => 'required',
      'id_kelas' => 'required',
      'id_instrumen' => 'required',
      'nama_siswa' => 'required|max:80',
      'email_siswa' => 'required|email|max:80'.($new_email_siswa ? '|unique:siswa' : ''),
      'tanggal_lahir' => 'required',
      'sekolah' => 'max:80',
      'jenis_kelamin' => 'required',
      'alamat' => 'required|max:180',
      'email_orangtua' => 'email|max:80',
      'no_hp_orangtua' => 'required|max:20',
      'tangan_dominan' => 'required',
      'username' => 'required|max:30|min:3'.($new_username ? '|unique:pengguna' : ''),
      'password' => $new_password ? 'required|min:6' : '',
    ],[
      'id_penempatan.required' => 'Penempatan harus dipilih!',
      'id_kelas.required' => 'Kelas harus dipilih!',
      'id_instrumen.required' => 'Instrumen harus dipilih!',
      'nama_siswa.required' => 'Nama siswa harus diisi!',
      'nama_siswa.max' => 'Nama siswa maksimal :max karakter!',
      'email_siswa.required' => 'Email siswa harus diisi!',
      'email_siswa.max' => 'Email siswa maksimal :max karakter!',
      'email_siswa.unique' => 'Email siswa telah digunakan!',
      'email_siswa.email' => 'Email siswa tidak valid!',
      'tanggal_lahir.required' => 'Tanggal lahir harus diisi!',
      'sekolah.max' => 'Sekolah maksimal :max karakter!',
      'jenis_kelamin.required' => 'Jenis Kelamin harus diisi!',
      'alamat.required' => 'Alamat harus diisi!',
      'alamat.max' => 'Alamat maksimal :max karakter!',
      'email_orangtua.max' => 'Email orang tua maksimal :max karakter!',
      'email_orangtua.email' => 'Email orang tua tidak valid!',
      'no_hp_orangtua.required' => 'No HP Orang Tua harus diisi!',
      'no_hp_orangtua.max' => 'No HP Orang Tua maksimal :max karakter!',
      'tangan_dominan.required' => 'Tangan Dominan harus diisi!',
      'username.required' => 'Username harus diisi!',
      'username.max' => 'Username maksimal :max karakter!',
      'username.min' => 'Username minimal :max karakter!',
      'username.unique' => 'Username telah digunakan!',
      'password.required' => 'Kata Sandi harus diisi!',
      'password.min' => 'Kata Sandi minimal :min karakter!',
    ]);
  }

  private function storeImageFile($location = 'storage/foto_profile')
  {
    if(request()->file('foto_profile')){
      $file = request()->file('foto_profile');
      $ext = $file->getClientOriginalExtension();
      $name = time() .'.' . $ext;
      $file->move(public_path() . "/$location", $name);
      return $location.'/'.$name;
    }
    else{
      return null;
    }
  }

  private function deleteFile($nama)
  {
    File::delete("public/$nama");
  }
}
