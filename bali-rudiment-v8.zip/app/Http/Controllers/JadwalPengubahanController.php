<?php

namespace App\Http\Controllers;

use App\Jadwal;
use App\JadwalPengubahan;
use App\JadwalSiswa;
use App\Siswa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class JadwalPengubahanController extends Controller
{
  public function indexSiswa()
  {
    $data = JadwalPengubahan::getDataBySiswa();
    $data_jadwal = JadwalSiswa::getJadwalSiswaUntukPengubahan();
//    dd($data, $data_jadwal);

    return view('pages.pengubahan_jadwal.index_siswa')
      ->with('data_jadwal', $data_jadwal)
      ->with('data', $data);
  }

  public function indexMenungguKonfirmasi()
  {
    $data_menunggu = JadwalPengubahan::getDataByStatus(JadwalPengubahan::S_MENUNGGU_KONFIRMASI);
    $data_ditolak = JadwalPengubahan::getDataByStatus(JadwalPengubahan::S_DITOLAK);

    return view('pages.pengubahan_jadwal.index_menunggu')
      ->with('data_menunggu', $data_menunggu)
      ->with('data_ditolak', $data_ditolak);
  }

  public function indexDikonfirmasi()
  {
    $data = JadwalPengubahan::getDataByStatus(JadwalPengubahan::S_DIKONFIRMASI);
//    dd($data);

    return view('pages.pengubahan_jadwal.index_dikonfirmasi')
      ->with('data', $data);
  }

  public function getComponentPengubahan(Request $req)
  {
    $temp = explode('--', $req->id_jadwal_sebelum);
    if(count($temp) == 3){
      $id_jadwal = $temp[0];
      $tanggal = $temp[1];
      $durasi = JadwalSiswa::getDurasi($id_jadwal, $tanggal);
      $pilihan_pengubahan_jadwal = Jadwal::getPilihanPengubahanJadwal($durasi);
//      return [$durasi, $pilihan_pengubahan_jadwal];
      return view('components.pengubahan_jadwal.select_pengubahan_jadwal')
        ->with('pilihan_pengubahan_jadwal', $pilihan_pengubahan_jadwal);
    }
    else return null;
  }

  public function store(Request $req)
  {
//    dd($req);
    $this->validateData();

    $jadwal_sebelum = explode('--', $req->id_jadwal_sebelum);
    $jadwal_setelah = explode('--', $req->id_jadwal_setelah);

    JadwalPengubahan::insertData([
      'id_siswa' => Siswa::getIdSiswa(),
      'id_jadwal_sebelum' => $jadwal_sebelum[0],
      'id_jadwal_setelah' => $jadwal_setelah[0],
      'tanggal_sebelum' => $jadwal_sebelum[1],
      'tanggal_setelah' => $jadwal_setelah[1],
      'jam_sebelum' => $jadwal_sebelum[2],
      'jam_setelah' => $jadwal_setelah[2],
      'status' => JadwalPengubahan::S_MENUNGGU_KONFIRMASI,
      'waktu_pengajuan' => date('Y-m-d H:i:s')
    ]);

    return back()->with('success','Berhasil mengajukan pengubahan jadwal');
  }

  private function validateData()
  {
    return request()->validate([
      'id_jadwal_sebelum' => 'required',
      'id_jadwal_setelah' => 'required',
    ],[
      'id_jadwal_sebelum.required' => 'Jadwal yang ingin diubah harus dipilih!',
      'id_jadwal_setelah.required' => 'Pengubahan Jadwal harus dipilih!',
    ]);
  }

  public function tolak(Request $req)
  {
    JadwalPengubahan::updateData([
      'id_jadwal_pengubahan' => $req->id_jadwal_pengubahan,
      'status' => JadwalPengubahan::S_DITOLAK
    ]);

    return back()->with('success','Berhasil menolak pengajuan pengubahan jadwal');
  }

  public function konfirmasi(Request $req)
  {
    DB::transaction(function () use ($req){
      JadwalPengubahan::updateData([
        'id_jadwal_pengubahan' => $req->id_jadwal_pengubahan,
        'status' => JadwalPengubahan::S_DIKONFIRMASI
      ]);

      $info = JadwalPengubahan::getInfo($req->id_jadwal_pengubahan);
      JadwalSiswa::deleteByTanggal($info->id_jadwal_sebelum, $info->id_siswa, $info->tanggal_sebelum);

      $waktu = explode('-', $info->jam_setelah);

      JadwalSiswa::insertData([
        'id_jadwal' => $info->id_jadwal_setelah,
        'id_siswa' => $info->id_siswa,
        'tanggal' => $info->tanggal_setelah,
        'jam_mulai' => $waktu[0],
        'jam_selesai' => $waktu[1],
      ]);
    });

    return back()->with('success','Berhasil konfirmasi pengajuan pengubahan jadwal');
  }
}


