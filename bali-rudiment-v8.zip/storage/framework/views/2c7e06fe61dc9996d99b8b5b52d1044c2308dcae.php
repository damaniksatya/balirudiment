<?php $__env->startSection('title','Data Kelas'); ?>

<?php
  $arr_nonaktif = \App\SettingMenu::getAksiNonaktif(Auth::user()->level_user, \App\SettingMenu::$menu_kelas);
  $nonaktif_input = in_array(\App\SettingMenu::CREATE_KELAS, $arr_nonaktif);
  $nonaktif_edit = in_array(\App\SettingMenu::UPDATE_KELAS, $arr_nonaktif);
  $nonaktif_delete = in_array(\App\SettingMenu::DELETE_KELAS, $arr_nonaktif);
?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="row">
            <div class="col-lg-8">
              <div class="page-title-right mt-2 pt-1">
                <?php if($nonaktif_input == false): ?>
                  <a href="<?php echo e(url('kelas/add')); ?>" class="btn btn-primary">
                    <i class="mdi mdi-plus mr-2"></i>Input Data Kelas
                  </a>
                <?php endif; ?>
              </div>
              <h4 class="page-title">Data Kelas</h4>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-8">
        <div class="card">
          <div class="card-body">
            <div class="table-responsive">
              <table id="datatable" class="table mb-0 table-sm table-bordered">
                <thead>
                <tr>
                  <th class="text-center" style="width: 40px">No</th>
                  <th class="">Nama Kelas</th>
                  <?php if(!($nonaktif_edit && $nonaktif_delete)): ?>
                    <th style="width: 80px" class="text">Aksi</th>
                  <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-center"><?php echo e($no+1); ?></td>
                    <td class=""><?php echo e($d['nama_kelas']); ?></td>
                    <?php if(!($nonaktif_edit && $nonaktif_delete)): ?>
                      <td>
                        <div class="btn-group btn-block">
                          <?php if(!$nonaktif_edit): ?>
                            <a href="<?php echo e(url('kelas/edit/'.$d['id_kelas'])); ?>" class="btn btn-outline-primary btn-sm">Edit</a>
                          <?php endif; ?>

                          <?php if(!$nonaktif_delete): ?>
                            <button id="delete-<?php echo e($d['id_kelas']); ?>" type="button" class="btn btn-block btn-sm btn-outline-danger">Hapus</button>
                          <?php endif; ?>
                        </div>

                        <form id="form-delete<?php echo e($d['id_kelas']); ?>" action="<?php echo e(url('kelas')); ?>" method="post">
                          <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                          <input type="hidden" name="id" value="<?php echo e($d['id_kelas']); ?>">
                        </form>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          $('#delete-<?php echo e($d['id_kelas']); ?>').click(function(){
              swal({
                  title: "Anda yakin?",
                  text: "Data kelas <?php echo e($d['nama_kelas']); ?> yang akan dihapus, tidak bisa dikembalikan!",
                  type: "warning",
                  showCancelButton: true,
                  confirmButtonColor: "#E62129",
                  confirmButtonText: "Ya, hapus!",
                  cancelButtonText: "Batalkan",
                  closeOnConfirm: false
              }, function(){
                  $("#form-delete<?php echo e($d['id_kelas']); ?>").submit();
              });
          });
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>