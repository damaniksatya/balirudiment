<div class="slimscroll-menu">
  <div id="sidebar-menu">
    @if(\Illuminate\Support\Facades\Auth::user()->level_user == \App\User::L_ADMIN)
      @include('components.sidebar_admin')
    @elseif(\Illuminate\Support\Facades\Auth::user()->level_user == \App\User::L_GENERAL_ADMIN)
      @include('components.sidebar_general_admin')
    @elseif(\Illuminate\Support\Facades\Auth::user()->level_user == \App\User::L_INSTRUKTUR)
      @include('components.sidebar_instruktur')
    @elseif(\Illuminate\Support\Facades\Auth::user()->level_user == \App\User::L_ACCOUNTING)
      @include('components.sidebar_accounting')
    @elseif(\Illuminate\Support\Facades\Auth::user()->level_user == \App\User::L_SISWA)
      @include('components.sidebar_siswa')
    @endif
  </div>
  <div class="clearfix"></div>
  {{--<div style="background: url('{{ url('images/logo') }}'); background-size: cover; background-position: "></div>--}}
</div>
