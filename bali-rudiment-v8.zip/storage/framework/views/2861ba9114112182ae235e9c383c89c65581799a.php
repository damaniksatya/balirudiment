<?php $__env->startSection('title','Setting Menu'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="page-title-box">
          <div class="page-title-right mt-2 pt-1">
          </div>
          <h4 class="page-title">Setting Menu</h4>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <div class="table-responsive">
              <table id="datatable" class="table mb-0 table-sm table-bordered table-hover">
                <thead>
                <tr>
                  <th class="text-center" style="width: 40px">No</th>
                  <th class="">Level User</th>
                  <th>Aksi</th>
                  <th class="text-center no-sort">Status</th>
                  <th style="width: 70px" class="no-sort"></th>
                </tr>
                </thead>
                <tbody>
                <?php $no = 1 ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index_user=>$level_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $level_user['aksi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index_aksi=>$aksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $is_aktif = $aksi['status'] == \App\SettingMenu::S_AKTIF; ?>
                    <tr>
                      <td class="text-center"><?php echo e($no++); ?></td>
                      <td class=""><?php echo e($level_user['level_user']); ?></td>
                      <td class=""><?php echo e($aksi['aksi']); ?></td>
                      <td class="text-center">
                        <span style="padding-top: 5px; display: <?php echo e($is_aktif ? 'inline-block' : 'none'); ?>" id="badge-aktif<?php echo e($no); ?>"
                              class="badge badge-<?php echo e(\App\SettingMenu::$color[\App\SettingMenu::S_AKTIF]); ?>">
                          <?php echo e(\App\SettingMenu::S_AKTIF); ?>

                        </span>
                        <span style="padding-top: 5px; display: <?php echo e(!$is_aktif ? 'inline-block' : 'none'); ?>" id="badge-nonaktif<?php echo e($no); ?>"
                              class="badge badge-<?php echo e(\App\SettingMenu::$color[\App\SettingMenu::S_NONAKTIF]); ?>">
                          <?php echo e(\App\SettingMenu::S_NONAKTIF); ?>

                        </span>
                      </td>
                      <td>
                        <button type="button" onclick="nonaktifkan('<?php echo e($level_user['level_user']); ?>','<?php echo e($aksi['aksi']); ?>','<?php echo e($no); ?>')"
                                style="display: <?php echo e($is_aktif ? 'block' : 'none'); ?>;" id="btn-nonaktif<?php echo e($no); ?>"
                                class="btn btn-block btn-sm btn-outline-danger px-1 my-0">Nonaktifkan</button>
                        <button onclick="aktifkan('<?php echo e($level_user['level_user']); ?>','<?php echo e($aksi['aksi']); ?>','<?php echo e($no); ?>')"
                                style="display: <?php echo e($is_aktif ? 'none' : 'block'); ?>;" id="btn-aktif<?php echo e($no); ?>"
                                type="button" class="btn btn-block btn-sm btn-outline-primary px-1 my-0">Aktifkan</button>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <?php echo $__env->make('components.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('components.sweet_alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script>
    function nonaktifkan(level_user, aksi, no) {
        $.ajax({
            url: '<?php echo e(url('setting-menu/status')); ?>',
            type: 'put',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                level_user: level_user,
                aksi: aksi,
                status: '<?php echo e(\App\SettingMenu::S_NONAKTIF); ?>',
            },
            success: function(data) {
                $(`#badge-aktif${no}`).hide();
                $(`#badge-nonaktif${no}`).show();
                $(`#btn-aktif${no}`).show();
                $(`#btn-nonaktif${no}`).hide();
            },
            error: async function(data) {
                swal({
                    title: 'Gagal',
                    text: "Terjadi kesalahan sistem",
                    type: 'error',
                    confirmButtonColor: '#306397'
                });
            },
        });
    }
    function aktifkan(level_user, aksi, no) {
        $.ajax({
            url: '<?php echo e(url('setting-menu/status')); ?>',
            type: 'put',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                level_user: level_user,
                aksi: aksi,
                status: '<?php echo e(\App\SettingMenu::S_AKTIF); ?>',
            },
            success: function(data) {
                $(`#badge-aktif${no}`).show();
                $(`#badge-nonaktif${no}`).hide();
                $(`#btn-aktif${no}`).hide();
                $(`#btn-nonaktif${no}`).show();
            },
            error: async function(data) {
                swal({
                    title: 'Gagal',
                    text: "Terjadi kesalahan sistem",
                    type: 'error',
                    confirmButtonColor: '#306397'
                });
            },
        });
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>